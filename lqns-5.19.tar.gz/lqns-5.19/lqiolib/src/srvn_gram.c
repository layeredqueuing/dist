/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0

/* Substitute the variable and function names.  */
#define yyparse LQIO_parse
#define yylex   LQIO_lex
#define yyerror LQIO_error
#define yylval  LQIO_lval
#define yychar  LQIO_char
#define yydebug LQIO_debug
#define yynerrs LQIO_nerrs


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TEXT = 258,
     END_LIST = 259,
     SYMBOL = 260,
     VARIABLE = 261,
     RANGE_ERR = 262,
     SOLVER = 263,
     INTEGER = 264,
     FLOAT = 265,
     CONST_INFINITY = 266,
     TRANSITION = 267,
     KEY_UTILIZATION = 268,
     KEY_THROUGHPUT = 269,
     KEY_PROCESSOR_UTILIZATION = 270,
     KEY_SERVICE_TIME = 271,
     KEY_VARIANCE = 272,
     KEY_THROUGHPUT_BOUND = 273,
     KEY_PROCESSOR_WAITING = 274,
     KEY_WAITING = 275,
     KEY_WAITING_VARIANCE = 276,
     KEY_ITERATIONS = 277,
     KEY_ELAPSED_TIME = 278,
     KEY_USER_TIME = 279,
     KEY_SYSTEM_TIME = 280,
     KEY_EXCEEDED_TIME = 281,
     TOK_LESS_EQUAL = 282,
     TOK_LOGIC_NOT = 283,
     TOK_LESS_THAN = 284,
     TOK_NOT_EQUALS = 285,
     TOK_GREATER_EQUAL = 286,
     TOK_EQUALS = 287,
     TOK_LOGIC_AND = 288,
     TOK_GREATER_THAN = 289,
     TOK_LOGIC_OR = 290,
     TOK_POWER = 291,
     SRVN_INPUT = 292,
     SPEX_PARAMETER = 293,
     SPEX_RESULT = 294,
     SPEX_CONVERGENCE = 295,
     SPEX_EXPRESSION = 296
   };
#endif
/* Tokens.  */
#define TEXT 258
#define END_LIST 259
#define SYMBOL 260
#define VARIABLE 261
#define RANGE_ERR 262
#define SOLVER 263
#define INTEGER 264
#define FLOAT 265
#define CONST_INFINITY 266
#define TRANSITION 267
#define KEY_UTILIZATION 268
#define KEY_THROUGHPUT 269
#define KEY_PROCESSOR_UTILIZATION 270
#define KEY_SERVICE_TIME 271
#define KEY_VARIANCE 272
#define KEY_THROUGHPUT_BOUND 273
#define KEY_PROCESSOR_WAITING 274
#define KEY_WAITING 275
#define KEY_WAITING_VARIANCE 276
#define KEY_ITERATIONS 277
#define KEY_ELAPSED_TIME 278
#define KEY_USER_TIME 279
#define KEY_SYSTEM_TIME 280
#define KEY_EXCEEDED_TIME 281
#define TOK_LESS_EQUAL 282
#define TOK_LOGIC_NOT 283
#define TOK_LESS_THAN 284
#define TOK_NOT_EQUALS 285
#define TOK_GREATER_EQUAL 286
#define TOK_EQUALS 287
#define TOK_LOGIC_AND 288
#define TOK_GREATER_THAN 289
#define TOK_LOGIC_OR 290
#define TOK_POWER 291
#define SRVN_INPUT 292
#define SPEX_PARAMETER 293
#define SPEX_RESULT 294
#define SPEX_CONVERGENCE 295
#define SPEX_EXPRESSION 296




/* Copy the first part of user declarations.  */
#line 5 "srvn_gram.y"

#define YYDEBUG 1
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <string.h>
#include "input.h"
#include "srvn_input.h"
#include "srvn_spex.h"

static char * make_name( int i );
static void * curr_task = 0;
static void * curr_proc = 0;
static void * curr_group = 0;
static void * curr_entry = 0;
static void * dest_entry = 0;
static void * curr_activity = 0;
static bool constant_expression = true;
extern int LQIO_lex();


/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 38 "srvn_gram.y"
{
    int anInt;
    double aFloat;
    void * aVariable;
    void * domObject;
    char * aString;
    void * entryList;
    void * activityList;
    scheduling_type schedulingFlag;
    void * aParseTreeNode;
    void * aParseTreeList;
}
/* Line 193 of yacc.c.  */
#line 221 "srvn_gram.c"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 216 of yacc.c.  */
#line 234 "srvn_gram.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  31
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   757

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  95
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  125
/* YYNRULES -- Number of rules.  */
#define YYNRULES  326
/* YYNRULES -- Number of states.  */
#define YYNSTATES  639

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   296

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,    53,    91,     2,
      54,    55,    51,    49,    43,    50,     2,    52,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    47,    90,
       2,    44,     2,    48,     2,    83,     2,    92,     2,    81,
      84,    42,    65,    72,     2,     2,     2,    85,     2,    73,
      56,     2,    67,    74,    70,    68,    86,    78,    87,     2,
      89,    45,     2,    46,     2,     2,     2,    82,    75,    63,
      58,     2,    59,    69,    62,    60,     2,     2,     2,    66,
      76,     2,    57,    79,    61,    64,    71,    77,     2,     2,
       2,    88,    80,    93,     2,    94,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     6,     9,    12,    15,    18,    23,    30,
      31,    41,    42,    51,    52,    60,    61,    67,    68,    70,
      72,    74,    76,    78,    81,    82,    85,    88,    91,    94,
      97,   100,   101,   104,   106,   112,   116,   122,   132,   136,
     138,   144,   146,   150,   152,   156,   158,   162,   166,   170,
     174,   178,   182,   184,   188,   192,   194,   198,   202,   206,
     208,   212,   214,   217,   219,   224,   226,   230,   234,   239,
     241,   243,   245,   249,   254,   256,   258,   261,   263,   264,
     271,   272,   280,   285,   287,   289,   291,   293,   295,   297,
     299,   301,   303,   306,   307,   309,   312,   315,   318,   321,
     326,   327,   332,   333,   335,   338,   340,   341,   349,   351,
     353,   355,   356,   359,   364,   365,   370,   372,   375,   377,
     378,   388,   393,   398,   400,   402,   404,   406,   408,   410,
     412,   414,   416,   418,   420,   422,   424,   427,   429,   432,
     433,   435,   438,   441,   443,   446,   449,   452,   455,   458,
     459,   462,   467,   470,   475,   478,   483,   488,   490,   492,
     495,   500,   504,   509,   513,   519,   523,   528,   532,   535,
     538,   543,   546,   549,   552,   555,   561,   567,   572,   574,
     576,   578,   581,   585,   590,   593,   597,   602,   605,   609,
     614,   620,   622,   625,   629,   634,   637,   641,   646,   649,
     653,   658,   661,   665,   670,   673,   675,   676,   679,   680,
     683,   688,   691,   694,   699,   702,   707,   710,   715,   718,
     723,   726,   731,   734,   739,   742,   745,   746,   749,   754,
     757,   762,   763,   766,   771,   778,   780,   782,   785,   790,
     795,   799,   806,   810,   811,   818,   819,   826,   831,   833,
     837,   839,   843,   845,   850,   854,   858,   859,   861,   865,
     867,   871,   873,   878,   880,   884,   886,   889,   894,   898,
     903,   905,   909,   912,   917,   919,   924,   928,   931,   933,
     935,   937,   940,   941,   944,   949,   952,   957,   960,   965,
     968,   973,   976,   981,   984,   989,   992,   995,   996,   999,
    1004,  1007,  1012,  1017,  1025,  1026,  1028,  1031,  1035,  1037,
    1042,  1043,  1045,  1048,  1052,  1054,  1056,  1058,  1060,  1064,
    1066,  1068,  1070,  1072,  1074,  1076,  1078
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
      96,     0,    -1,    37,    97,    -1,    38,   111,    -1,    39,
     210,    -1,    40,   213,    -1,    41,   118,    -1,   111,    98,
     209,   212,    -1,    99,   125,   137,   146,   159,   181,    -1,
      -1,    42,   104,   105,   106,   107,   108,     4,   100,   109,
      -1,    -1,    42,   104,   105,   106,   108,     4,   101,   109,
      -1,    -1,    42,   104,   105,   106,     4,   102,   109,    -1,
      -1,    42,   104,     4,   103,   109,    -1,    -1,     3,    -1,
     215,    -1,   217,    -1,   217,    -1,   215,    -1,   110,   109,
      -1,    -1,    20,     6,    -1,    16,     6,    -1,    22,     6,
      -1,    23,     6,    -1,    24,     6,    -1,    25,     6,    -1,
      -1,   111,   112,    -1,   113,    -1,     6,    43,     6,    44,
     114,    -1,     6,    44,   114,    -1,     6,    44,    45,   124,
      46,    -1,     6,    44,    45,   216,    47,   216,    43,   216,
      46,    -1,     6,    44,     3,    -1,     8,    -1,   115,    48,
     115,    47,   115,    -1,   115,    -1,   115,    35,   116,    -1,
     116,    -1,   116,    33,   117,    -1,   117,    -1,   117,    32,
     118,    -1,   117,    30,   118,    -1,   117,    29,   118,    -1,
     117,    27,   118,    -1,   117,    34,   118,    -1,   117,    31,
     118,    -1,   118,    -1,   118,    49,   119,    -1,   118,    50,
     119,    -1,   119,    -1,   119,    51,   120,    -1,   119,    52,
     120,    -1,   119,    53,   120,    -1,   120,    -1,   121,    36,
     120,    -1,   121,    -1,    28,   122,    -1,   122,    -1,   122,
      45,   118,    46,    -1,   123,    -1,    54,   118,    55,    -1,
     219,    54,    55,    -1,   219,    54,   124,    55,    -1,     6,
      -1,   216,    -1,   118,    -1,   124,    43,   118,    -1,    56,
     126,   127,     4,    -1,     9,    -1,   129,    -1,   127,   129,
      -1,   218,    -1,    -1,    57,   128,   132,   130,   134,   136,
      -1,    -1,    57,   128,   133,   215,   131,   134,   136,    -1,
      58,   128,   128,   215,    -1,    59,    -1,    60,    -1,    61,
      -1,    62,    -1,    57,    -1,    63,    -1,    64,    -1,    65,
      -1,    56,    -1,   135,   134,    -1,    -1,    60,    -1,    66,
     217,    -1,    61,   217,    -1,    67,   215,    -1,    13,     6,
      -1,    13,     9,     6,     6,    -1,    -1,    68,   138,   139,
       4,    -1,    -1,     9,    -1,   139,   140,    -1,   140,    -1,
      -1,    69,   142,   143,   144,   128,   141,   145,    -1,   218,
      -1,   215,    -1,    63,    -1,    -1,    13,     6,    -1,    13,
       9,     6,     6,    -1,    -1,    70,   147,   148,     4,    -1,
       9,    -1,   148,   149,    -1,   149,    -1,    -1,    71,   151,
     152,   153,     4,   128,   150,   155,   157,    -1,    72,   151,
     151,   217,    -1,    73,   151,   151,   217,    -1,   218,    -1,
      56,    -1,    74,    -1,    75,    -1,    59,    -1,    62,    -1,
      60,    -1,    76,    -1,    57,    -1,    61,    -1,    77,    -1,
      78,    -1,   154,    -1,   153,   154,    -1,   218,    -1,   156,
     155,    -1,    -1,   217,    -1,    70,     9,    -1,    69,   142,
      -1,    60,    -1,    66,   217,    -1,    79,   217,    -1,    61,
     217,    -1,    80,   215,    -1,   158,   157,    -1,    -1,    14,
       6,    -1,    14,     9,     6,     6,    -1,    13,     6,    -1,
      13,     9,     6,     6,    -1,    15,     6,    -1,    15,     9,
       6,     6,    -1,    81,   160,   161,     4,    -1,     9,    -1,
     162,    -1,   161,   162,    -1,    82,   163,   165,   177,    -1,
      83,   163,   218,    -1,    63,   163,   166,   177,    -1,    59,
     163,   167,    -1,    84,   163,   164,   175,   179,    -1,    65,
     163,   169,    -1,    85,   163,   168,   177,    -1,    57,   163,
     170,    -1,    67,   163,    -1,    56,   163,    -1,    64,   163,
     171,   177,    -1,    68,   163,    -1,    86,   163,    -1,    78,
     163,    -1,    87,   163,    -1,    88,   163,   164,   172,   179,
      -1,    80,   163,   164,   173,   179,    -1,    89,   163,   174,
     177,    -1,   154,    -1,   154,    -1,   215,    -1,   215,     4,
      -1,   215,   215,     4,    -1,   215,   215,   215,     4,    -1,
       9,     4,    -1,     9,     9,     4,    -1,     9,     9,     9,
       4,    -1,   216,     4,    -1,   216,   216,     4,    -1,   216,
     216,   216,     4,    -1,     9,   216,    47,   216,   176,    -1,
       9,    -1,   215,     4,    -1,   215,   215,     4,    -1,   215,
     215,   215,     4,    -1,   215,     4,    -1,   215,   215,     4,
      -1,   215,   215,   215,     4,    -1,   215,     4,    -1,   215,
     215,     4,    -1,   215,   215,   215,     4,    -1,   215,     4,
      -1,   215,   215,     4,    -1,   215,   215,   215,     4,    -1,
     215,     4,    -1,     9,    -1,    -1,   178,   177,    -1,    -1,
      14,     6,    -1,    14,     9,     6,     6,    -1,    18,     6,
      -1,    13,     6,    -1,    13,     9,     6,     6,    -1,    15,
       6,    -1,    15,     9,     6,     6,    -1,    19,     6,    -1,
      19,     9,     6,     6,    -1,    16,     6,    -1,    16,     9,
       6,     6,    -1,    17,     6,    -1,    17,     9,     6,     6,
      -1,    20,     6,    -1,    20,     9,     6,     6,    -1,    26,
       6,    -1,   180,   179,    -1,    -1,    20,     6,    -1,    20,
       9,     6,     6,    -1,    21,     6,    -1,    21,     9,     6,
       6,    -1,    -1,   181,   182,    -1,    83,   183,   184,     4,
      -1,    83,   183,   184,    47,   188,     4,    -1,   151,    -1,
     185,    -1,   184,   185,    -1,    64,   203,   215,   205,    -1,
      63,   203,   215,   205,    -1,    59,   203,     9,    -1,    65,
     203,   216,    47,   216,   176,    -1,    85,   203,   216,    -1,
      -1,    88,   203,   164,   215,   186,   207,    -1,    -1,    80,
     203,   164,   215,   187,   207,    -1,    89,   203,   215,   205,
      -1,   189,    -1,   189,    90,   188,    -1,   190,    -1,   190,
      12,   196,    -1,   194,    -1,   192,    91,   194,   191,    -1,
     193,    49,   194,    -1,    54,   217,    55,    -1,    -1,   194,
      -1,   192,    91,   194,    -1,   194,    -1,   193,    49,   194,
      -1,   204,    -1,   204,    45,   195,    46,    -1,   163,    -1,
     195,    43,   163,    -1,   204,    -1,   201,   204,    -1,   201,
     204,    43,   199,    -1,   197,    91,   204,    -1,   200,   204,
      49,   198,    -1,   204,    -1,   197,    91,   204,    -1,   200,
     204,    -1,   198,    49,   200,   204,    -1,   204,    -1,   199,
      43,   201,   204,    -1,    54,   215,    55,    -1,   215,    51,
      -1,   218,    -1,   202,    -1,   202,    -1,   206,   205,    -1,
      -1,    14,     6,    -1,    14,     9,     6,     6,    -1,    13,
       6,    -1,    13,     9,     6,     6,    -1,    15,     6,    -1,
      15,     9,     6,     6,    -1,    19,     6,    -1,    19,     9,
       6,     6,    -1,    16,     6,    -1,    16,     9,     6,     6,
      -1,    17,     6,    -1,    17,     9,     6,     6,    -1,    26,
       6,    -1,   208,   207,    -1,    -1,    20,     6,    -1,    20,
       9,     6,     6,    -1,    21,     6,    -1,    21,     9,     6,
       6,    -1,    67,     9,   210,     4,    -1,    67,     9,   219,
      54,   124,    55,     4,    -1,    -1,   211,    -1,   210,   211,
      -1,     6,    44,   114,    -1,     6,    -1,    92,     9,   213,
       4,    -1,    -1,   214,    -1,   213,   214,    -1,     6,    44,
     114,    -1,     6,    -1,    10,    -1,     9,    -1,     6,    -1,
      93,   118,    94,    -1,    10,    -1,     9,    -1,    11,    -1,
       9,    -1,     6,    -1,     5,    -1,     9,    -1,     5,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,    76,    76,    78,    79,    80,    81,    89,    93,    99,
      98,   102,   101,   105,   104,   108,   107,   111,   114,   117,
     120,   123,   126,   130,   131,   135,   136,   137,   138,   139,
     140,   148,   149,   152,   153,   156,   157,   158,   160,   161,
     164,   165,   168,   169,   171,   172,   175,   176,   177,   178,
     179,   180,   181,   184,   185,   186,   189,   190,   191,   192,
     195,   196,   199,   200,   203,   204,   207,   208,   209,   210,
     211,   214,   215,   221,   224,   227,   228,   231,   236,   235,
     239,   238,   241,   245,   246,   247,   248,   249,   250,   253,
     254,   255,   258,   259,   262,   263,   264,   265,   269,   270,
     271,   282,   283,   286,   289,   290,   295,   294,   302,   306,
     309,   310,   314,   315,   316,   329,   332,   335,   336,   341,
     340,   347,   352,   359,   363,   364,   365,   366,   367,   368,
     369,   370,   371,   372,   373,   376,   377,   380,   384,   385,
     388,   389,   390,   391,   392,   393,   394,   395,   399,   400,
     404,   405,   406,   407,   408,   409,   422,   425,   428,   429,
     432,   433,   434,   435,   436,   437,   438,   439,   440,   441,
     442,   443,   444,   445,   446,   447,   448,   449,   452,   455,
     463,   466,   467,   468,   471,   472,   473,   476,   480,   485,
     493,   499,   502,   503,   504,   507,   508,   509,   512,   513,
     514,   517,   518,   519,   522,   525,   526,   531,   532,   536,
     537,   538,   539,   540,   541,   542,   543,   544,   545,   546,
     547,   548,   549,   550,   551,   554,   555,   558,   559,   560,
     561,   566,   567,   570,   571,   574,   579,   580,   583,   584,
     585,   586,   587,   589,   589,   590,   590,   591,   596,   597,
     600,   601,   604,   605,   606,   609,   610,   613,   614,   617,
     618,   621,   622,   625,   626,   629,   630,   631,   632,   633,
     636,   637,   640,   641,   644,   645,   648,   651,   654,   657,
     660,   664,   665,   668,   669,   670,   671,   672,   673,   674,
     675,   676,   677,   678,   679,   680,   683,   684,   687,   688,
     689,   690,   695,   696,   697,   700,   701,   704,   705,   712,
     713,   716,   717,   720,   721,   727,   728,   729,   731,   735,
     736,   737,   740,   741,   744,   745,   749
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "TEXT", "END_LIST", "SYMBOL", "VARIABLE",
  "RANGE_ERR", "SOLVER", "INTEGER", "FLOAT", "CONST_INFINITY",
  "TRANSITION", "KEY_UTILIZATION", "KEY_THROUGHPUT",
  "KEY_PROCESSOR_UTILIZATION", "KEY_SERVICE_TIME", "KEY_VARIANCE",
  "KEY_THROUGHPUT_BOUND", "KEY_PROCESSOR_WAITING", "KEY_WAITING",
  "KEY_WAITING_VARIANCE", "KEY_ITERATIONS", "KEY_ELAPSED_TIME",
  "KEY_USER_TIME", "KEY_SYSTEM_TIME", "KEY_EXCEEDED_TIME",
  "TOK_LESS_EQUAL", "TOK_LOGIC_NOT", "TOK_LESS_THAN", "TOK_NOT_EQUALS",
  "TOK_GREATER_EQUAL", "TOK_EQUALS", "TOK_LOGIC_AND", "TOK_GREATER_THAN",
  "TOK_LOGIC_OR", "TOK_POWER", "SRVN_INPUT", "SPEX_PARAMETER",
  "SPEX_RESULT", "SPEX_CONVERGENCE", "SPEX_EXPRESSION", "'G'", "','",
  "'='", "'['", "']'", "':'", "'?'", "'+'", "'-'", "'*'", "'/'", "'%'",
  "'('", "')'", "'P'", "'p'", "'d'", "'f'", "'i'", "'r'", "'h'", "'c'",
  "'s'", "'H'", "'m'", "'R'", "'U'", "'g'", "'T'", "'t'", "'I'", "'O'",
  "'S'", "'b'", "'n'", "'u'", "'W'", "'q'", "'z'", "'E'", "'a'", "'A'",
  "'F'", "'M'", "'V'", "'X'", "'y'", "'Z'", "';'", "'&'", "'C'", "'{'",
  "'}'", "$accept", "start", "SRVN_input_file", "srvn_spec",
  "general_info", "@1", "@2", "@3", "@4", "comment", "conv_val",
  "it_limit", "print_int", "underrelax_coeff", "general_obs",
  "general_obs_info", "parameter_list", "forall_expr", "assignment",
  "ternary_expr", "or_expr", "and_expr", "compare_expr", "expression",
  "term", "power", "prefix", "arrayref", "factor", "expression_list",
  "processor_info", "np", "p_decl_list", "proc_id", "p_decl", "@5", "@6",
  "proc_sched_flag", "proc_sched_quantum", "proc_opts", "proc_flags",
  "proc_obs", "group_info", "ng", "g_decl_list", "g_decl", "@7",
  "group_id", "group_share", "cap_flag", "group_obs", "task_info", "nt",
  "t_decl_list", "t_decl", "@8", "task_id", "task_sched_flag",
  "entry_list", "entry_id", "task_opts", "task_flags", "task_obs",
  "task_obs_info", "entry_info", "ne", "entry_decl_list", "entry_decl",
  "entry_ref", "dest_ref", "arrival_rate", "coeff_of_variation",
  "ph_type_flag", "max_ph_serv_time", "histogram", "priority",
  "ph_serv_time", "ph_RNV_nb", "ph_SNR_nb", "ph_think_time", "p_forward",
  "hist_bins", "entry_obs", "entry_obs_info", "call_obs", "call_obs_info",
  "activity_info_list", "activity_info", "task_ref", "activity_defn_list",
  "activity_defn", "@9", "@10", "activity_conn_list", "activity_conn",
  "join_list", "quorum_count", "and_join_list", "or_join_list",
  "reply_activity", "act_entry_list", "fork_list", "and_fork_list",
  "or_fork_list", "loop_list", "act_prob", "act_count", "activity_id",
  "activity_def", "activity_ref", "activity_obs", "activity_obs_info",
  "act_call_obs", "act_call_obs_info", "opt_report_info", "r_decl_list",
  "r_decl", "opt_convergence_info", "c_decl_list", "c_decl", "real",
  "constant", "integer", "symbol", "rvalue", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,    71,    44,    61,    91,    93,    58,    63,    43,
      45,    42,    47,    37,    40,    41,    80,   112,   100,   102,
     105,   114,   104,    99,   115,    72,   109,    82,    85,   103,
      84,   116,    73,    79,    83,    98,   110,   117,    87,   113,
     122,    69,    97,    65,    70,    77,    86,    88,   121,    90,
      59,    38,    67,   123,   125
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    95,    96,    96,    96,    96,    96,    97,    98,   100,
      99,   101,    99,   102,    99,   103,    99,    99,   104,   105,
     106,   107,   108,   109,   109,   110,   110,   110,   110,   110,
     110,   111,   111,   112,   112,   113,   113,   113,   113,   113,
     114,   114,   115,   115,   116,   116,   117,   117,   117,   117,
     117,   117,   117,   118,   118,   118,   119,   119,   119,   119,
     120,   120,   121,   121,   122,   122,   123,   123,   123,   123,
     123,   124,   124,   125,   126,   127,   127,   128,   130,   129,
     131,   129,   129,   132,   132,   132,   132,   132,   132,   133,
     133,   133,   134,   134,   135,   135,   135,   135,   136,   136,
     136,   137,   137,   138,   139,   139,   141,   140,   142,   143,
     144,   144,   145,   145,   145,   146,   147,   148,   148,   150,
     149,   149,   149,   151,   152,   152,   152,   152,   152,   152,
     152,   152,   152,   152,   152,   153,   153,   154,   155,   155,
     156,   156,   156,   156,   156,   156,   156,   156,   157,   157,
     158,   158,   158,   158,   158,   158,   159,   160,   161,   161,
     162,   162,   162,   162,   162,   162,   162,   162,   162,   162,
     162,   162,   162,   162,   162,   162,   162,   162,   163,   164,
     165,   166,   166,   166,   167,   167,   167,   168,   168,   168,
     169,   170,   171,   171,   171,   172,   172,   172,   173,   173,
     173,   174,   174,   174,   175,   176,   176,   177,   177,   178,
     178,   178,   178,   178,   178,   178,   178,   178,   178,   178,
     178,   178,   178,   178,   178,   179,   179,   180,   180,   180,
     180,   181,   181,   182,   182,   183,   184,   184,   185,   185,
     185,   185,   185,   186,   185,   187,   185,   185,   188,   188,
     189,   189,   190,   190,   190,   191,   191,   192,   192,   193,
     193,   194,   194,   195,   195,   196,   196,   196,   196,   196,
     197,   197,   198,   198,   199,   199,   200,   201,   202,   203,
     204,   205,   205,   206,   206,   206,   206,   206,   206,   206,
     206,   206,   206,   206,   206,   206,   207,   207,   208,   208,
     208,   208,   209,   209,   209,   210,   210,   211,   211,   212,
     212,   213,   213,   214,   214,   215,   215,   215,   215,   216,
     216,   216,   217,   217,   218,   218,   219
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     2,     2,     2,     2,     2,     4,     6,     0,
       9,     0,     8,     0,     7,     0,     5,     0,     1,     1,
       1,     1,     1,     2,     0,     2,     2,     2,     2,     2,
       2,     0,     2,     1,     5,     3,     5,     9,     3,     1,
       5,     1,     3,     1,     3,     1,     3,     3,     3,     3,
       3,     3,     1,     3,     3,     1,     3,     3,     3,     1,
       3,     1,     2,     1,     4,     1,     3,     3,     4,     1,
       1,     1,     3,     4,     1,     1,     2,     1,     0,     6,
       0,     7,     4,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     2,     0,     1,     2,     2,     2,     2,     4,
       0,     4,     0,     1,     2,     1,     0,     7,     1,     1,
       1,     0,     2,     4,     0,     4,     1,     2,     1,     0,
       9,     4,     4,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     2,     1,     2,     0,
       1,     2,     2,     1,     2,     2,     2,     2,     2,     0,
       2,     4,     2,     4,     2,     4,     4,     1,     1,     2,
       4,     3,     4,     3,     5,     3,     4,     3,     2,     2,
       4,     2,     2,     2,     2,     5,     5,     4,     1,     1,
       1,     2,     3,     4,     2,     3,     4,     2,     3,     4,
       5,     1,     2,     3,     4,     2,     3,     4,     2,     3,
       4,     2,     3,     4,     2,     1,     0,     2,     0,     2,
       4,     2,     2,     4,     2,     4,     2,     4,     2,     4,
       2,     4,     2,     4,     2,     2,     0,     2,     4,     2,
       4,     0,     2,     4,     6,     1,     1,     2,     4,     4,
       3,     6,     3,     0,     6,     0,     6,     4,     1,     3,
       1,     3,     1,     4,     3,     3,     0,     1,     3,     1,
       3,     1,     4,     1,     3,     1,     2,     4,     3,     4,
       1,     3,     2,     4,     1,     4,     3,     2,     1,     1,
       1,     2,     0,     2,     4,     2,     4,     2,     4,     2,
       4,     2,     4,     2,     4,     2,     2,     0,     2,     4,
       2,     4,     4,     7,     0,     1,     2,     3,     1,     4,
       0,     1,     2,     3,     1,     1,     1,     1,     3,     1,
       1,     1,     1,     1,     1,     1,     1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       0,    31,    31,     0,     0,     0,     0,     2,    17,     3,
     308,     4,   305,   314,     5,   311,   326,    69,   320,   319,
     321,     0,     0,     6,    55,    59,    61,    63,    65,    70,
       0,     1,     0,    39,     0,   304,     0,    32,    33,     0,
     306,     0,   312,    62,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    18,     0,     0,   310,     0,
     102,   307,    41,    43,    45,    52,   313,    66,    53,    54,
      56,    57,    58,    60,     0,    67,    71,     0,     0,    38,
       0,    35,    15,   317,   316,   315,     0,     0,    19,     0,
       0,     7,    74,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    64,     0,    68,     0,     0,
      70,    24,     0,   323,   322,     0,    20,     0,     0,     0,
       0,     0,     0,    75,   103,     0,     0,     0,    42,     0,
      44,    49,    48,    47,    51,    46,    50,    72,    34,    36,
       0,     0,     0,     0,     0,     0,     0,    16,    24,   318,
      13,   323,   322,     0,     0,    22,    21,   302,     0,     0,
     324,   325,     0,    77,     0,    73,    76,     0,     0,   105,
     116,     0,     0,   231,     0,     0,    26,    25,    27,    28,
      29,    30,    23,    24,     0,    11,     0,   309,    91,    87,
      83,    84,    85,    86,    88,    89,    90,    78,     0,     0,
       0,   108,   101,   104,     0,     0,     0,     0,   118,   157,
       0,     8,    40,     0,    14,     9,    24,     0,    93,    80,
      82,   111,   109,     0,   123,     0,     0,   115,   117,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   158,     0,
     232,     0,    24,    12,   303,    94,     0,     0,     0,   100,
      93,    93,   110,     0,   124,   131,   127,   129,   132,   128,
     125,   126,   130,   133,   134,     0,     0,     0,   178,   169,
     137,     0,     0,     0,     0,     0,   168,   171,   173,     0,
       0,     0,     0,     0,   172,   174,     0,     0,   156,   159,
     235,     0,    37,    10,    96,    95,    97,     0,    79,    92,
     100,   106,     0,   135,   121,   122,   191,   167,     0,   163,
     208,     0,   208,     0,     0,   165,   179,     0,   208,   180,
     161,     0,   208,     0,     0,   208,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   236,    98,     0,    81,
     114,     0,   136,   184,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   162,   208,   181,     0,   170,   192,
       0,     0,   226,     0,   160,   226,     0,   166,   187,     0,
     226,     0,   177,   201,     0,   279,     0,   278,     0,     0,
       0,     0,     0,     0,     0,   233,     0,   237,     0,     0,
     107,   119,   185,     0,   212,     0,   209,     0,   214,     0,
     218,     0,   220,     0,   211,   216,     0,   222,     0,   224,
     207,   182,     0,   193,     0,     0,     0,     0,   176,   226,
     198,     0,   164,   204,   188,     0,   175,   195,     0,   202,
       0,   240,   282,   282,     0,     0,   242,     0,   282,     0,
     248,   250,     0,     0,   252,   280,   261,    99,   112,     0,
     139,   186,     0,     0,     0,     0,     0,     0,     0,   183,
     194,   206,   227,     0,   229,     0,   225,   199,     0,   189,
     196,     0,   203,     0,     0,     0,     0,     0,     0,     0,
     239,   282,   238,     0,   245,   243,   247,   234,     0,     0,
       0,     0,     0,     0,   143,     0,     0,     0,     0,     0,
       0,   149,   139,   140,   213,   210,   215,   219,   221,   217,
     223,   205,   190,     0,     0,   200,   197,   285,     0,   283,
       0,   287,     0,   291,     0,   293,     0,   289,     0,   295,
     281,   206,   297,   297,   249,   325,     0,   251,     0,     0,
       0,   265,     0,   256,   254,   263,     0,   113,   146,   144,
     142,   141,   145,   147,     0,     0,     0,   120,   149,   138,
     228,   230,     0,     0,     0,     0,     0,     0,   241,     0,
       0,   246,   297,   244,     0,     0,     0,   266,   277,     0,
     253,     0,   262,   152,     0,   150,     0,   154,     0,   148,
     286,   284,   288,   292,   294,   290,   298,     0,   300,     0,
     296,   276,   268,     0,     0,     0,   264,     0,     0,     0,
       0,     0,   269,     0,   267,   274,   255,   153,   151,   155,
     299,   301,     0,   272,     0,     0,     0,   273,   275
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     6,     7,    35,    36,   252,   216,   183,   111,    56,
      87,   115,   153,   154,   147,   148,     8,    37,    38,    61,
      62,    63,    64,    65,    24,    25,    26,    27,    28,    77,
      60,    93,   122,   162,   123,   218,   261,   197,   198,   259,
     260,   308,    95,   125,   168,   169,   350,   200,   221,   263,
     400,   127,   171,   207,   208,   460,   223,   275,   312,   278,
     511,   512,   567,   568,   173,   210,   247,   248,   279,   327,
     328,   320,   319,   332,   325,   317,   322,   380,   372,   335,
     375,   522,   364,   365,   428,   429,   211,   250,   301,   345,
     346,   543,   542,   449,   450,   451,   590,   452,   453,   454,
     556,   547,   548,   622,   624,   549,   550,   455,   386,   456,
     490,   491,   581,   582,    58,    11,    12,    91,    14,    15,
     155,    29,   513,   280,    30
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -562
static const yytype_int16 yypact[] =
{
     371,  -562,  -562,    51,    57,   374,    98,  -562,   146,   155,
      35,    51,  -562,    77,    57,  -562,  -562,  -562,  -562,  -562,
    -562,   290,   374,   328,   124,  -562,    94,   105,  -562,  -562,
     144,  -562,   435,  -562,   181,   147,   180,  -562,  -562,   374,
    -562,   374,  -562,   105,   238,   374,   374,   374,   374,   374,
     374,   374,   249,   226,   387,  -562,    27,   233,   174,   261,
     211,  -562,   103,   251,   342,   328,  -562,  -562,   124,   124,
    -562,  -562,  -562,  -562,   301,  -562,   328,     0,   247,  -562,
     374,  -562,  -562,  -562,  -562,  -562,   374,   216,  -562,   425,
     299,  -562,  -562,   431,   303,   246,   374,   374,   374,   374,
     374,   374,   374,   374,   374,  -562,   374,  -562,   374,   172,
     276,   215,    66,  -562,  -562,    44,  -562,   220,   286,    57,
      96,    96,     1,  -562,  -562,   326,   321,   287,   251,    60,
     342,   328,   328,   328,   328,   328,   328,   328,  -562,  -562,
     442,   397,   410,   452,   456,   488,   496,  -562,   215,  -562,
    -562,   414,   523,    81,   528,  -562,  -562,  -562,   374,   353,
    -562,  -562,   474,  -562,    96,  -562,  -562,    96,    28,  -562,
    -562,   401,   497,  -562,   374,   534,  -562,  -562,  -562,  -562,
    -562,  -562,  -562,   215,   536,  -562,    59,  -562,  -562,  -562,
    -562,  -562,  -562,  -562,  -562,  -562,  -562,  -562,    81,    81,
      81,  -562,  -562,  -562,    96,    96,    96,   191,  -562,  -562,
     381,   508,   557,   442,  -562,  -562,   215,   589,   288,  -562,
    -562,   531,  -562,   448,  -562,    96,    96,  -562,  -562,    96,
      96,    96,    96,    96,    96,    96,    96,    96,    96,    96,
      96,    96,    96,    96,    96,    96,    96,   278,  -562,    96,
    -562,   549,   215,  -562,  -562,  -562,   216,   216,    81,   583,
     288,   288,  -562,    96,  -562,  -562,  -562,  -562,  -562,  -562,
    -562,  -562,  -562,  -562,  -562,    96,   216,   216,  -562,  -562,
    -562,   588,   590,    81,    81,   591,  -562,  -562,  -562,    96,
      81,    96,    96,   442,  -562,  -562,    96,    81,  -562,  -562,
    -562,   412,  -562,  -562,  -562,  -562,  -562,   304,  -562,  -562,
     583,  -562,   322,  -562,  -562,  -562,  -562,  -562,   149,  -562,
     467,    56,   467,    72,   442,  -562,  -562,    81,   467,  -562,
    -562,    81,   467,   377,    81,   467,    79,    96,    96,    96,
      96,    96,    96,    96,    96,   209,  -562,  -562,   592,  -562,
     593,    96,  -562,  -562,   208,   315,   330,   408,   416,   418,
     595,   420,   433,   596,  -562,   467,  -562,    90,  -562,  -562,
     130,   556,   492,   158,  -562,   492,   600,  -562,  -562,   390,
     492,   176,  -562,  -562,   183,  -562,   598,  -562,    81,    81,
     442,    96,   442,    96,    81,  -562,    96,  -562,   599,   441,
    -562,  -562,  -562,   604,  -562,   603,  -562,   605,  -562,   606,
    -562,   607,  -562,   608,  -562,  -562,   609,  -562,   610,  -562,
    -562,  -562,   613,  -562,   614,   442,   451,   489,  -562,   492,
    -562,   190,  -562,  -562,  -562,   615,  -562,  -562,   197,  -562,
     616,  -562,   502,   502,   574,    81,  -562,    81,   502,   618,
     520,   611,   533,   576,   -14,  -562,   581,  -562,  -562,   621,
     150,  -562,   622,   623,   624,   625,   626,   627,   628,  -562,
    -562,   629,  -562,   630,  -562,   631,  -562,  -562,   635,  -562,
    -562,   636,  -562,   490,   505,   552,   553,   554,   558,   637,
    -562,   502,  -562,   442,  -562,  -562,  -562,  -562,    96,   199,
      96,    96,    96,   638,  -562,   216,   216,    96,   632,   216,
      81,   567,   150,  -562,  -562,  -562,  -562,  -562,  -562,  -562,
    -562,  -562,  -562,   639,   640,  -562,  -562,  -562,   641,  -562,
     642,  -562,   643,  -562,   644,  -562,   645,  -562,   646,  -562,
    -562,   629,   563,   563,  -562,   584,    81,  -562,   551,    96,
      96,   562,   612,    -5,   617,  -562,   522,  -562,  -562,  -562,
    -562,  -562,  -562,  -562,   560,   564,   565,  -562,   567,  -562,
    -562,  -562,   648,   649,   650,   651,   652,   653,  -562,   566,
     570,  -562,   563,  -562,   619,    96,   620,   633,  -562,   216,
    -562,    96,  -562,  -562,   654,  -562,   655,  -562,   656,  -562,
    -562,  -562,  -562,  -562,  -562,  -562,  -562,   658,  -562,   659,
    -562,  -562,   577,   634,    96,   647,  -562,   661,   664,   665,
     666,   667,   657,    96,   660,  -562,  -562,  -562,  -562,  -562,
    -562,  -562,   634,  -562,    81,    96,    96,  -562,  -562
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -562,  -562,  -562,  -562,  -562,  -562,  -562,  -562,  -562,  -562,
    -562,  -562,  -562,   524,  -144,  -562,   673,  -562,  -562,    65,
     -57,   582,   585,    23,   540,   386,  -562,   663,  -562,   -74,
    -562,  -562,  -562,  -118,   559,  -562,  -562,  -562,  -562,   327,
    -562,   369,  -562,  -562,  -562,   512,  -562,   175,  -562,  -562,
    -562,  -562,  -562,  -562,   478,  -562,    80,  -562,  -562,  -245,
     177,  -562,   118,  -562,  -562,  -562,  -562,   440,  -221,  -258,
    -562,  -562,  -562,  -562,  -562,  -562,  -562,  -562,  -562,  -562,
    -562,   151,   -13,  -562,  -311,  -562,  -562,  -562,  -562,  -562,
     345,  -562,  -562,   193,  -562,  -562,  -562,  -562,  -562,    89,
    -562,  -562,  -562,  -562,  -562,  -561,    61,   206,   213,  -457,
    -387,  -562,  -502,  -562,  -562,   662,    -4,  -562,   575,   -12,
     -56,   -72,   -86,   -94,   668
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -318
static const yytype_int16 yytable[] =
{
      88,   116,    42,   164,   182,   165,   109,    40,   110,   281,
     282,   283,   284,   285,   286,   287,   288,   289,   290,   291,
     292,   293,   294,   295,   296,   297,   163,   163,    23,   156,
     313,    82,   202,    83,   331,  -259,    84,    85,   334,   214,
     129,   583,   551,   106,   326,    44,   199,   326,   150,   589,
     151,   326,   623,   152,    85,   107,   492,    10,   120,   121,
     366,   496,    83,    13,   432,    84,    85,   352,   175,   436,
     163,   635,   253,   201,    74,    76,   369,  -257,    83,    39,
     610,    84,    85,   383,   186,    83,  -258,    83,    84,    85,
      84,    85,   586,   587,   421,    96,    83,   167,    31,    84,
      85,   160,   106,    76,   540,   161,    66,   174,   303,   112,
     224,   224,   224,    40,   217,    45,    46,   212,   476,    81,
      86,    41,   131,   132,   133,   134,   135,   136,   612,   137,
      50,   224,   224,   445,   423,   447,    83,    86,    96,    84,
      85,   251,   219,   220,   222,   311,   326,    42,   326,    86,
      51,    97,    32,   353,    33,   224,   113,   625,   354,   114,
     149,    32,   430,    33,    83,    86,   633,    84,    85,   163,
     304,   305,    86,   138,    86,    47,    48,    49,   637,   638,
     437,    76,    83,    86,    55,    84,    85,   439,    34,    83,
     314,   315,    84,    85,   477,   227,    83,   330,    52,    84,
      85,   480,   306,    83,   160,    83,    84,    85,   545,    85,
     504,   505,   402,   395,    57,   106,   506,   403,   139,   507,
     508,   333,   113,    86,   157,   114,    10,   321,   323,   509,
     510,   141,    78,   401,   329,   142,    59,   143,   144,   145,
     146,   336,    89,   387,   387,   387,   387,   387,   387,   387,
     387,    86,   371,   546,    16,    17,   396,   163,    18,    19,
      20,   379,   204,   205,   206,   367,    90,   370,   337,    86,
      92,   373,   338,   339,   340,   376,    86,    21,   381,    94,
     384,   555,   298,    86,    98,   225,   226,    45,    46,   341,
      86,   108,    86,    67,   342,    16,    17,   343,   344,    18,
      19,    20,   387,    22,    75,   276,   277,   435,   119,   368,
     347,   422,   124,   348,   424,   374,   126,   431,   444,   377,
     446,   404,   382,   140,   405,   438,   351,   160,   440,   300,
     170,   161,   442,   443,   229,   230,   406,   231,   448,   407,
     158,   232,   233,   234,    22,   235,   236,   105,   255,   256,
      45,    46,   420,   471,   257,   258,   237,   187,   238,    13,
     239,   240,   241,   242,   243,   244,   245,   246,   172,    99,
     616,   100,   101,   102,   103,   478,   104,    45,    46,    16,
      17,   378,   481,    18,    19,    20,    18,    19,    20,   494,
      79,   495,    16,    17,   434,   167,    18,    19,    20,    18,
      19,    20,    21,   176,   387,   387,   387,   387,     1,     2,
       3,     4,     5,   201,   408,    21,   177,   409,  -317,   558,
     559,   541,   410,   562,   412,   411,   415,   413,    22,   416,
      16,    10,    80,    70,    71,    72,    73,   229,   230,   417,
     231,    22,   418,   552,   232,   233,   234,   458,   235,   236,
     459,    18,    19,    20,   563,   387,   387,   472,   178,   237,
     473,   238,   179,   239,   240,   241,   242,   243,   244,   245,
     246,   337,   204,   205,   206,   338,   339,   340,    53,    54,
     355,   356,   357,   358,   359,   360,   361,   362,   120,   121,
     584,   387,   341,   363,   180,   474,   527,   342,   475,   528,
     343,   344,   181,   615,   264,   265,   209,   266,   267,   268,
     269,   529,   426,   427,   530,   483,   484,   485,   486,   487,
     387,   488,   270,   271,   272,   273,   274,  -316,   489,   387,
     188,   189,   185,   190,   191,   192,   193,   194,   195,   196,
     215,   387,   387,   385,   385,   385,   385,   385,   385,   385,
     385,   388,   389,   390,   391,   392,   393,   394,   531,   533,
     535,   532,   534,   536,   537,   591,   593,   538,   592,   594,
     595,   597,   606,   596,   598,   607,   608,   213,   552,   609,
     564,   565,   566,   579,   580,    68,    69,   309,   310,   553,
     554,   249,    96,   254,   262,   302,   307,   316,   398,   318,
     324,   414,   419,   425,   433,   457,   399,   441,   461,   462,
     498,   463,   464,   465,   466,   467,   468,   469,   470,   479,
     482,   493,   497,   499,   500,   501,   502,   503,   514,   515,
     516,   517,   518,   519,   520,  -316,   523,   524,   521,   525,
     526,   561,   585,   539,   557,   570,   571,   572,   573,   574,
     575,   576,   577,  -270,   600,   601,   602,   603,   604,   605,
     617,   618,   619,   588,   620,   621,  -260,   627,  -271,   613,
     628,   629,   630,   631,   611,     9,   614,   184,   128,   349,
     203,   166,   560,   130,    43,   228,   599,   299,   546,   569,
     397,   544,   578,     0,   159,   636,     0,     0,     0,     0,
       0,     0,   626,   634,     0,     0,   632,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   117,     0,     0,     0,     0,     0,   118
};

static const yytype_int16 yycheck[] =
{
      56,    87,    14,   121,   148,     4,    80,    11,    80,   230,
     231,   232,   233,   234,   235,   236,   237,   238,   239,   240,
     241,   242,   243,   244,   245,   246,   120,   121,     5,   115,
     275,     4,     4,     6,   292,    49,     9,    10,   296,   183,
      97,   543,   499,    43,   289,    22,   164,   292,     4,    54,
       6,   296,   613,     9,    10,    55,   443,     6,    57,    58,
       4,   448,     6,     6,   375,     9,    10,   312,   140,   380,
     164,   632,   216,   167,    51,    52,     4,    91,     6,    44,
     582,     9,    10,     4,   158,     6,    91,     6,     9,    10,
       9,    10,   549,   550,     4,    35,     6,    69,     0,     9,
      10,     5,    43,    80,   491,     9,    41,    47,   252,    86,
     204,   205,   206,   117,    55,    49,    50,   174,   429,    54,
      93,    44,    99,   100,   101,   102,   103,   104,   585,   106,
      36,   225,   226,   391,     4,   393,     6,    93,    35,     9,
      10,   213,   198,   199,   200,   263,   391,   159,   393,    93,
      45,    48,     6,     4,     8,   249,     6,   614,     9,     9,
      94,     6,     4,     8,     6,    93,   623,     9,    10,   263,
     256,   257,    93,   108,    93,    51,    52,    53,   635,   636,
       4,   158,     6,    93,     3,     9,    10,     4,    42,     6,
     276,   277,     9,    10,     4,     4,     6,   291,    54,     9,
      10,     4,   258,     6,     5,     6,     9,    10,     9,    10,
      60,    61,     4,     4,    67,    43,    66,     9,    46,    69,
      70,   293,     6,    93,     4,     9,     6,   283,   284,    79,
      80,    16,     6,   351,   290,    20,    56,    22,    23,    24,
      25,   297,     9,   337,   338,   339,   340,   341,   342,   343,
     344,    93,   324,    54,     5,     6,    47,   351,     9,    10,
      11,   333,    71,    72,    73,   321,    92,   323,    59,    93,
       9,   327,    63,    64,    65,   331,    93,    28,   334,    68,
     336,   502,     4,    93,    33,   205,   206,    49,    50,    80,
      93,    44,    93,    55,    85,     5,     6,    88,    89,     9,
      10,    11,   396,    54,    55,   225,   226,   379,     9,   322,
       6,   367,     9,     9,   370,   328,    70,   373,   390,   332,
     392,     6,   335,    47,     9,   381,     4,     5,   384,   249,
       9,     9,   388,   389,    56,    57,     6,    59,   394,     9,
      54,    63,    64,    65,    54,    67,    68,    46,    60,    61,
      49,    50,   365,   425,    66,    67,    78,     4,    80,     6,
      82,    83,    84,    85,    86,    87,    88,    89,    81,    27,
     591,    29,    30,    31,    32,   431,    34,    49,    50,     5,
       6,     4,   438,     9,    10,    11,     9,    10,    11,   445,
       3,   447,     5,     6,     4,    69,     9,    10,    11,     9,
      10,    11,    28,     6,   498,   499,   500,   501,    37,    38,
      39,    40,    41,   507,     6,    28,     6,     9,     4,   505,
     506,   493,     6,   509,     6,     9,     6,     9,    54,     9,
       5,     6,    45,    47,    48,    49,    50,    56,    57,     6,
      59,    54,     9,   499,    63,    64,    65,     6,    67,    68,
       9,     9,    10,    11,   510,   549,   550,     6,     6,    78,
       9,    80,     6,    82,    83,    84,    85,    86,    87,    88,
      89,    59,    71,    72,    73,    63,    64,    65,    43,    44,
      13,    14,    15,    16,    17,    18,    19,    20,    57,    58,
     546,   585,    80,    26,     6,     6,     6,    85,     9,     9,
      88,    89,     6,   589,    56,    57,     9,    59,    60,    61,
      62,     6,    20,    21,     9,    13,    14,    15,    16,    17,
     614,    19,    74,    75,    76,    77,    78,     4,    26,   623,
      56,    57,     4,    59,    60,    61,    62,    63,    64,    65,
       4,   635,   636,   337,   338,   339,   340,   341,   342,   343,
     344,   338,   339,   340,   341,   342,   343,   344,     6,     6,
       6,     9,     9,     9,     6,    43,     6,     9,    46,     9,
       6,     6,     6,     9,     9,     9,     6,    43,   634,     9,
      13,    14,    15,    20,    21,    45,    46,   260,   261,   500,
     501,    83,    35,     4,    63,    46,    13,     9,     6,     9,
       9,     6,     6,    47,     4,     6,    13,     9,     4,     6,
      90,     6,     6,     6,     6,     6,     6,     4,     4,     4,
       4,    47,     4,    12,    91,    49,    45,     6,     6,     6,
       6,     6,     6,     6,     6,    51,     6,     6,     9,     4,
       4,     9,    91,     6,     6,     6,     6,     6,     6,     6,
       6,     6,     6,    91,     6,     6,     6,     6,     6,     6,
       6,     6,     6,    51,     6,     6,    49,     6,    91,    49,
       6,     6,     6,     6,    55,     2,    43,   153,    96,   310,
     168,   122,   507,    98,    21,   207,   568,   247,    54,   512,
     345,   498,   541,    -1,   119,   634,    -1,    -1,    -1,    -1,
      -1,    -1,    55,    43,    -1,    -1,    49,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    89,    -1,    -1,    -1,    -1,    -1,    89
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,    37,    38,    39,    40,    41,    96,    97,   111,   111,
       6,   210,   211,     6,   213,   214,     5,     6,     9,    10,
      11,    28,    54,   118,   119,   120,   121,   122,   123,   216,
     219,     0,     6,     8,    42,    98,    99,   112,   113,    44,
     211,    44,   214,   122,   118,    49,    50,    51,    52,    53,
      36,    45,    54,    43,    44,     3,   104,    67,   209,    56,
     125,   114,   115,   116,   117,   118,   114,    55,   119,   119,
     120,   120,   120,   120,   118,    55,   118,   124,     6,     3,
      45,   114,     4,     6,     9,    10,    93,   105,   215,     9,
      92,   212,     9,   126,    68,   137,    35,    48,    33,    27,
      29,    30,    31,    32,    34,    46,    43,    55,    44,   124,
     216,   103,   118,     6,     9,   106,   217,   210,   219,     9,
      57,    58,   127,   129,     9,   138,    70,   146,   116,   115,
     117,   118,   118,   118,   118,   118,   118,   118,   114,    46,
      47,    16,    20,    22,    23,    24,    25,   109,   110,    94,
       4,     6,     9,   107,   108,   215,   217,     4,    54,   213,
       5,     9,   128,   218,   128,     4,   129,    69,   139,   140,
       9,   147,    81,   159,    47,   216,     6,     6,     6,     6,
       6,     6,   109,   102,   108,     4,   124,     4,    56,    57,
      59,    60,    61,    62,    63,    64,    65,   132,   133,   128,
     142,   218,     4,   140,    71,    72,    73,   148,   149,     9,
     160,   181,   115,    43,   109,     4,   101,    55,   130,   215,
     215,   143,   215,   151,   218,   151,   151,     4,   149,    56,
      57,    59,    63,    64,    65,    67,    68,    78,    80,    82,
      83,    84,    85,    86,    87,    88,    89,   161,   162,    83,
     182,   216,   100,   109,     4,    60,    61,    66,    67,   134,
     135,   131,    63,   144,    56,    57,    59,    60,    61,    62,
      74,    75,    76,    77,    78,   152,   151,   151,   154,   163,
     218,   163,   163,   163,   163,   163,   163,   163,   163,   163,
     163,   163,   163,   163,   163,   163,   163,   163,     4,   162,
     151,   183,    46,   109,   217,   217,   215,    13,   136,   134,
     134,   128,   153,   154,   217,   217,     9,   170,     9,   167,
     166,   215,   171,   215,     9,   169,   154,   164,   165,   215,
     218,   164,   168,   216,   164,   174,   215,    59,    63,    64,
      65,    80,    85,    88,    89,   184,   185,     6,     9,   136,
     141,     4,   154,     4,     9,    13,    14,    15,    16,    17,
      18,    19,    20,    26,   177,   178,     4,   215,   177,     4,
     215,   216,   173,   215,   177,   175,   215,   177,     4,   216,
     172,   215,   177,     4,   215,   202,   203,   218,   203,   203,
     203,   203,   203,   203,   203,     4,    47,   185,     6,    13,
     145,   128,     4,     9,     6,     9,     6,     9,     6,     9,
       6,     9,     6,     9,     6,     6,     9,     6,     9,     6,
     177,     4,   215,     4,   215,    47,    20,    21,   179,   180,
       4,   215,   179,     4,     4,   216,   179,     4,   215,     4,
     215,     9,   215,   215,   216,   164,   216,   164,   215,   188,
     189,   190,   192,   193,   194,   202,   204,     6,     6,     9,
     150,     4,     6,     6,     6,     6,     6,     6,     6,     4,
       4,   216,     6,     9,     6,     9,   179,     4,   215,     4,
       4,   215,     4,    13,    14,    15,    16,    17,    19,    26,
     205,   206,   205,    47,   215,   215,   205,     4,    90,    12,
      91,    49,    45,     6,    60,    61,    66,    69,    70,    79,
      80,   155,   156,   217,     6,     6,     6,     6,     6,     6,
       6,     9,   176,     6,     6,     4,     4,     6,     9,     6,
       9,     6,     9,     6,     9,     6,     9,     6,     9,     6,
     205,   216,   187,   186,   188,     9,    54,   196,   197,   200,
     201,   204,   215,   194,   194,   163,   195,     6,   217,   217,
     142,     9,   217,   215,    13,    14,    15,   157,   158,   155,
       6,     6,     6,     6,     6,     6,     6,     6,   176,    20,
      21,   207,   208,   207,   215,    91,   204,   204,    51,    54,
     191,    43,    46,     6,     9,     6,     9,     6,     9,   157,
       6,     6,     6,     6,     6,     6,     6,     9,     6,     9,
     207,    55,   204,    49,    43,   217,   163,     6,     6,     6,
       6,     6,   198,   200,   199,   204,    55,     6,     6,     6,
       6,     6,    49,   204,    43,   200,   201,   204,   204
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 3:
#line 78 "srvn_gram.y"
    { spex_set_parameter_list( (yyvsp[(2) - (2)].aParseTreeList) ); }
    break;

  case 4:
#line 79 "srvn_gram.y"
    { spex_set_result_list( (yyvsp[(2) - (2)].aParseTreeList) ); }
    break;

  case 5:
#line 80 "srvn_gram.y"
    { spex_set_convergence_list( (yyvsp[(2) - (2)].aParseTreeList) ); }
    break;

  case 6:
#line 81 "srvn_gram.y"
    { spex_set_variable( spex_inline_expression( (yyvsp[(2) - (2)].aParseTreeNode) ) ) ; }
    break;

  case 7:
#line 90 "srvn_gram.y"
    { spex_set_program( (yyvsp[(1) - (4)].aParseTreeList), (yyvsp[(3) - (4)].aParseTreeNode), (yyvsp[(4) - (4)].aParseTreeList) ); }
    break;

  case 9:
#line 99 "srvn_gram.y"
    { srvn_set_model_parameters( (yyvsp[(2) - (7)].aString), (yyvsp[(3) - (7)].aVariable), (yyvsp[(4) - (7)].aVariable), (yyvsp[(5) - (7)].aVariable), (yyvsp[(6) - (7)].aVariable) ); free( (yyvsp[(2) - (7)].aString) ); }
    break;

  case 11:
#line 102 "srvn_gram.y"
    { srvn_set_model_parameters( (yyvsp[(2) - (6)].aString), (yyvsp[(3) - (6)].aVariable), (yyvsp[(4) - (6)].aVariable), 0, (yyvsp[(5) - (6)].aVariable) ); free( (yyvsp[(2) - (6)].aString) ); }
    break;

  case 13:
#line 105 "srvn_gram.y"
    { srvn_set_model_parameters( (yyvsp[(2) - (5)].aString), (yyvsp[(3) - (5)].aVariable), (yyvsp[(4) - (5)].aVariable), 0, 0 ); free( (yyvsp[(2) - (5)].aString) ); }
    break;

  case 15:
#line 108 "srvn_gram.y"
    { srvn_set_model_parameters( (yyvsp[(2) - (3)].aString), 0, 0, 0, 0 ); free( (yyvsp[(2) - (3)].aString) ); }
    break;

  case 17:
#line 111 "srvn_gram.y"
    { srvn_set_model_parameters( "", 0, 0, 0, 0 ); }
    break;

  case 25:
#line 135 "srvn_gram.y"
    { spex_document_observation( KEY_WAITING, (yyvsp[(2) - (2)].aString) ); }
    break;

  case 26:
#line 136 "srvn_gram.y"
    { spex_document_observation( KEY_SERVICE_TIME, (yyvsp[(2) - (2)].aString) ); }
    break;

  case 27:
#line 137 "srvn_gram.y"
    { spex_document_observation( KEY_ITERATIONS, (yyvsp[(2) - (2)].aString) ); }
    break;

  case 28:
#line 138 "srvn_gram.y"
    { spex_document_observation( KEY_ELAPSED_TIME, (yyvsp[(2) - (2)].aString) ); }
    break;

  case 29:
#line 139 "srvn_gram.y"
    { spex_document_observation( KEY_USER_TIME, (yyvsp[(2) - (2)].aString) ); }
    break;

  case 30:
#line 140 "srvn_gram.y"
    { spex_document_observation( KEY_SYSTEM_TIME, (yyvsp[(2) - (2)].aString) ); }
    break;

  case 31:
#line 148 "srvn_gram.y"
    { (yyval.aParseTreeList) = 0; }
    break;

  case 32:
#line 149 "srvn_gram.y"
    { (yyval.aParseTreeList) = spex_list( (yyvsp[(1) - (2)].aParseTreeList), (yyvsp[(2) - (2)].aParseTreeNode) ); }
    break;

  case 33:
#line 152 "srvn_gram.y"
    { (yyval.aParseTreeNode) = (yyvsp[(1) - (1)].aParseTreeNode); }
    break;

  case 34:
#line 153 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_forall( (yyvsp[(1) - (5)].aString), (yyvsp[(3) - (5)].aString), (yyvsp[(5) - (5)].aParseTreeNode) ); }
    break;

  case 35:
#line 156 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_assignment_statement( (yyvsp[(1) - (3)].aString), (yyvsp[(3) - (3)].aParseTreeNode), constant_expression ); constant_expression = true; }
    break;

  case 36:
#line 157 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_array_assignment( (yyvsp[(1) - (5)].aString), (yyvsp[(4) - (5)].aParseTreeList), constant_expression ); constant_expression = true; }
    break;

  case 37:
#line 159 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_array_comprehension( (yyvsp[(1) - (9)].aString), (yyvsp[(4) - (9)].aFloat), (yyvsp[(6) - (9)].aFloat), (yyvsp[(8) - (9)].aFloat) ); constant_expression = true; }
    break;

  case 38:
#line 160 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_assignment_statement( (yyvsp[(1) - (3)].aString), spex_get_string( (yyvsp[(3) - (3)].aString) ), true ); free( (yyvsp[(3) - (3)].aString) ); }
    break;

  case 39:
#line 161 "srvn_gram.y"
    { srvnwarning( "Spex control variable \"%s\" is not supported.", (yyvsp[(1) - (1)].aString) ); (yyval.aParseTreeNode) = 0; }
    break;

  case 40:
#line 164 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_ternary( (yyvsp[(1) - (5)].aParseTreeNode), (yyvsp[(3) - (5)].aParseTreeNode), (yyvsp[(5) - (5)].aParseTreeNode) ); }
    break;

  case 41:
#line 165 "srvn_gram.y"
    { (yyval.aParseTreeNode) = (yyvsp[(1) - (1)].aParseTreeNode); }
    break;

  case 42:
#line 168 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_or( (yyvsp[(1) - (3)].aParseTreeNode), (yyvsp[(3) - (3)].aParseTreeNode) ); }
    break;

  case 43:
#line 169 "srvn_gram.y"
    { (yyval.aParseTreeNode) = (yyvsp[(1) - (1)].aParseTreeNode); }
    break;

  case 44:
#line 171 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_and( (yyvsp[(1) - (3)].aParseTreeNode), (yyvsp[(3) - (3)].aParseTreeNode) ); }
    break;

  case 45:
#line 172 "srvn_gram.y"
    { (yyval.aParseTreeNode) = (yyvsp[(1) - (1)].aParseTreeNode); }
    break;

  case 46:
#line 175 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_equals( (yyvsp[(1) - (3)].aParseTreeNode), (yyvsp[(3) - (3)].aParseTreeNode) ); }
    break;

  case 47:
#line 176 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_not_equals( (yyvsp[(1) - (3)].aParseTreeNode), (yyvsp[(3) - (3)].aParseTreeNode) ); }
    break;

  case 48:
#line 177 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_less_than( (yyvsp[(1) - (3)].aParseTreeNode), (yyvsp[(3) - (3)].aParseTreeNode) ); }
    break;

  case 49:
#line 178 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_less_than_or_equals( (yyvsp[(1) - (3)].aParseTreeNode), (yyvsp[(3) - (3)].aParseTreeNode) ); }
    break;

  case 50:
#line 179 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_greater_than( (yyvsp[(1) - (3)].aParseTreeNode), (yyvsp[(3) - (3)].aParseTreeNode) ); }
    break;

  case 51:
#line 180 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_greater_than_or_equals( (yyvsp[(1) - (3)].aParseTreeNode), (yyvsp[(3) - (3)].aParseTreeNode) ); }
    break;

  case 52:
#line 181 "srvn_gram.y"
    { (yyval.aParseTreeNode) = (yyvsp[(1) - (1)].aParseTreeNode); }
    break;

  case 53:
#line 184 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_add( (yyvsp[(1) - (3)].aParseTreeNode), (yyvsp[(3) - (3)].aParseTreeNode) ); }
    break;

  case 54:
#line 185 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_subtract( (yyvsp[(1) - (3)].aParseTreeNode), (yyvsp[(3) - (3)].aParseTreeNode) ); }
    break;

  case 55:
#line 186 "srvn_gram.y"
    { (yyval.aParseTreeNode) = (yyvsp[(1) - (1)].aParseTreeNode); }
    break;

  case 56:
#line 189 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_multiply( (yyvsp[(1) - (3)].aParseTreeNode), (yyvsp[(3) - (3)].aParseTreeNode) ); }
    break;

  case 57:
#line 190 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_divide( (yyvsp[(1) - (3)].aParseTreeNode), (yyvsp[(3) - (3)].aParseTreeNode) ); }
    break;

  case 58:
#line 191 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_modulus( (yyvsp[(1) - (3)].aParseTreeNode), (yyvsp[(3) - (3)].aParseTreeNode) ); }
    break;

  case 59:
#line 192 "srvn_gram.y"
    { (yyval.aParseTreeNode) = (yyvsp[(1) - (1)].aParseTreeNode); }
    break;

  case 60:
#line 195 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_power( (yyvsp[(1) - (3)].aParseTreeNode), (yyvsp[(3) - (3)].aParseTreeNode) ); }
    break;

  case 61:
#line 196 "srvn_gram.y"
    { (yyval.aParseTreeNode) = (yyvsp[(1) - (1)].aParseTreeNode); }
    break;

  case 62:
#line 199 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_not( (yyvsp[(2) - (2)].aParseTreeNode) ); }
    break;

  case 63:
#line 200 "srvn_gram.y"
    { (yyval.aParseTreeNode) = (yyvsp[(1) - (1)].aParseTreeNode); }
    break;

  case 64:
#line 203 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_array_reference( (yyvsp[(1) - (4)].aParseTreeNode), (yyvsp[(3) - (4)].aParseTreeNode) ); }
    break;

  case 66:
#line 207 "srvn_gram.y"
    { (yyval.aParseTreeNode) = (yyvsp[(2) - (3)].aParseTreeNode); }
    break;

  case 67:
#line 208 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_invoke_function( (yyvsp[(1) - (3)].aVariable), 0 ); }
    break;

  case 68:
#line 209 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_invoke_function( (yyvsp[(1) - (4)].aVariable), (yyvsp[(3) - (4)].aParseTreeList) ); }
    break;

  case 69:
#line 210 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_get_symbol( (yyvsp[(1) - (1)].aString) ); constant_expression = false; }
    break;

  case 70:
#line 211 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_get_real( (yyvsp[(1) - (1)].aFloat) ); }
    break;

  case 71:
#line 214 "srvn_gram.y"
    { (yyval.aParseTreeList) = spex_list( 0, (yyvsp[(1) - (1)].aParseTreeNode) ); }
    break;

  case 72:
#line 215 "srvn_gram.y"
    { (yyval.aParseTreeList) = spex_list( (yyvsp[(1) - (3)].aParseTreeList), (yyvsp[(3) - (3)].aParseTreeNode) ); }
    break;

  case 78:
#line 236 "srvn_gram.y"
    { curr_proc = srvn_add_processor( (yyvsp[(2) - (3)].aString), (yyvsp[(3) - (3)].schedulingFlag), NULL ); (void) free( (yyvsp[(2) - (3)].aString) );	}
    break;

  case 80:
#line 239 "srvn_gram.y"
    { curr_proc = srvn_add_processor( (yyvsp[(2) - (4)].aString), (yyvsp[(3) - (4)].schedulingFlag), (yyvsp[(4) - (4)].aVariable) ); (void) free( (yyvsp[(2) - (4)].aString) );	}
    break;

  case 82:
#line 242 "srvn_gram.y"
    { srvn_add_communication_delay( (yyvsp[(2) - (4)].aString), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aVariable) ); }
    break;

  case 83:
#line 245 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_FIFO; }
    break;

  case 84:
#line 246 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_DELAY; }
    break;

  case 85:
#line 247 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_RAND; }
    break;

  case 86:
#line 248 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_HOL; }
    break;

  case 87:
#line 249 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_PPR; }
    break;

  case 88:
#line 250 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_CFS; }
    break;

  case 89:
#line 253 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_PS; }
    break;

  case 90:
#line 254 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_PS_HOL; }
    break;

  case 91:
#line 255 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_PS_PPR; }
    break;

  case 94:
#line 262 "srvn_gram.y"
    { srvn_set_proc_multiplicity( curr_proc, srvn_real_constant( srvn_get_infinity() ) ); }
    break;

  case 95:
#line 263 "srvn_gram.y"
    { srvn_set_proc_multiplicity( curr_proc, (yyvsp[(2) - (2)].aVariable) ); }
    break;

  case 96:
#line 264 "srvn_gram.y"
    { srvn_set_proc_replicas( curr_proc, (yyvsp[(2) - (2)].aVariable) ); }
    break;

  case 97:
#line 265 "srvn_gram.y"
    { srvn_set_proc_rate( curr_proc, (yyvsp[(2) - (2)].aVariable) ); }
    break;

  case 98:
#line 269 "srvn_gram.y"
    { spex_processor_observation( curr_proc, KEY_UTILIZATION, 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 99:
#line 270 "srvn_gram.y"
    { spex_processor_observation( curr_proc, KEY_UTILIZATION, (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 106:
#line 295 "srvn_gram.y"
    {
			    curr_group = srvn_add_group( (yyvsp[(2) - (5)].aString), (yyvsp[(3) - (5)].aVariable), (yyvsp[(5) - (5)].aString), (yyvsp[(4) - (5)].anInt) );
			    (void) free((yyvsp[(2) - (5)].aString));
			    (void) free((yyvsp[(5) - (5)].aString));
			}
    break;

  case 109:
#line 306 "srvn_gram.y"
    { (yyval.aVariable)=(yyvsp[(1) - (1)].aVariable);}
    break;

  case 110:
#line 309 "srvn_gram.y"
    { (yyval.anInt) = 1; }
    break;

  case 111:
#line 310 "srvn_gram.y"
    { (yyval.anInt) = 0;}
    break;

  case 112:
#line 314 "srvn_gram.y"
    { spex_group_observation( curr_group, KEY_UTILIZATION, 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 113:
#line 315 "srvn_gram.y"
    { spex_group_observation( curr_group, KEY_UTILIZATION, (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 119:
#line 341 "srvn_gram.y"
    {
				    curr_task = srvn_add_task( (yyvsp[(2) - (6)].aString), (yyvsp[(3) - (6)].schedulingFlag), (yyvsp[(4) - (6)].entryList), (yyvsp[(6) - (6)].aString) );
				    (void) free((yyvsp[(2) - (6)].aString));
				    (void) free((yyvsp[(6) - (6)].aString));
				}
    break;

  case 121:
#line 348 "srvn_gram.y"
    {
			    srvn_store_fanin( (yyvsp[(2) - (4)].aString), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aVariable) );
			    free( (yyvsp[(2) - (4)].aString) ); free( (yyvsp[(3) - (4)].aString) );
			}
    break;

  case 122:
#line 353 "srvn_gram.y"
    {
			    srvn_store_fanout( (yyvsp[(2) - (4)].aString), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aVariable) );
			    free( (yyvsp[(2) - (4)].aString) ); free( (yyvsp[(3) - (4)].aString) );
			}
    break;

  case 124:
#line 363 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_POLL; }
    break;

  case 125:
#line 364 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_SEMAPHORE; }
    break;

  case 126:
#line 365 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_BURST; }
    break;

  case 127:
#line 366 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_FIFO; }
    break;

  case 128:
#line 367 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_HOL; }
    break;

  case 129:
#line 368 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_DELAY; }
    break;

  case 130:
#line 369 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_FIFO; }
    break;

  case 131:
#line 370 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_PPR; }
    break;

  case 132:
#line 371 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_CUSTOMER; }
    break;

  case 133:
#line 372 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_UNIFORM; }
    break;

  case 134:
#line 373 "srvn_gram.y"
    { (yyval.schedulingFlag) = SCHEDULE_RWLOCK; }
    break;

  case 135:
#line 376 "srvn_gram.y"
    { (yyval.entryList) = srvn_add_entry( (yyvsp[(1) - (1)].aString), 0 ); (void) free( (yyvsp[(1) - (1)].aString) ); }
    break;

  case 136:
#line 377 "srvn_gram.y"
    { (yyval.entryList) = srvn_add_entry( (yyvsp[(2) - (2)].aString), (yyvsp[(1) - (2)].entryList) ); (void) free( (yyvsp[(2) - (2)].aString) ); }
    break;

  case 140:
#line 388 "srvn_gram.y"
    { srvn_set_task_priority( curr_task, (yyvsp[(1) - (1)].aVariable) ) ; }
    break;

  case 141:
#line 389 "srvn_gram.y"
    { srvn_set_task_tokens( curr_task, (yyvsp[(2) - (2)].anInt) ); }
    break;

  case 142:
#line 390 "srvn_gram.y"
    { srvn_set_task_group( curr_task, (yyvsp[(2) - (2)].aString) ); free( (yyvsp[(2) - (2)].aString) ); }
    break;

  case 143:
#line 391 "srvn_gram.y"
    { srvn_set_task_multiplicity( curr_task, srvn_real_constant( srvn_get_infinity() ) ); }
    break;

  case 144:
#line 392 "srvn_gram.y"
    { srvn_set_task_multiplicity( curr_task, (yyvsp[(2) - (2)].aVariable) ); }
    break;

  case 145:
#line 393 "srvn_gram.y"
    { srvn_set_task_queue_length( curr_task, (yyvsp[(2) - (2)].aVariable) ); }
    break;

  case 146:
#line 394 "srvn_gram.y"
    { srvn_set_task_replicas( curr_task, (yyvsp[(2) - (2)].aVariable) ); }
    break;

  case 147:
#line 395 "srvn_gram.y"
    { srvn_set_task_think_time( curr_task, (yyvsp[(2) - (2)].aVariable) ); }
    break;

  case 150:
#line 404 "srvn_gram.y"
    { spex_task_observation( curr_task, KEY_THROUGHPUT,  	       0,  0,  (yyvsp[(2) - (2)].aString), 0  ); }
    break;

  case 151:
#line 405 "srvn_gram.y"
    { spex_task_observation( curr_task, KEY_THROUGHPUT,  	       0,  (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 152:
#line 406 "srvn_gram.y"
    { spex_task_observation( curr_task, KEY_UTILIZATION, 	       (yyvsp[(1) - (2)].anInt), 0,  (yyvsp[(2) - (2)].aString), 0  ); }
    break;

  case 153:
#line 407 "srvn_gram.y"
    { spex_task_observation( curr_task, KEY_UTILIZATION, 	       (yyvsp[(1) - (4)].anInt), (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 154:
#line 408 "srvn_gram.y"
    { spex_task_observation( curr_task, KEY_PROCESSOR_UTILIZATION, 0,  0,  (yyvsp[(2) - (2)].aString), 0  ); }
    break;

  case 155:
#line 409 "srvn_gram.y"
    { spex_task_observation( curr_task, KEY_PROCESSOR_UTILIZATION, 0,  (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 161:
#line 433 "srvn_gram.y"
    { srvn_set_start_activity( (yyvsp[(2) - (3)].domObject), (yyvsp[(3) - (3)].aString) ); free( (yyvsp[(3) - (3)].aString) ); }
    break;

  case 168:
#line 440 "srvn_gram.y"
    { srvn_set_rwlock_flag( (yyvsp[(2) - (2)].domObject), 'R' ); }
    break;

  case 169:
#line 441 "srvn_gram.y"
    { srvn_set_semaphore_flag( (yyvsp[(2) - (2)].domObject), 'P' ); }
    break;

  case 171:
#line 443 "srvn_gram.y"
    { srvn_set_rwlock_flag( (yyvsp[(2) - (2)].domObject), 'U' ); }
    break;

  case 172:
#line 444 "srvn_gram.y"
    { srvn_set_semaphore_flag( (yyvsp[(2) - (2)].domObject), 'V' ); }
    break;

  case 173:
#line 445 "srvn_gram.y"
    { srvn_set_rwlock_flag( (yyvsp[(2) - (2)].domObject), 'W' ); }
    break;

  case 174:
#line 446 "srvn_gram.y"
    { srvn_set_rwlock_flag( (yyvsp[(2) - (2)].domObject), 'X' ); }
    break;

  case 178:
#line 452 "srvn_gram.y"
    { void * entry = srvn_get_entry( (yyvsp[(1) - (1)].aString) ); curr_entry = entry; (yyval.domObject) = entry; free( (yyvsp[(1) - (1)].aString) ); }
    break;

  case 179:
#line 455 "srvn_gram.y"
    { void * entry = srvn_get_entry( (yyvsp[(1) - (1)].aString) ); dest_entry = entry; (yyval.domObject) = entry; free( (yyvsp[(1) - (1)].aString) ); }
    break;

  case 180:
#line 463 "srvn_gram.y"
    { srvn_store_open_arrival_rate( (yyvsp[(0) - (1)].domObject), (yyvsp[(1) - (1)].aVariable) );  }
    break;

  case 181:
#line 466 "srvn_gram.y"
    { srvn_store_coeff_of_variation( (yyvsp[(0) - (2)].domObject), 1, (yyvsp[(1) - (2)].aVariable) ); }
    break;

  case 182:
#line 467 "srvn_gram.y"
    { srvn_store_coeff_of_variation( (yyvsp[(0) - (3)].domObject), 2, (yyvsp[(1) - (3)].aVariable), (yyvsp[(2) - (3)].aVariable) ); }
    break;

  case 183:
#line 468 "srvn_gram.y"
    { srvn_store_coeff_of_variation( (yyvsp[(0) - (4)].domObject), 3, (yyvsp[(1) - (4)].aVariable), (yyvsp[(2) - (4)].aVariable), (yyvsp[(3) - (4)].aVariable) ); }
    break;

  case 184:
#line 471 "srvn_gram.y"
    { srvn_set_phase_type_flag( (yyvsp[(0) - (2)].domObject), 1, (yyvsp[(1) - (2)].anInt) ); }
    break;

  case 185:
#line 472 "srvn_gram.y"
    { srvn_set_phase_type_flag( (yyvsp[(0) - (3)].domObject), 2, (yyvsp[(1) - (3)].anInt), (yyvsp[(2) - (3)].anInt) ); }
    break;

  case 186:
#line 473 "srvn_gram.y"
    { srvn_set_phase_type_flag( (yyvsp[(0) - (4)].domObject), 3, (yyvsp[(1) - (4)].anInt), (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].anInt) ); }
    break;

  case 187:
#line 477 "srvn_gram.y"
    {
				    srvn_set_histogram( (yyvsp[(0) - (2)].domObject), 1, (yyvsp[(1) - (2)].aFloat), (yyvsp[(1) - (2)].aFloat), 0 );	/* Ph 1 */
				}
    break;

  case 188:
#line 481 "srvn_gram.y"
    {
				    srvn_set_histogram( (yyvsp[(0) - (3)].domObject), 1, (yyvsp[(1) - (3)].aFloat), (yyvsp[(1) - (3)].aFloat), 0 );	/* Ph 1 */
				    srvn_set_histogram( (yyvsp[(0) - (3)].domObject), 2, (yyvsp[(2) - (3)].aFloat), (yyvsp[(2) - (3)].aFloat), 0 );	/* Ph 2 */
				}
    break;

  case 189:
#line 486 "srvn_gram.y"
    {
				    srvn_set_histogram( (yyvsp[(0) - (4)].domObject), 1, (yyvsp[(1) - (4)].aFloat), (yyvsp[(1) - (4)].aFloat), 0 );	/* Ph 1 */
				    srvn_set_histogram( (yyvsp[(0) - (4)].domObject), 2, (yyvsp[(2) - (4)].aFloat), (yyvsp[(2) - (4)].aFloat), 0 );	/* Ph 2 */
				    srvn_set_histogram( (yyvsp[(0) - (4)].domObject), 3, (yyvsp[(3) - (4)].aFloat), (yyvsp[(3) - (4)].aFloat), 0 );	/* Ph 3 */
				}
    break;

  case 190:
#line 494 "srvn_gram.y"
    {
				    srvn_set_histogram( (yyvsp[(0) - (5)].domObject), (yyvsp[(1) - (5)].anInt), (yyvsp[(2) - (5)].aFloat), (yyvsp[(4) - (5)].aFloat), (yyvsp[(5) - (5)].anInt) );
				}
    break;

  case 191:
#line 499 "srvn_gram.y"
    { srvn_store_entry_priority( (yyvsp[(0) - (1)].domObject), (yyvsp[(1) - (1)].anInt) ); }
    break;

  case 192:
#line 502 "srvn_gram.y"
    { srvn_store_phase_service_time( (yyvsp[(0) - (2)].domObject), 1, (yyvsp[(1) - (2)].aVariable) ); }
    break;

  case 193:
#line 503 "srvn_gram.y"
    { srvn_store_phase_service_time( (yyvsp[(0) - (3)].domObject), 2, (yyvsp[(1) - (3)].aVariable), (yyvsp[(2) - (3)].aVariable) ); }
    break;

  case 194:
#line 504 "srvn_gram.y"
    { srvn_store_phase_service_time( (yyvsp[(0) - (4)].domObject), 3, (yyvsp[(1) - (4)].aVariable), (yyvsp[(2) - (4)].aVariable), (yyvsp[(3) - (4)].aVariable) ); }
    break;

  case 195:
#line 507 "srvn_gram.y"
    { srvn_store_rnv_data( (yyvsp[(-1) - (2)].domObject), (yyvsp[(0) - (2)].domObject), 1, (yyvsp[(1) - (2)].aVariable) ); }
    break;

  case 196:
#line 508 "srvn_gram.y"
    { srvn_store_rnv_data( (yyvsp[(-1) - (3)].domObject), (yyvsp[(0) - (3)].domObject), 2, (yyvsp[(1) - (3)].aVariable), (yyvsp[(2) - (3)].aVariable) ); }
    break;

  case 197:
#line 509 "srvn_gram.y"
    { srvn_store_rnv_data( (yyvsp[(-1) - (4)].domObject), (yyvsp[(0) - (4)].domObject), 3, (yyvsp[(1) - (4)].aVariable), (yyvsp[(2) - (4)].aVariable), (yyvsp[(3) - (4)].aVariable) ); }
    break;

  case 198:
#line 512 "srvn_gram.y"
    { srvn_store_snr_data( (yyvsp[(-1) - (2)].domObject), (yyvsp[(0) - (2)].domObject), 1, (yyvsp[(1) - (2)].aVariable) ); }
    break;

  case 199:
#line 513 "srvn_gram.y"
    { srvn_store_snr_data( (yyvsp[(-1) - (3)].domObject), (yyvsp[(0) - (3)].domObject), 2, (yyvsp[(1) - (3)].aVariable), (yyvsp[(2) - (3)].aVariable) ); }
    break;

  case 200:
#line 514 "srvn_gram.y"
    { srvn_store_snr_data( (yyvsp[(-1) - (4)].domObject), (yyvsp[(0) - (4)].domObject), 3, (yyvsp[(1) - (4)].aVariable), (yyvsp[(2) - (4)].aVariable), (yyvsp[(3) - (4)].aVariable) ); }
    break;

  case 201:
#line 517 "srvn_gram.y"
    { srvn_store_phase_think_time( (yyvsp[(0) - (2)].domObject), 1, (yyvsp[(1) - (2)].aVariable) ); }
    break;

  case 202:
#line 518 "srvn_gram.y"
    { srvn_store_phase_think_time( (yyvsp[(0) - (3)].domObject), 2, (yyvsp[(1) - (3)].aVariable), (yyvsp[(2) - (3)].aVariable) ); }
    break;

  case 203:
#line 519 "srvn_gram.y"
    { srvn_store_phase_think_time( (yyvsp[(0) - (4)].domObject), 3, (yyvsp[(1) - (4)].aVariable), (yyvsp[(2) - (4)].aVariable), (yyvsp[(3) - (4)].aVariable) ); }
    break;

  case 204:
#line 522 "srvn_gram.y"
    { srvn_store_prob_forward_data( (yyvsp[(-1) - (2)].domObject), (yyvsp[(0) - (2)].domObject), (yyvsp[(1) - (2)].aVariable) ); }
    break;

  case 205:
#line 525 "srvn_gram.y"
    { (yyval.anInt) = (yyvsp[(1) - (1)].anInt); }
    break;

  case 206:
#line 526 "srvn_gram.y"
    { (yyval.anInt) = 20; }
    break;

  case 209:
#line 536 "srvn_gram.y"
    { spex_entry_observation( curr_entry, KEY_THROUGHPUT, (yyvsp[(1) - (2)].anInt), 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 210:
#line 537 "srvn_gram.y"
    { spex_entry_observation( curr_entry, KEY_THROUGHPUT, (yyvsp[(1) - (4)].anInt), (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 211:
#line 538 "srvn_gram.y"
    { spex_entry_observation( curr_entry, KEY_THROUGHPUT_BOUND, (yyvsp[(1) - (2)].anInt),  0,  (yyvsp[(2) - (2)].aString), 0  ); }
    break;

  case 212:
#line 539 "srvn_gram.y"
    { spex_entry_observation( curr_entry, KEY_UTILIZATION, (yyvsp[(1) - (2)].anInt), 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 213:
#line 540 "srvn_gram.y"
    { spex_entry_observation( curr_entry, KEY_UTILIZATION, (yyvsp[(1) - (4)].anInt), (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 214:
#line 541 "srvn_gram.y"
    { spex_entry_observation( curr_entry, KEY_PROCESSOR_UTILIZATION, (yyvsp[(1) - (2)].anInt), 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 215:
#line 542 "srvn_gram.y"
    { spex_entry_observation( curr_entry, KEY_PROCESSOR_UTILIZATION, (yyvsp[(1) - (4)].anInt), (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 216:
#line 543 "srvn_gram.y"
    { spex_entry_observation( curr_entry, KEY_PROCESSOR_WAITING, (yyvsp[(1) - (2)].anInt), 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 217:
#line 544 "srvn_gram.y"
    { spex_entry_observation( curr_entry, KEY_PROCESSOR_WAITING, (yyvsp[(1) - (4)].anInt), (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 218:
#line 545 "srvn_gram.y"
    { spex_entry_observation( curr_entry, KEY_SERVICE_TIME, (yyvsp[(1) - (2)].anInt), 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 219:
#line 546 "srvn_gram.y"
    { spex_entry_observation( curr_entry, KEY_SERVICE_TIME, (yyvsp[(1) - (4)].anInt), (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 220:
#line 547 "srvn_gram.y"
    { spex_entry_observation( curr_entry, KEY_VARIANCE, (yyvsp[(1) - (2)].anInt), 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 221:
#line 548 "srvn_gram.y"
    { spex_entry_observation( curr_entry, KEY_VARIANCE, (yyvsp[(1) - (4)].anInt), (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 222:
#line 549 "srvn_gram.y"
    { spex_entry_observation( curr_entry, KEY_WAITING, (yyvsp[(1) - (2)].anInt), 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 223:
#line 550 "srvn_gram.y"
    { spex_entry_observation( curr_entry, KEY_WAITING, (yyvsp[(1) - (4)].anInt), (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 224:
#line 551 "srvn_gram.y"
    { spex_entry_observation( curr_entry, KEY_EXCEEDED_TIME, (yyvsp[(1) - (2)].anInt), 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 227:
#line 558 "srvn_gram.y"
    { spex_call_observation( curr_entry, KEY_WAITING, (yyvsp[(1) - (2)].anInt), dest_entry, 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 228:
#line 559 "srvn_gram.y"
    { spex_call_observation( curr_entry, KEY_WAITING, (yyvsp[(1) - (4)].anInt), dest_entry, (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 229:
#line 560 "srvn_gram.y"
    { spex_call_observation( curr_entry, KEY_WAITING_VARIANCE, (yyvsp[(1) - (2)].anInt), dest_entry, 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 230:
#line 561 "srvn_gram.y"
    { spex_call_observation( curr_entry, KEY_WAITING_VARIANCE, (yyvsp[(1) - (4)].anInt), dest_entry, (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 235:
#line 574 "srvn_gram.y"
    { curr_task = srvn_find_task( (yyvsp[(1) - (1)].aString) ); free( (yyvsp[(1) - (1)].aString) ); }
    break;

  case 238:
#line 583 "srvn_gram.y"
    { srvn_store_activity_service_time( (yyvsp[(2) - (4)].domObject), (yyvsp[(3) - (4)].aVariable) ); }
    break;

  case 239:
#line 584 "srvn_gram.y"
    { srvn_store_activity_coeff_of_variation( (yyvsp[(2) - (4)].domObject), (yyvsp[(3) - (4)].aVariable) );  }
    break;

  case 240:
#line 585 "srvn_gram.y"
    { srvn_set_activity_phase_type_flag( (yyvsp[(2) - (3)].domObject), (yyvsp[(3) - (3)].anInt) ); }
    break;

  case 241:
#line 586 "srvn_gram.y"
    { srvn_set_activity_histogram( (yyvsp[(2) - (6)].domObject), (yyvsp[(3) - (6)].aFloat), (yyvsp[(5) - (6)].aFloat), (yyvsp[(6) - (6)].anInt) ); }
    break;

  case 242:
#line 587 "srvn_gram.y"
    { srvn_set_activity_histogram( (yyvsp[(2) - (3)].domObject), (yyvsp[(3) - (3)].aFloat), (yyvsp[(3) - (3)].aFloat), 0 );  }
    break;

  case 243:
#line 589 "srvn_gram.y"
    { srvn_set_activity_call_name( curr_task, (yyvsp[(2) - (4)].domObject), (yyvsp[(3) - (4)].domObject), srvn_store_activity_rnv_data( (yyvsp[(2) - (4)].domObject), (yyvsp[(3) - (4)].domObject), (yyvsp[(4) - (4)].aVariable) ) ); }
    break;

  case 245:
#line 590 "srvn_gram.y"
    { srvn_set_activity_call_name( curr_task, (yyvsp[(2) - (4)].domObject), (yyvsp[(3) - (4)].domObject), srvn_store_activity_snr_data( (yyvsp[(2) - (4)].domObject), (yyvsp[(3) - (4)].domObject), (yyvsp[(4) - (4)].aVariable) ) ); }
    break;

  case 247:
#line 591 "srvn_gram.y"
    { srvn_store_activity_think_time( (yyvsp[(2) - (4)].domObject), (yyvsp[(3) - (4)].aVariable) ); }
    break;

  case 250:
#line 600 "srvn_gram.y"
    { srvn_act_connect( curr_task, (yyvsp[(1) - (1)].activityList), 0 ); }
    break;

  case 251:
#line 601 "srvn_gram.y"
    { srvn_act_connect( curr_task, (yyvsp[(1) - (3)].activityList), (yyvsp[(3) - (3)].activityList) ); }
    break;

  case 252:
#line 604 "srvn_gram.y"
    { (yyval.activityList) = srvn_act_join_item( curr_task, (yyvsp[(1) - (1)].aString) ); }
    break;

  case 253:
#line 605 "srvn_gram.y"
    { (yyval.activityList) = srvn_act_and_join_list( curr_task, (yyvsp[(3) - (4)].aString), (yyvsp[(1) - (4)].activityList), (yyvsp[(4) - (4)].aVariable) ); }
    break;

  case 254:
#line 606 "srvn_gram.y"
    { (yyval.activityList) = srvn_act_or_join_list( curr_task, (yyvsp[(3) - (3)].aString), (yyvsp[(1) - (3)].activityList) ); }
    break;

  case 255:
#line 609 "srvn_gram.y"
    { (yyval.aVariable) = (yyvsp[(2) - (3)].aVariable); }
    break;

  case 256:
#line 610 "srvn_gram.y"
    { (yyval.aVariable) = 0; }
    break;

  case 257:
#line 613 "srvn_gram.y"
    { (yyval.activityList) = srvn_act_and_join_list( curr_task, (yyvsp[(1) - (1)].aString), 0, 0 ); }
    break;

  case 258:
#line 614 "srvn_gram.y"
    { (yyval.activityList) = srvn_act_and_join_list( curr_task, (yyvsp[(3) - (3)].aString), (yyvsp[(1) - (3)].activityList), 0 ); }
    break;

  case 259:
#line 617 "srvn_gram.y"
    { (yyval.activityList) = srvn_act_or_join_list( curr_task, (yyvsp[(1) - (1)].aString), 0 ); }
    break;

  case 260:
#line 618 "srvn_gram.y"
    { (yyval.activityList) = srvn_act_or_join_list( curr_task, (yyvsp[(3) - (3)].aString), (yyvsp[(1) - (3)].activityList) ); }
    break;

  case 261:
#line 621 "srvn_gram.y"
    { (yyval.aString) = (yyvsp[(1) - (1)].domObject); }
    break;

  case 262:
#line 622 "srvn_gram.y"
    { srvn_act_add_reply_list( curr_task, (yyvsp[(1) - (4)].domObject), (yyvsp[(3) - (4)].entryList) ); (yyval.aString) = (yyvsp[(1) - (4)].domObject); }
    break;

  case 263:
#line 625 "srvn_gram.y"
    { (yyval.entryList) = srvn_act_add_reply( curr_task, (yyvsp[(1) - (1)].domObject), 0 );  }
    break;

  case 264:
#line 626 "srvn_gram.y"
    { (yyval.entryList) = srvn_act_add_reply( curr_task, (yyvsp[(3) - (3)].domObject), (yyvsp[(1) - (3)].entryList) );  }
    break;

  case 265:
#line 629 "srvn_gram.y"
    { (yyval.activityList) = srvn_act_fork_item( curr_task, (yyvsp[(1) - (1)].domObject) ); }
    break;

  case 266:
#line 630 "srvn_gram.y"
    { (yyval.activityList) = srvn_act_loop_list( curr_task, (yyvsp[(1) - (2)].aVariable), (yyvsp[(2) - (2)].domObject), 0 ); }
    break;

  case 267:
#line 631 "srvn_gram.y"
    { (yyval.activityList) = srvn_act_loop_list( curr_task, (yyvsp[(1) - (4)].aVariable), (yyvsp[(2) - (4)].domObject), (yyvsp[(4) - (4)].activityList) ); }
    break;

  case 268:
#line 632 "srvn_gram.y"
    { (yyval.activityList) = srvn_act_and_fork_list( curr_task, (yyvsp[(3) - (3)].domObject), (yyvsp[(1) - (3)].activityList) ); }
    break;

  case 269:
#line 633 "srvn_gram.y"
    { (yyval.activityList) = srvn_act_or_fork_list( curr_task, (yyvsp[(1) - (4)].aVariable), (yyvsp[(2) - (4)].domObject), (yyvsp[(4) - (4)].activityList) ); }
    break;

  case 270:
#line 636 "srvn_gram.y"
    { (yyval.activityList) = srvn_act_and_fork_list( curr_task, (yyvsp[(1) - (1)].domObject), 0 ); }
    break;

  case 271:
#line 637 "srvn_gram.y"
    { (yyval.activityList) = srvn_act_and_fork_list( curr_task, (yyvsp[(3) - (3)].domObject), (yyvsp[(1) - (3)].activityList) ); }
    break;

  case 272:
#line 640 "srvn_gram.y"
    { (yyval.activityList) = srvn_act_or_fork_list( curr_task, (yyvsp[(1) - (2)].aVariable), (yyvsp[(2) - (2)].domObject), 0 ); }
    break;

  case 273:
#line 641 "srvn_gram.y"
    { (yyval.activityList) = srvn_act_or_fork_list( curr_task, (yyvsp[(3) - (4)].aVariable), (yyvsp[(4) - (4)].domObject), (yyvsp[(1) - (4)].activityList) ); }
    break;

  case 274:
#line 644 "srvn_gram.y"
    { (yyval.activityList) = srvn_act_loop_list( curr_task, 0, (yyvsp[(1) - (1)].domObject), 0 ); }
    break;

  case 275:
#line 645 "srvn_gram.y"
    { (yyval.activityList) = srvn_act_loop_list( curr_task, (yyvsp[(3) - (4)].aVariable), (yyvsp[(4) - (4)].domObject), (yyvsp[(1) - (4)].activityList) ); }
    break;

  case 276:
#line 648 "srvn_gram.y"
    { (yyval.aVariable) = (yyvsp[(2) - (3)].aVariable); }
    break;

  case 277:
#line 651 "srvn_gram.y"
    { (yyval.aVariable) = (yyvsp[(1) - (2)].aVariable); }
    break;

  case 279:
#line 657 "srvn_gram.y"
    { void * activity = srvn_get_activity( curr_task, (yyvsp[(1) - (1)].aString) ); curr_activity = activity; (yyval.domObject) = activity; free( (yyvsp[(1) - (1)].aString) ); }
    break;

  case 280:
#line 660 "srvn_gram.y"
    { void * activity = srvn_find_activity( curr_task, (yyvsp[(1) - (1)].aString) ); curr_activity = activity; (yyval.domObject) = activity; free( (yyvsp[(1) - (1)].aString) ); }
    break;

  case 283:
#line 668 "srvn_gram.y"
    { spex_activity_observation( curr_task, curr_activity, KEY_THROUGHPUT, 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 284:
#line 669 "srvn_gram.y"
    { spex_activity_observation( curr_task, curr_activity, KEY_THROUGHPUT, (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 285:
#line 670 "srvn_gram.y"
    { spex_activity_observation( curr_task, curr_activity, KEY_UTILIZATION, 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 286:
#line 671 "srvn_gram.y"
    { spex_activity_observation( curr_task, curr_activity, KEY_UTILIZATION, (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 287:
#line 672 "srvn_gram.y"
    { spex_activity_observation( curr_task, curr_activity, KEY_PROCESSOR_UTILIZATION, 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 288:
#line 673 "srvn_gram.y"
    { spex_activity_observation( curr_task, curr_activity, KEY_PROCESSOR_UTILIZATION, (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 289:
#line 674 "srvn_gram.y"
    { spex_activity_observation( curr_task, curr_activity, KEY_PROCESSOR_WAITING, 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 290:
#line 675 "srvn_gram.y"
    { spex_activity_observation( curr_task, curr_activity, KEY_PROCESSOR_WAITING, (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 291:
#line 676 "srvn_gram.y"
    { spex_activity_observation( curr_task, curr_activity, KEY_SERVICE_TIME, 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 292:
#line 677 "srvn_gram.y"
    { spex_activity_observation( curr_task, curr_activity, KEY_SERVICE_TIME, (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 293:
#line 678 "srvn_gram.y"
    { spex_activity_observation( curr_task, curr_activity, KEY_VARIANCE, 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 294:
#line 679 "srvn_gram.y"
    { spex_activity_observation( curr_task, curr_activity, KEY_VARIANCE, (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 295:
#line 680 "srvn_gram.y"
    { spex_activity_observation( curr_task, curr_activity, KEY_EXCEEDED_TIME, 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 298:
#line 687 "srvn_gram.y"
    { spex_activity_call_observation( curr_task, curr_activity, KEY_WAITING, dest_entry, 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 299:
#line 688 "srvn_gram.y"
    { spex_activity_call_observation( curr_task, curr_activity, KEY_WAITING, dest_entry, (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 300:
#line 689 "srvn_gram.y"
    { spex_activity_call_observation( curr_task, curr_activity, KEY_WAITING_VARIANCE, dest_entry, 0, (yyvsp[(2) - (2)].aString), 0 ); }
    break;

  case 301:
#line 690 "srvn_gram.y"
    { spex_activity_call_observation( curr_task, curr_activity, KEY_WAITING_VARIANCE, dest_entry, (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aString) ); }
    break;

  case 302:
#line 695 "srvn_gram.y"
    { (yyval.aParseTreeNode) = (yyvsp[(3) - (4)].aParseTreeList); }
    break;

  case 303:
#line 696 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_result_function( (yyvsp[(3) - (7)].aVariable), (yyvsp[(5) - (7)].aParseTreeList) ); }
    break;

  case 304:
#line 697 "srvn_gram.y"
    { (yyval.aParseTreeNode) = 0; }
    break;

  case 305:
#line 700 "srvn_gram.y"
    { (yyval.aParseTreeList) = spex_list( 0, (yyvsp[(1) - (1)].aParseTreeNode) ); }
    break;

  case 306:
#line 701 "srvn_gram.y"
    { (yyval.aParseTreeList) = spex_list( (yyvsp[(1) - (2)].aParseTreeList), (yyvsp[(2) - (2)].aParseTreeNode) ); }
    break;

  case 307:
#line 704 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_result_assignment_statement( (yyvsp[(1) - (3)].aString), (yyvsp[(3) - (3)].aParseTreeNode) ); }
    break;

  case 308:
#line 705 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_result_assignment_statement( (yyvsp[(1) - (1)].aString), 0 ); }
    break;

  case 309:
#line 712 "srvn_gram.y"
    { (yyval.aParseTreeList) = (yyvsp[(3) - (4)].aParseTreeList); }
    break;

  case 310:
#line 713 "srvn_gram.y"
    { (yyval.aParseTreeList) = 0; }
    break;

  case 311:
#line 716 "srvn_gram.y"
    { (yyval.aParseTreeList) = spex_list( 0, (yyvsp[(1) - (1)].aParseTreeNode) ); }
    break;

  case 312:
#line 717 "srvn_gram.y"
    { (yyval.aParseTreeList) = spex_list( (yyvsp[(1) - (2)].aParseTreeList), (yyvsp[(2) - (2)].aParseTreeNode) ); }
    break;

  case 313:
#line 720 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_convergence_assignment_statement( (yyvsp[(1) - (3)].aString), (yyvsp[(3) - (3)].aParseTreeNode) ); }
    break;

  case 314:
#line 721 "srvn_gram.y"
    { (yyval.aParseTreeNode) = spex_convergence_assignment_statement( (yyvsp[(1) - (1)].aString), 0 ); }
    break;

  case 315:
#line 727 "srvn_gram.y"
    { (yyval.aVariable) = srvn_real_constant( (yyvsp[(1) - (1)].aFloat) ); }
    break;

  case 316:
#line 728 "srvn_gram.y"
    { (yyval.aVariable) = srvn_int_constant( (yyvsp[(1) - (1)].anInt) ); }
    break;

  case 317:
#line 729 "srvn_gram.y"
    { (yyval.aVariable) = srvn_variable( (yyvsp[(1) - (1)].aString) ); }
    break;

  case 318:
#line 731 "srvn_gram.y"
    { (yyval.aVariable) = spex_inline_expression( (yyvsp[(2) - (3)].aParseTreeNode) ); }
    break;

  case 319:
#line 735 "srvn_gram.y"
    { (yyval.aFloat) = (yyvsp[(1) - (1)].aFloat); }
    break;

  case 320:
#line 736 "srvn_gram.y"
    { (yyval.aFloat) = (double)( (yyvsp[(1) - (1)].anInt) ); }
    break;

  case 321:
#line 737 "srvn_gram.y"
    { (yyval.aFloat) = srvn_get_infinity(); }
    break;

  case 322:
#line 740 "srvn_gram.y"
    { (yyval.aVariable) = srvn_int_constant( (yyvsp[(1) - (1)].anInt) ); }
    break;

  case 323:
#line 741 "srvn_gram.y"
    { (yyval.aVariable) = srvn_variable( (yyvsp[(1) - (1)].aString) ); }
    break;

  case 324:
#line 744 "srvn_gram.y"
    { (yyval.aString) = (yyvsp[(1) - (1)].aString); }
    break;

  case 325:
#line 745 "srvn_gram.y"
    { (yyval.aString) = make_name( (yyvsp[(1) - (1)].anInt) ); }
    break;

  case 326:
#line 749 "srvn_gram.y"
    { (yyval.aVariable) = (yyvsp[(1) - (1)].aString); }
    break;


/* Line 1267 of yacc.c.  */
#line 3329 "srvn_gram.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}


#line 753 "srvn_gram.y"


/*
 * Convert an integer into a malloced string.
 */

static char *
make_name( int i )
{
    char * buf = (char *)malloc( 10 );
    if ( buf ) {
	if ( snprintf( buf, 10, "%d", i ) >= 10 ) {
	}
    }
    return buf;
}

