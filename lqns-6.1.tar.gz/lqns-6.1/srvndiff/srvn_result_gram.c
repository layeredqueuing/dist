/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0

/* Substitute the variable and function names.  */
#define yyparse resultparse
#define yylex   resultlex
#define yyerror resulterror
#define yylval  resultlval
#define yychar  resultchar
#define yydebug resultdebug
#define yynerrs resultnerrs


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     VALIDITY_FLAG = 258,
     CONV_FLAG = 259,
     ITERATION_FLAG = 260,
     PROC_COUNT_FLAG = 261,
     PHASE_COUNT_FLAG = 262,
     BOUND_FLAG = 263,
     DROP_PROBABILITY_FLAG = 264,
     SERVICE_EXCEEDED_FLAG = 265,
     DISTRIBUTION_FLAG = 266,
     WAITING_FLAG = 267,
     WAITING_VARIANCE_FLAG = 268,
     FWD_WAITING_FLAG = 269,
     FWD_WAITING_VARIANCE_FLAG = 270,
     SNR_WAITING_FLAG = 271,
     SNR_WAITING_VARIANCE_FLAG = 272,
     JOIN_FLAG = 273,
     HOLD_TIME_FLAG = 274,
     RWLOCK_HOLD_TIME_FLAG = 275,
     SERVICE_FLAG = 276,
     VARIANCE_FLAG = 277,
     THPT_UT_FLAG = 278,
     OPEN_ARRIV_FLAG = 279,
     PROC_FLAG = 280,
     GROUP_FLAG = 281,
     OVERTAKING_FLAG = 282,
     ENDLIST = 283,
     REAL_TIME = 284,
     USER_TIME = 285,
     SYST_TIME = 286,
     MAX_RSS = 287,
     SOLVER = 288,
     INTEGER = 289,
     FLOAT = 290,
     TIME = 291,
     SYMBOL = 292,
     TEXT = 293,
     INFTY = 294,
     VARIABLE = 295,
     COMMENT = 296,
     CHAR = 297
   };
#endif
/* Tokens.  */
#define VALIDITY_FLAG 258
#define CONV_FLAG 259
#define ITERATION_FLAG 260
#define PROC_COUNT_FLAG 261
#define PHASE_COUNT_FLAG 262
#define BOUND_FLAG 263
#define DROP_PROBABILITY_FLAG 264
#define SERVICE_EXCEEDED_FLAG 265
#define DISTRIBUTION_FLAG 266
#define WAITING_FLAG 267
#define WAITING_VARIANCE_FLAG 268
#define FWD_WAITING_FLAG 269
#define FWD_WAITING_VARIANCE_FLAG 270
#define SNR_WAITING_FLAG 271
#define SNR_WAITING_VARIANCE_FLAG 272
#define JOIN_FLAG 273
#define HOLD_TIME_FLAG 274
#define RWLOCK_HOLD_TIME_FLAG 275
#define SERVICE_FLAG 276
#define VARIANCE_FLAG 277
#define THPT_UT_FLAG 278
#define OPEN_ARRIV_FLAG 279
#define PROC_FLAG 280
#define GROUP_FLAG 281
#define OVERTAKING_FLAG 282
#define ENDLIST 283
#define REAL_TIME 284
#define USER_TIME 285
#define SYST_TIME 286
#define MAX_RSS 287
#define SOLVER 288
#define INTEGER 289
#define FLOAT 290
#define TIME 291
#define SYMBOL 292
#define TEXT 293
#define INFTY 294
#define VARIABLE 295
#define COMMENT 296
#define CHAR 297




/* Copy the first part of user declarations.  */
#line 1 "srvn_result_gram.y"

/************************************************************************/
/* Copyright the Real-Time and Distributed Systems Group,		*/
/* Department of Systems and Computer Engineering,			*/
/* Carleton University, Ottawa, Ontario, Canada. K1S 5B6		*/
/*									*/
/* Novemeber 1990.							*/
/************************************************************************/

/*
 * $Id: srvn_result_gram.y 14000 2020-10-25 12:50:53Z greg $
 * ----------------------------------------------------------------------
 *
 * This file has been modified such that it uses result rather than yy on its
 * global variables.  The parser generated should be run through a sed command
 * of the form "sed -e /s/y/xx/g" before compilation.  Same goes for the
 * lexical analyser.
 */
	
#if defined(HAVE_CONFIG_H)
#include <config.h>
#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <ctype.h>
#include <math.h>
#if HAVE_FLOAT_H
#include <float.h>
#endif
#if HAVE_VALUES_H
#include <values.h>
#endif
#include "srvn_results.h"


static unsigned		i;	/* Index into phase list array */
static unsigned		np;	/* Number of phases in phase list */
static double		*fl;	/* Phase list array (float list) */
static char		*proc_name = 0;		/* Current processor name */
static char		*task_name = 0;		/* Current task name */
static char		*group_name = 0;	/* Current group name */
static char		*from_name = 0;
static char		*to_name = 0;
static char		*entry_name = 0;
static char		*activity_name = 0;
static int		entry_phase = 0;

static char * make_name( int i );
static void free_from_and_to_name();
static void free_task_name();
static void free_entry_name();
static void free_activity_name();
static double resultinfinity();
static void resulterror( const char * fmt );



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 75 "srvn_result_gram.y"
{
	int anInt;
	double aFloat;
	char *aString;
	char aChar;
	double *aFloatList;
}
/* Line 193 of yacc.c.  */
#line 255 "srvn_result_gram.c"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 216 of yacc.c.  */
#line 268 "srvn_result_gram.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  7
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1562

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  47
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  243
/* YYNRULES -- Number of rules.  */
#define YYNRULES  393
/* YYNRULES -- Number of states.  */
#define YYNSTATES  771

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   297

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,    43,     2,     2,
       2,     2,     2,     2,    45,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    44,     2,
       2,    46,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,    26,    28,    31,    32,    34,    35,    37,
      38,    40,    41,    43,    44,    46,    47,    49,    50,    52,
      53,    55,    56,    58,    59,    61,    62,    64,    65,    67,
      68,    70,    71,    74,    75,    77,    78,    80,    81,    83,
      84,    86,    87,    89,    90,    92,    93,    99,   102,   105,
     108,   111,   114,   116,   120,   124,   126,   129,   132,   135,
     138,   140,   143,   152,   166,   170,   173,   176,   179,   184,
     188,   190,   192,   194,   197,   200,   204,   208,   212,   214,
     217,   220,   225,   228,   229,   233,   236,   239,   244,   247,
     248,   252,   256,   258,   260,   262,   265,   268,   272,   276,
     280,   282,   285,   288,   293,   296,   297,   301,   304,   307,
     312,   315,   316,   320,   324,   326,   328,   331,   334,   338,
     341,   344,   349,   352,   353,   357,   361,   363,   365,   368,
     371,   375,   378,   381,   386,   389,   390,   394,   398,   400,
     402,   404,   407,   410,   414,   418,   422,   424,   427,   430,
     435,   438,   439,   443,   446,   449,   454,   457,   458,   462,
     466,   468,   470,   472,   475,   478,   482,   486,   490,   492,
     495,   498,   503,   506,   507,   511,   514,   517,   522,   525,
     526,   530,   534,   536,   538,   540,   543,   546,   550,   554,
     558,   560,   563,   566,   571,   574,   575,   579,   582,   585,
     590,   593,   594,   598,   602,   604,   606,   609,   612,   616,
     619,   622,   628,   631,   632,   637,   641,   643,   645,   648,
     651,   655,   659,   661,   664,   667,   671,   674,   675,   679,
     682,   685,   689,   692,   693,   697,   701,   703,   705,   708,
     711,   715,   719,   721,   724,   727,   731,   734,   735,   739,
     742,   745,   749,   752,   753,   757,   761,   763,   765,   768,
     771,   775,   779,   781,   784,   787,   791,   794,   795,   799,
     802,   805,   809,   812,   813,   817,   826,   835,   838,   840,
     846,   849,   851,   857,   861,   862,   866,   869,   872,   881,
     884,   885,   891,   895,   898,   901,   904,   915,   924,   927,
     928,   936,   939,   940,   948,   953,   956,   958,   964,   967,
     968,   973,   974,   977,   978,   984,   987,   990,   996,   999,
    1000,  1006,  1009,  1012,  1017,  1020,  1021,  1026,  1030,  1033,
    1036,  1042,  1049,  1052,  1053,  1057,  1060,  1062,  1068,  1072,
    1073,  1076,  1078,  1084,  1086,  1090,  1094,  1097,  1100,  1103,
    1108,  1111,  1112,  1117,  1120,  1123,  1128,  1131,  1132,  1137,
    1140,  1141,  1145,  1148,  1149,  1154,  1155,  1158,  1159,  1163,
    1166,  1167,  1171,  1174,  1177,  1180,  1187,  1189,  1191,  1193,
    1195,  1197,  1199,  1201,  1203,  1205,  1206,  1209,  1212,  1213,
    1217,  1220,  1222,  1224
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
      48,     0,    -1,    70,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    -1,     1,    -1,    76,    49,
      -1,    -1,    78,    -1,    -1,    80,    -1,    -1,    83,    -1,
      -1,    96,    -1,    -1,   109,    -1,    -1,   117,    -1,    -1,
     125,    -1,    -1,   138,    -1,    -1,   151,    -1,    -1,   164,
      -1,    -1,   172,    -1,    -1,   185,    -1,    -1,   198,    -1,
      -1,    63,   211,    -1,    -1,   217,    -1,    -1,   222,    -1,
      -1,   231,    -1,    -1,   246,    -1,    -1,   251,    -1,    -1,
     274,    -1,    -1,    71,    72,    73,    74,    75,    -1,     3,
      42,    -1,     4,   289,    -1,     5,    34,    -1,     6,    34,
      -1,     7,    34,    -1,    77,    -1,    77,    45,    76,    -1,
      40,    46,   289,    -1,    79,    -1,    79,    78,    -1,    29,
      36,    -1,    30,    36,    -1,    31,    36,    -1,    41,    -1,
      32,    34,    -1,    33,    34,    34,   289,   289,   289,   289,
      34,    -1,    33,    34,    34,   289,   289,   289,   289,   289,
     289,   289,    36,    36,    36,    -1,     8,    34,    81,    -1,
      82,    28,    -1,    82,    81,    -1,   277,   289,    -1,   277,
      44,   277,   289,    -1,    12,    34,    84,    -1,    85,    -1,
      88,    -1,    28,    -1,    86,    28,    -1,    86,    85,    -1,
     279,    44,    87,    -1,    28,    44,    92,    -1,    88,    44,
      92,    -1,    88,    -1,    89,    88,    -1,    89,    28,    -1,
     281,   282,   285,    90,    -1,    91,    90,    -1,    -1,    43,
      34,   285,    -1,    93,    28,    -1,    93,    92,    -1,   281,
     282,   285,    94,    -1,    95,    94,    -1,    -1,    43,    34,
     285,    -1,    13,    34,    97,    -1,    98,    -1,   101,    -1,
      28,    -1,    99,    28,    -1,    99,    98,    -1,   279,    44,
     100,    -1,    28,    44,   105,    -1,   101,    44,   105,    -1,
     101,    -1,   102,    28,    -1,   102,   101,    -1,   281,   282,
     285,   103,    -1,   104,   103,    -1,    -1,    43,    34,   285,
      -1,   106,    28,    -1,   106,   105,    -1,   281,   282,   285,
     107,    -1,   108,   107,    -1,    -1,    43,    34,   285,    -1,
      14,    34,   110,    -1,   111,    -1,    28,    -1,   112,    28,
      -1,   112,   111,    -1,   279,    44,   113,    -1,   114,    28,
      -1,   114,   113,    -1,   281,   282,   289,   115,    -1,   116,
     115,    -1,    -1,    43,    34,   289,    -1,    15,    34,   118,
      -1,   119,    -1,    28,    -1,   120,    28,    -1,   120,   119,
      -1,   279,    44,   121,    -1,   122,    28,    -1,   122,   121,
      -1,   281,   282,   289,   123,    -1,   124,   123,    -1,    -1,
      43,    34,   289,    -1,    16,    34,   126,    -1,   127,    -1,
     130,    -1,    28,    -1,   128,    28,    -1,   128,   127,    -1,
     279,    44,   129,    -1,    28,    44,   134,    -1,   130,    44,
     134,    -1,   130,    -1,   131,   130,    -1,   131,    28,    -1,
     281,   282,   285,   132,    -1,   133,   132,    -1,    -1,    43,
      34,   285,    -1,   135,    28,    -1,   135,   134,    -1,   281,
     282,   285,   136,    -1,   137,   136,    -1,    -1,    43,    34,
     285,    -1,    17,    34,   139,    -1,   140,    -1,   143,    -1,
      28,    -1,   141,    28,    -1,   141,   140,    -1,   279,    44,
     142,    -1,    28,    44,   147,    -1,   143,    44,   147,    -1,
     143,    -1,   144,    28,    -1,   144,   143,    -1,   281,   282,
     285,   145,    -1,   146,   145,    -1,    -1,    43,    34,   285,
      -1,   148,    28,    -1,   148,   147,    -1,   281,   282,   285,
     149,    -1,   150,   149,    -1,    -1,    43,    34,   285,    -1,
       9,    34,   152,    -1,   153,    -1,   156,    -1,    28,    -1,
     154,    28,    -1,   154,   153,    -1,   279,    44,   155,    -1,
      28,    44,   160,    -1,   156,    44,   160,    -1,   156,    -1,
     157,   156,    -1,   157,    28,    -1,   281,   282,   285,   158,
      -1,   159,   158,    -1,    -1,    43,    34,   285,    -1,   161,
      28,    -1,   161,   160,    -1,   281,   282,   285,   162,    -1,
     163,   162,    -1,    -1,    43,    34,   285,    -1,    18,    34,
     165,    -1,   166,    -1,    28,    -1,   167,    28,    -1,   167,
     166,    -1,   279,    44,   168,    -1,   169,   168,    -1,   169,
      28,    -1,   281,   282,   289,   289,   170,    -1,   171,   170,
      -1,    -1,    43,    34,   289,   289,    -1,    21,    34,   173,
      -1,   174,    -1,   177,    -1,   175,    28,    -1,   175,   174,
      -1,   279,    44,   176,    -1,   177,    44,   181,    -1,   177,
      -1,   178,    28,    -1,   178,   177,    -1,   282,   285,   179,
      -1,   180,   179,    -1,    -1,    43,    34,   285,    -1,   182,
      28,    -1,   182,   181,    -1,   282,   285,   183,    -1,   184,
     183,    -1,    -1,    43,    34,   285,    -1,    22,    34,   186,
      -1,   187,    -1,   190,    -1,   188,    28,    -1,   188,   187,
      -1,   279,    44,   189,    -1,   190,    44,   194,    -1,   190,
      -1,   191,    28,    -1,   191,   190,    -1,   282,   285,   192,
      -1,   193,   192,    -1,    -1,    43,    34,   285,    -1,   195,
      28,    -1,   195,   194,    -1,   282,   285,   196,    -1,   197,
     196,    -1,    -1,    43,    34,   285,    -1,    10,    34,   199,
      -1,   200,    -1,   203,    -1,   201,    28,    -1,   201,   200,
      -1,   279,    44,   202,    -1,   203,    44,   207,    -1,   203,
      -1,   204,    28,    -1,   204,   203,    -1,   282,   285,   205,
      -1,   206,   205,    -1,    -1,    43,    34,   285,    -1,   208,
      28,    -1,   208,   207,    -1,   282,   285,   209,    -1,   210,
     209,    -1,    -1,    43,    34,   285,    -1,    11,   277,   284,
     289,   289,   289,   289,   212,    -1,    11,   279,   283,   289,
     289,   289,   289,   214,    -1,   213,   212,    -1,    28,    -1,
     289,   289,   289,   216,   216,    -1,   215,   214,    -1,    28,
      -1,   289,   289,   289,   216,   216,    -1,    43,    34,   289,
      -1,    -1,    19,    34,   218,    -1,   219,    28,    -1,   219,
     218,    -1,   279,    44,   281,   282,   289,   289,   289,   220,
      -1,   221,   220,    -1,    -1,    43,    34,   289,   289,   289,
      -1,    20,    34,   223,    -1,   224,    28,    -1,   224,   223,
      -1,   225,   226,    -1,   279,    44,   281,   282,   289,   289,
     289,   289,   289,   227,    -1,   281,   282,   289,   289,   289,
     289,   289,   229,    -1,   228,   227,    -1,    -1,    43,    34,
     289,   289,   289,   289,   289,    -1,   230,   229,    -1,    -1,
      43,    34,   289,   289,   289,   289,   289,    -1,    23,    34,
     232,    28,    -1,   232,   233,    -1,   233,    -1,   279,    44,
     238,   234,   235,    -1,    44,   242,    -1,    -1,   289,   285,
     289,   236,    -1,    -1,   237,   236,    -1,    -1,    43,    34,
     289,   285,   289,    -1,   239,    28,    -1,   239,   238,    -1,
     282,   289,   285,   289,   240,    -1,   241,   240,    -1,    -1,
      43,    34,   289,   285,   289,    -1,   243,    28,    -1,   243,
     242,    -1,   282,   289,   285,   244,    -1,   245,   244,    -1,
      -1,    43,    34,   289,   285,    -1,    24,    34,   247,    -1,
     248,    28,    -1,   248,   247,    -1,   279,   282,   289,   289,
     249,    -1,   279,    44,   282,   289,   289,   249,    -1,   250,
     249,    -1,    -1,    43,    34,   289,    -1,   252,   251,    -1,
      28,    -1,    25,   278,    34,   254,   253,    -1,   289,   272,
      28,    -1,    -1,   255,   254,    -1,    28,    -1,   279,   257,
     256,   268,   269,    -1,   258,    -1,   258,    44,   262,    -1,
      34,    34,    34,    -1,    34,    34,    -1,   259,    28,    -1,
     259,   258,    -1,   282,   289,   285,   260,    -1,   261,   260,
      -1,    -1,    43,    34,   289,   285,    -1,   263,    28,    -1,
     263,   262,    -1,   282,   289,   285,   264,    -1,   265,   264,
      -1,    -1,    43,    34,   289,   285,    -1,   267,   266,    -1,
      -1,    43,    34,   289,    -1,   289,   266,    -1,    -1,    26,
     280,   289,   270,    -1,    -1,   271,   270,    -1,    -1,    43,
      34,   289,    -1,   273,   272,    -1,    -1,    43,    34,   289,
      -1,    27,   275,    -1,   276,    28,    -1,   276,   275,    -1,
     281,   282,   277,   277,    34,   285,    -1,    37,    -1,    34,
      -1,   277,    -1,   277,    -1,   277,    -1,   277,    -1,   277,
      -1,   277,    -1,    34,    -1,    -1,   286,   287,    -1,   289,
      28,    -1,    -1,   289,   288,   287,    -1,     1,    28,    -1,
      35,    -1,    34,    -1,    39,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   114,   114,   115,   119,   120,   123,   124,   127,   128,
     131,   132,   135,   136,   139,   140,   143,   144,   147,   148,
     151,   152,   155,   156,   159,   160,   163,   164,   167,   168,
     171,   172,   175,   176,   179,   180,   183,   184,   187,   188,
     191,   192,   195,   196,   199,   200,   210,   214,   227,   231,
     235,   245,   259,   260,   263,   271,   272,   275,   277,   279,
     281,   283,   284,   286,   296,   299,   300,   303,   305,   320,
     323,   324,   325,   328,   329,   332,   339,   340,   341,   344,
     345,   348,   356,   357,   360,   367,   368,   372,   380,   381,
     384,   398,   401,   402,   403,   406,   407,   410,   416,   417,
     418,   421,   422,   425,   433,   434,   437,   444,   445,   448,
     456,   457,   460,   473,   476,   477,   480,   481,   484,   491,
     492,   495,   502,   503,   506,   518,   521,   522,   525,   526,
     529,   536,   537,   540,   547,   548,   551,   565,   568,   569,
     570,   573,   574,   577,   583,   584,   585,   588,   589,   592,
     600,   601,   604,   611,   612,   615,   623,   624,   627,   641,
     644,   645,   646,   649,   650,   653,   659,   660,   661,   664,
     665,   668,   676,   677,   680,   687,   688,   691,   699,   700,
     703,   717,   720,   721,   722,   725,   726,   729,   735,   736,
     737,   740,   741,   744,   752,   753,   756,   763,   764,   767,
     774,   775,   778,   793,   796,   797,   800,   801,   804,   810,
     811,   814,   821,   822,   825,   838,   841,   842,   845,   846,
     849,   855,   856,   859,   860,   863,   872,   873,   876,   883,
     884,   887,   896,   897,   900,   914,   917,   918,   921,   922,
     925,   931,   932,   935,   936,   939,   948,   949,   952,   959,
     960,   963,   972,   973,   976,   990,   993,   994,   997,   998,
    1001,  1007,  1008,  1011,  1012,  1015,  1024,  1025,  1028,  1035,
    1036,  1039,  1048,  1049,  1052,  1063,  1070,  1078,  1079,  1082,
    1088,  1089,  1092,  1098,  1103,  1116,  1119,  1120,  1123,  1131,
    1132,  1135,  1149,  1152,  1153,  1156,  1159,  1165,  1173,  1174,
    1177,  1183,  1184,  1187,  1200,  1203,  1204,  1207,  1214,  1215,
    1218,  1223,  1226,  1227,  1230,  1237,  1238,  1241,  1250,  1251,
    1254,  1261,  1262,  1265,  1274,  1275,  1278,  1292,  1295,  1296,
    1299,  1306,  1315,  1316,  1319,  1332,  1333,  1336,  1344,  1348,
    1351,  1352,  1355,  1362,  1363,  1366,  1370,  1376,  1377,  1380,
    1389,  1390,  1393,  1400,  1401,  1404,  1414,  1415,  1418,  1425,
    1426,  1429,  1435,  1440,  1445,  1449,  1453,  1454,  1457,  1463,
    1464,  1467,  1477,  1480,  1481,  1484,  1499,  1501,  1505,  1509,
    1513,  1517,  1521,  1525,  1529,  1538,  1538,  1543,  1551,  1550,
    1557,  1568,  1569,  1571
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "VALIDITY_FLAG", "CONV_FLAG",
  "ITERATION_FLAG", "PROC_COUNT_FLAG", "PHASE_COUNT_FLAG", "BOUND_FLAG",
  "DROP_PROBABILITY_FLAG", "SERVICE_EXCEEDED_FLAG", "DISTRIBUTION_FLAG",
  "WAITING_FLAG", "WAITING_VARIANCE_FLAG", "FWD_WAITING_FLAG",
  "FWD_WAITING_VARIANCE_FLAG", "SNR_WAITING_FLAG",
  "SNR_WAITING_VARIANCE_FLAG", "JOIN_FLAG", "HOLD_TIME_FLAG",
  "RWLOCK_HOLD_TIME_FLAG", "SERVICE_FLAG", "VARIANCE_FLAG", "THPT_UT_FLAG",
  "OPEN_ARRIV_FLAG", "PROC_FLAG", "GROUP_FLAG", "OVERTAKING_FLAG",
  "ENDLIST", "REAL_TIME", "USER_TIME", "SYST_TIME", "MAX_RSS", "SOLVER",
  "INTEGER", "FLOAT", "TIME", "SYMBOL", "TEXT", "INFTY", "VARIABLE",
  "COMMENT", "CHAR", "'%'", "':'", "','", "'='", "$accept",
  "SRVN_output_file", "opt_variables", "opt_runtime", "opt_bound",
  "opt_waiting", "opt_waitvar", "opt_fwd_waiting", "opt_fwd_waitvar",
  "opt_snr_waiting", "opt_snr_waitvar", "opt_drop_prob", "opt_join",
  "opt_service", "opt_variance", "opt_service_exceeded",
  "opt_distribution", "opt_hold_time", "opt_rwlock_hold_time",
  "opt_thpt_ut", "opt_open_arriv", "opt_proc", "opt_overtaking", "general",
  "validity_rep", "conv_rep", "iteration_rep", "proc_count_rep",
  "phase_count_rep", "variables", "variables_entry", "runtime",
  "runtime_tbl_entry", "bound", "bound_tbl", "bound_tbl_entry", "waiting",
  "waiting_fmt", "waiting_t_tbl", "waiting_t_entry", "waiting_t_choice",
  "waiting_e_tbl", "waiting_e_entry", "waiting_e_conf_tbl",
  "waiting_e_conf_entry", "waiting_a_tbl", "waiting_a_entry",
  "waiting_a_conf_tbl", "waiting_a_conf_entry", "waitvar", "waitvar_fmt",
  "waitvar_t_tbl", "waitvar_t_entry", "waitvar_t_choice", "waitvar_e_tbl",
  "waitvar_e_entry", "waitvar_e_conf_tbl", "waitvar_e_conf_entry",
  "waitvar_a_tbl", "waitvar_a_entry", "waitvar_a_conf_tbl",
  "waitvar_a_conf_entry", "fwd_waiting", "fwd_waiting_fmt",
  "fwd_waiting_t_tbl", "fwd_waiting_t_entry", "fwd_waiting_e_tbl",
  "fwd_waiting_e_entry", "fwd_waiting_e_conf_tbl",
  "fwd_waiting_e_conf_entry", "fwd_waitvar", "fwd_waitvar_fmt",
  "fwd_waitvar_t_tbl", "fwd_waitvar_t_entry", "fwd_waitvar_e_tbl",
  "fwd_waitvar_e_entry", "fwd_waitvar_e_conf_tbl",
  "fwd_waitvar_e_conf_entry", "snr_waiting", "snr_waiting_fmt",
  "snr_waiting_t_tbl", "snr_waiting_t_entry", "snr_waiting_t_choice",
  "snr_waiting_e_tbl", "snr_waiting_e_entry", "snr_waiting_e_conf_tbl",
  "snr_waiting_e_conf_entry", "snr_waiting_a_tbl", "snr_waiting_a_entry",
  "snr_waiting_a_conf_tbl", "snr_waiting_a_conf_entry", "snr_waitvar",
  "snr_waitvar_fmt", "snr_waitvar_t_tbl", "snr_waitvar_t_entry",
  "snr_waitvar_t_choice", "snr_waitvar_e_tbl", "snr_waitvar_e_entry",
  "snr_waitvar_e_conf_tbl", "snr_waitvar_e_conf_entry",
  "snr_waitvar_a_tbl", "snr_waitvar_a_entry", "snr_waitvar_a_conf_tbl",
  "snr_waitvar_a_conf_entry", "drop_prob", "drop_prob_fmt",
  "drop_prob_t_tbl", "drop_prob_t_entry", "drop_prob_t_choice",
  "drop_prob_e_tbl", "drop_prob_e_entry", "drop_prob_e_conf_tbl",
  "drop_prob_e_conf_entry", "drop_prob_a_tbl", "drop_prob_a_entry",
  "drop_prob_a_conf_tbl", "drop_prob_a_conf_entry", "join", "join_fmt",
  "join_t_tbl", "join_t_entry", "join_e_tbl", "join_e_entry",
  "join_conf_tbl", "join_conf_entry", "service", "service_fmt",
  "service_t_tbl", "service_t_entry", "service_t_choice", "service_e_tbl",
  "service_e_entry", "service_e_conf_tbl", "service_e_conf_entry",
  "service_a_tbl", "service_a_entry", "service_a_conf_tbl",
  "service_a_conf_entry", "variance", "variance_fmt", "variance_t_tbl",
  "variance_t_entry", "variance_t_choice", "variance_e_tbl",
  "variance_e_entry", "variance_e_conf_tbl", "variance_e_conf_entry",
  "variance_a_tbl", "variance_a_entry", "variance_a_conf_tbl",
  "variance_a_conf_entry", "service_exceeded", "service_exceeded_fmt",
  "service_exceeded_t_tbl", "service_exceeded_t_entry",
  "service_exceeded_t_choice", "service_exceeded_e_tbl",
  "service_exceeded_e_entry", "service_exceeded_e_conf_tbl",
  "service_exceeded_e_conf_entry", "service_exceeded_a_tbl",
  "service_exceeded_a_entry", "service_exceeded_a_conf_tbl",
  "service_exceeded_a_conf_entry", "distribution", "opt_bin_list",
  "bin_list", "opt_act_bin_list", "act_bin_list", "opt_bin_conf",
  "hold_time", "hold_time_t_tbl", "hold_time_t_entry",
  "hold_time_t_conf_tbl", "hold_time_t_conf_entry", "rwlock_hold_time",
  "rwlock_hold_time_t_tbl", "rwlock_hold_time_t_entry",
  "reader_hold_time_t_entry", "writer_hold_time_t_entry",
  "reader_hold_time_t_conf_tbl", "reader_hold_time_t_conf_entry",
  "writer_hold_time_t_conf_tbl", "writer_hold_time_t_conf_entry",
  "thpt_ut", "thpt_ut_t_tbl", "thpt_ut_t_entry", "opt_thpt_ut_a_tbl",
  "opt_thpt_total", "thpt_ut_t_conf_tbl", "thpt_ut_t_conf_entry",
  "thpt_ut_e_tbl", "thpt_ut_e_entry", "thpt_ut_e_conf_tbl",
  "thpt_ut_e_conf_entry", "thpt_ut_a_tbl", "thpt_ut_a_entry",
  "thpt_ut_act_conf_tbl", "thpt_ut_act_conf_entry", "open_arriv",
  "open_arriv_tbl", "open_arriv_entry", "open_arriv_conf_tbl",
  "open_arriv_conf_entry", "proc", "processor", "opt_processor_total",
  "proc_tbl", "proc_tbl_entry", "proc_task", "proc_task_info",
  "proc_entry_tbl", "proc_entry", "proc_entry_conf_tbl", "proc_entry_conf",
  "proc_activity_tbl", "proc_activity", "proc_activity_conf_tbl",
  "proc_activity_conf", "proc_task_conf_tbl", "proc_task_conf_entry",
  "opt_proc_task_total", "opt_group_util", "opt_group_util_conf",
  "group_util_conf_entry", "processor_conf_tbl", "processor_conf_entry",
  "overtaking", "overtaking_e_tbl", "overtaking_entry", "identifier",
  "proc_identifier", "task_identifier", "group_identifier",
  "from_identifier", "to_identifier", "activity_identifier",
  "phase_identifier", "float_phase_list", "@1", "float_list", "@2", "real", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,    37,    58,    44,    61
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint16 yyr1[] =
{
       0,    47,    48,    48,    49,    49,    50,    50,    51,    51,
      52,    52,    53,    53,    54,    54,    55,    55,    56,    56,
      57,    57,    58,    58,    59,    59,    60,    60,    61,    61,
      62,    62,    63,    63,    64,    64,    65,    65,    66,    66,
      67,    67,    68,    68,    69,    69,    70,    71,    72,    73,
      74,    75,    76,    76,    77,    78,    78,    79,    79,    79,
      79,    79,    79,    79,    80,    81,    81,    82,    82,    83,
      84,    84,    84,    85,    85,    86,    87,    87,    87,    88,
      88,    89,    90,    90,    91,    92,    92,    93,    94,    94,
      95,    96,    97,    97,    97,    98,    98,    99,   100,   100,
     100,   101,   101,   102,   103,   103,   104,   105,   105,   106,
     107,   107,   108,   109,   110,   110,   111,   111,   112,   113,
     113,   114,   115,   115,   116,   117,   118,   118,   119,   119,
     120,   121,   121,   122,   123,   123,   124,   125,   126,   126,
     126,   127,   127,   128,   129,   129,   129,   130,   130,   131,
     132,   132,   133,   134,   134,   135,   136,   136,   137,   138,
     139,   139,   139,   140,   140,   141,   142,   142,   142,   143,
     143,   144,   145,   145,   146,   147,   147,   148,   149,   149,
     150,   151,   152,   152,   152,   153,   153,   154,   155,   155,
     155,   156,   156,   157,   158,   158,   159,   160,   160,   161,
     162,   162,   163,   164,   165,   165,   166,   166,   167,   168,
     168,   169,   170,   170,   171,   172,   173,   173,   174,   174,
     175,   176,   176,   177,   177,   178,   179,   179,   180,   181,
     181,   182,   183,   183,   184,   185,   186,   186,   187,   187,
     188,   189,   189,   190,   190,   191,   192,   192,   193,   194,
     194,   195,   196,   196,   197,   198,   199,   199,   200,   200,
     201,   202,   202,   203,   203,   204,   205,   205,   206,   207,
     207,   208,   209,   209,   210,   211,   211,   212,   212,   213,
     214,   214,   215,   216,   216,   217,   218,   218,   219,   220,
     220,   221,   222,   223,   223,   224,   225,   226,   227,   227,
     228,   229,   229,   230,   231,   232,   232,   233,   234,   234,
     235,   235,   236,   236,   237,   238,   238,   239,   240,   240,
     241,   242,   242,   243,   244,   244,   245,   246,   247,   247,
     248,   248,   249,   249,   250,   251,   251,   252,   253,   253,
     254,   254,   255,   256,   256,   257,   257,   258,   258,   259,
     260,   260,   261,   262,   262,   263,   264,   264,   265,   266,
     266,   267,   268,   268,   269,   269,   270,   270,   271,   272,
     272,   273,   274,   275,   275,   276,   277,   277,   278,   279,
     280,   281,   282,   283,   284,   286,   285,   287,   288,   287,
     287,   289,   289,   289
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,    22,     1,     2,     0,     1,     0,     1,     0,
       1,     0,     1,     0,     1,     0,     1,     0,     1,     0,
       1,     0,     1,     0,     1,     0,     1,     0,     1,     0,
       1,     0,     2,     0,     1,     0,     1,     0,     1,     0,
       1,     0,     1,     0,     1,     0,     5,     2,     2,     2,
       2,     2,     1,     3,     3,     1,     2,     2,     2,     2,
       1,     2,     8,    13,     3,     2,     2,     2,     4,     3,
       1,     1,     1,     2,     2,     3,     3,     3,     1,     2,
       2,     4,     2,     0,     3,     2,     2,     4,     2,     0,
       3,     3,     1,     1,     1,     2,     2,     3,     3,     3,
       1,     2,     2,     4,     2,     0,     3,     2,     2,     4,
       2,     0,     3,     3,     1,     1,     2,     2,     3,     2,
       2,     4,     2,     0,     3,     3,     1,     1,     2,     2,
       3,     2,     2,     4,     2,     0,     3,     3,     1,     1,
       1,     2,     2,     3,     3,     3,     1,     2,     2,     4,
       2,     0,     3,     2,     2,     4,     2,     0,     3,     3,
       1,     1,     1,     2,     2,     3,     3,     3,     1,     2,
       2,     4,     2,     0,     3,     2,     2,     4,     2,     0,
       3,     3,     1,     1,     1,     2,     2,     3,     3,     3,
       1,     2,     2,     4,     2,     0,     3,     2,     2,     4,
       2,     0,     3,     3,     1,     1,     2,     2,     3,     2,
       2,     5,     2,     0,     4,     3,     1,     1,     2,     2,
       3,     3,     1,     2,     2,     3,     2,     0,     3,     2,
       2,     3,     2,     0,     3,     3,     1,     1,     2,     2,
       3,     3,     1,     2,     2,     3,     2,     0,     3,     2,
       2,     3,     2,     0,     3,     3,     1,     1,     2,     2,
       3,     3,     1,     2,     2,     3,     2,     0,     3,     2,
       2,     3,     2,     0,     3,     8,     8,     2,     1,     5,
       2,     1,     5,     3,     0,     3,     2,     2,     8,     2,
       0,     5,     3,     2,     2,     2,    10,     8,     2,     0,
       7,     2,     0,     7,     4,     2,     1,     5,     2,     0,
       4,     0,     2,     0,     5,     2,     2,     5,     2,     0,
       5,     2,     2,     4,     2,     0,     4,     3,     2,     2,
       5,     6,     2,     0,     3,     2,     1,     5,     3,     0,
       2,     1,     5,     1,     3,     3,     2,     2,     2,     4,
       2,     0,     4,     2,     2,     4,     2,     0,     4,     2,
       0,     3,     2,     0,     4,     0,     2,     0,     3,     2,
       0,     3,     2,     2,     2,     6,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     0,     2,     2,     0,     3,
       2,     1,     1,     1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       0,     3,     0,     0,     5,     0,    47,     1,     0,     7,
       5,    52,     0,     0,     0,     0,     0,     0,     0,     0,
      60,     9,     6,    55,     4,     0,   392,   391,   393,    48,
       0,     0,    54,    57,    58,    59,    61,     0,     0,    11,
       8,    56,    53,    49,     0,     0,     0,     0,     0,    13,
      10,    50,     0,    46,     0,   377,   376,    64,     0,     0,
       0,     0,    15,    12,    51,     0,    65,    66,     0,    67,
      72,    69,    70,     0,    71,     0,   381,     0,     0,     0,
       0,    17,    14,     0,     0,    73,    74,   379,    80,    79,
     381,     0,   382,   385,    94,    91,    92,     0,    93,     0,
       0,     0,     0,     0,    19,    16,     0,    68,     0,    75,
      78,    83,     0,    95,    96,   101,   102,     0,   385,   115,
     113,   114,     0,     0,     0,     0,    21,    18,    62,     0,
       0,     0,     0,    81,    83,     0,   386,   388,     0,    97,
     100,   105,   116,   117,     0,   127,   125,   126,     0,     0,
       0,     0,    23,    20,     0,    76,     0,     0,    77,   385,
      82,   390,   387,     0,     0,     0,     0,   103,   105,   118,
       0,     0,   128,   129,     0,   140,   137,   138,     0,   139,
       0,     0,     0,     0,     0,    25,    22,     0,    85,    86,
     385,    84,   389,    98,     0,     0,    99,   385,   104,   119,
     120,     0,   130,     0,     0,   141,   142,   148,   147,     0,
     385,   162,   159,   160,     0,   161,     0,     0,     0,     0,
       0,    27,    24,     0,    89,   107,   108,   385,   106,   123,
     131,   132,     0,     0,   143,   146,   151,   163,   164,   169,
     170,     0,   385,   184,   181,   182,     0,   183,     0,     0,
       0,     0,     0,    29,    26,     0,     0,    87,    89,   111,
       0,   121,   123,   135,     0,     0,     0,   149,   151,     0,
     165,   168,   173,   185,   186,   192,   191,     0,   385,   205,
     203,   204,     0,     0,     0,     0,    31,    28,    63,   385,
      88,     0,   109,   111,     0,   122,     0,   133,   135,   144,
       0,     0,   145,   385,   150,     0,     0,     0,   171,   173,
       0,   187,   190,   195,   206,   207,     0,   215,   216,     0,
     217,     0,   382,     0,   385,     0,     0,    33,    30,    90,
     385,   110,   124,     0,   134,   153,   154,   385,   152,   166,
       0,     0,   167,   385,   172,     0,     0,     0,   193,   195,
     208,     0,     0,   218,   219,   223,   224,     0,   227,   235,
     236,     0,   237,     0,     0,   385,     0,    35,   112,   136,
     157,   175,   176,   385,   174,   188,     0,     0,   189,   385,
     194,   210,   209,     0,   220,   222,     0,   225,   227,   238,
     239,   243,   244,     0,   247,   255,   256,     0,   257,     0,
       0,   385,     0,     0,    37,    32,    34,     0,   155,   157,
     179,   197,   198,   385,   196,     0,     0,   385,   226,   240,
     242,     0,   245,   247,   258,   259,   263,   264,     0,   267,
     379,     0,     0,     0,    39,    36,   385,   156,     0,   177,
     179,   201,   213,   221,     0,   385,   228,     0,   385,   246,
     260,   262,     0,   265,   267,   384,     0,   383,     0,   285,
       0,     0,     0,     0,    41,    38,   158,   385,   178,     0,
     199,   201,     0,   211,   213,   229,   230,   233,   241,     0,
     385,   248,     0,   385,   266,     0,     0,   286,   287,     0,
     292,     0,     0,     0,     0,     0,    43,    40,   180,   385,
     200,     0,   212,     0,   231,   233,   249,   250,   253,   261,
       0,   385,   268,     0,     0,     0,   293,   294,   295,     0,
       0,     0,   306,     0,     0,     0,   336,    45,    42,     0,
     202,     0,   385,   232,     0,   251,   253,   269,   270,   273,
       0,     0,     0,     0,     0,   304,   305,     0,   327,     0,
       0,   378,     0,     0,     2,    44,   335,   214,   234,   385,
     252,     0,   271,   273,     0,     0,     0,     0,     0,   309,
       0,     0,   328,   329,     0,     0,     0,   372,     0,     0,
     254,   385,   272,   278,   275,     0,     0,   281,   276,     0,
       0,     0,     0,     0,     0,   311,   315,   316,   385,     0,
       0,   341,   339,     0,     0,   373,   374,     0,   274,   277,
       0,   280,     0,   290,     0,     0,   308,     0,     0,   307,
     385,     0,     0,   333,   337,   370,   340,     0,     0,     0,
     284,   284,     0,   288,   290,     0,     0,   321,   322,   385,
       0,   319,   333,     0,   330,   333,     0,     0,   370,   346,
     363,   343,     0,     0,     0,     0,   284,   284,     0,   289,
     302,     0,   325,   313,     0,   317,   319,   331,     0,   332,
       0,   338,   369,   345,   365,   360,     0,   347,   348,   385,
     385,     0,   279,   282,     0,     0,   297,   302,   299,     0,
     323,   325,     0,   310,   313,     0,   318,   334,   371,     0,
     342,     0,   362,   360,   344,     0,     0,   351,   375,   283,
       0,     0,   301,     0,   296,   299,     0,   324,     0,   312,
     385,   380,     0,     0,   359,   353,   354,   385,     0,   349,
     351,   291,     0,     0,   298,   385,   385,     0,   367,   361,
     357,     0,   350,     0,     0,   326,     0,   320,     0,   364,
     367,     0,   355,   357,   385,     0,     0,   314,     0,   366,
       0,   356,   352,     0,     0,   368,   385,   303,     0,   358,
     300
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     3,     9,    21,    39,    49,    62,    81,   104,   126,
     152,   185,   221,   253,   286,   327,   367,   404,   434,   464,
     496,   527,   554,     4,     5,    13,    31,    45,    53,    10,
      11,    22,    23,    40,    57,    58,    50,    71,    72,    73,
     109,    74,    75,   133,   134,   155,   156,   257,   258,    63,
      95,    96,    97,   139,    98,    99,   167,   168,   193,   194,
     292,   293,    82,   120,   121,   122,   169,   170,   261,   262,
     105,   146,   147,   148,   202,   203,   297,   298,   127,   176,
     177,   178,   234,   179,   180,   267,   268,   299,   300,   408,
     409,   153,   212,   213,   214,   270,   215,   216,   308,   309,
     339,   340,   439,   440,   186,   244,   245,   246,   311,   247,
     248,   348,   349,   375,   376,   470,   471,   222,   280,   281,
     282,   350,   351,   473,   474,   254,   317,   318,   319,   384,
     320,   321,   387,   388,   443,   444,   504,   505,   287,   359,
     360,   361,   419,   362,   363,   422,   423,   478,   479,   535,
     536,   328,   395,   396,   397,   450,   398,   399,   453,   454,
     509,   510,   562,   563,   405,   584,   585,   588,   589,   656,
     406,   459,   460,   633,   634,   435,   490,   491,   492,   518,
     714,   715,   686,   687,   465,   521,   522,   595,   619,   693,
     694,   569,   570,   665,   666,   616,   617,   690,   691,   497,
     548,   549,   644,   645,   528,   529,   624,   602,   603,   650,
     628,   651,   652,   729,   730,   704,   705,   752,   753,   702,
     703,   674,   700,   749,   750,   647,   648,   555,   577,   578,
      92,   552,    77,   722,    78,   324,   458,   456,   111,   112,
     136,   163,   137
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -606
static const yytype_int16 yypact[] =
{
      77,  -606,   -17,    32,    28,    58,  -606,  -606,    42,    44,
      28,    55,   -24,    94,   -24,    72,    75,    83,   102,   103,
    -606,   120,  -606,    44,  -606,    28,  -606,  -606,  -606,  -606,
     116,   145,  -606,  -606,  -606,  -606,  -606,   124,   125,   150,
    -606,  -606,  -606,  -606,   127,   165,   -24,    33,   133,   166,
    -606,  -606,   146,  -606,   -24,  -606,  -606,  -606,    -6,    22,
      68,   157,   181,  -606,  -606,   -24,  -606,  -606,    33,  -606,
    -606,  -606,  -606,    69,  -606,    76,   156,   159,    33,    81,
     176,   200,  -606,   -24,   -24,  -606,  -606,  -606,  -606,  -606,
    -606,    88,  -606,  -606,  -606,  -606,  -606,    95,  -606,    96,
     167,    33,   107,   188,   210,  -606,    25,  -606,   183,  -606,
     193,   192,     4,  -606,  -606,  -606,  -606,   111,  -606,  -606,
    -606,  -606,   115,   198,   119,   212,   230,  -606,    92,   -24,
      33,    33,   215,  -606,   192,   231,  -606,   235,   222,  -606,
     232,   225,  -606,  -606,    33,  -606,  -606,  -606,   129,   237,
     137,   250,   278,  -606,   -24,  -606,   141,    33,  -606,  -606,
    -606,  -606,  -606,     4,    33,    33,   252,  -606,   225,  -606,
     148,    33,  -606,  -606,    33,  -606,  -606,  -606,   149,  -606,
     153,   257,    33,   160,   260,   285,  -606,   272,  -606,  -606,
    -606,  -606,  -606,  -606,   164,    33,  -606,  -606,  -606,  -606,
    -606,   -24,  -606,   168,    33,  -606,  -606,  -606,  -606,   179,
    -606,  -606,  -606,  -606,   180,  -606,   184,   268,    33,   191,
     279,   299,  -606,   293,   302,  -606,  -606,  -606,  -606,   307,
    -606,  -606,   -24,   281,  -606,   288,   317,  -606,  -606,  -606,
    -606,   195,  -606,  -606,  -606,  -606,   196,  -606,   206,   321,
      33,   211,   303,   327,  -606,   332,   336,  -606,   302,   331,
     339,  -606,   307,   333,    33,    33,   341,  -606,   317,   334,
    -606,   337,   340,  -606,  -606,  -606,  -606,   216,  -606,  -606,
    -606,  -606,   223,   338,    33,   343,   351,  -606,  -606,  -606,
    -606,   345,  -606,   331,   -24,  -606,   346,  -606,   333,  -606,
     224,    33,  -606,  -606,  -606,    33,    33,   350,  -606,   340,
     342,  -606,   344,   347,  -606,  -606,    33,  -606,  -606,   228,
    -606,   236,   156,   349,  -606,    33,   355,  -606,  -606,  -606,
    -606,  -606,  -606,   -24,  -606,  -606,  -606,  -606,  -606,  -606,
     241,    33,  -606,  -606,  -606,    33,    33,   357,  -606,   347,
    -606,   243,    33,  -606,  -606,  -606,  -606,    33,   352,  -606,
    -606,   251,  -606,   255,   353,  -606,    33,     2,  -606,  -606,
     356,  -606,  -606,  -606,  -606,  -606,   263,    33,  -606,  -606,
    -606,  -606,  -606,   -24,  -606,   354,   360,  -606,   352,  -606,
    -606,  -606,  -606,    33,   358,  -606,  -606,   265,  -606,   270,
     361,  -606,    33,   362,   365,  -606,  -606,   366,  -606,   356,
     359,  -606,  -606,  -606,  -606,   -24,    33,  -606,  -606,  -606,
     363,   370,  -606,   358,  -606,  -606,  -606,  -606,    33,   367,
     372,    33,    33,   374,   386,  -606,  -606,  -606,   377,  -606,
     359,   369,   371,  -606,   277,  -606,  -606,    33,  -606,  -606,
    -606,   373,   379,  -606,   367,  -606,   -24,  -606,   -24,  -606,
     282,   375,    33,   381,   392,  -606,  -606,  -606,  -606,   384,
    -606,   369,   389,  -606,   371,  -606,  -606,   382,  -606,   289,
    -606,  -606,    33,  -606,  -606,   -24,   -24,  -606,  -606,    33,
    -606,   290,    33,   376,    33,   390,    54,  -606,  -606,  -606,
    -606,   -24,  -606,   393,  -606,   382,  -606,  -606,   383,  -606,
     294,  -606,  -606,   -24,   -24,    33,  -606,  -606,  -606,    33,
      33,   305,  -606,   387,    33,    33,  -606,   401,  -606,    54,
    -606,   -24,  -606,  -606,   395,  -606,   383,  -606,  -606,   391,
     -24,   -24,   -24,   -24,    33,  -606,  -606,    33,  -606,   306,
      49,  -606,   396,    33,  -606,  -606,  -606,  -606,  -606,  -606,
    -606,   398,  -606,   391,   -16,    56,   -24,   -24,   -24,   394,
     310,   -24,  -606,  -606,    33,   -24,   318,  -606,   320,    33,
    -606,  -606,  -606,  -606,  -606,   -16,   -24,  -606,  -606,    56,
     -24,   -24,   -24,   -24,    33,   -24,  -606,  -606,  -606,   -24,
     -24,  -606,   -24,   318,   399,  -606,  -606,    33,  -606,  -606,
     -24,  -606,   -24,   397,   -24,   -24,  -606,   325,   -24,  -606,
    -606,   -24,   -24,   400,  -606,   402,  -606,   403,    33,    33,
     404,   404,   405,  -606,   397,   -24,   -24,  -606,  -606,  -606,
     -24,   406,   400,   407,  -606,   400,   408,   420,   402,   417,
     -24,   409,   330,   -24,   421,   422,   404,   404,   -24,  -606,
     411,   -24,   414,   415,   425,  -606,   406,  -606,   -24,  -606,
     -24,  -606,  -606,  -606,   410,   418,    33,  -606,  -606,  -606,
    -606,   -24,  -606,  -606,   -24,   426,  -606,   411,   419,   429,
    -606,   414,   430,  -606,   415,   -24,  -606,  -606,  -606,    33,
    -606,   431,  -606,   418,  -606,   335,   -24,   423,  -606,  -606,
     -24,   -24,  -606,   433,  -606,   419,   -24,  -606,   -24,  -606,
    -606,  -606,   -24,   -24,  -606,  -606,  -606,  -606,   434,  -606,
     423,  -606,   -24,   -24,  -606,  -606,  -606,   -24,   427,  -606,
     428,   -24,  -606,   -24,   -24,  -606,   -24,  -606,   435,  -606,
     427,   438,  -606,   428,  -606,   -24,   -24,  -606,   -24,  -606,
     -24,  -606,  -606,   -24,   -24,  -606,  -606,  -606,   -24,  -606,
    -606
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -606,  -606,   465,  -606,  -606,  -606,  -606,  -606,  -606,  -606,
    -606,  -606,  -606,  -606,  -606,  -606,  -606,  -606,  -606,  -606,
    -606,  -606,  -606,  -606,  -606,  -606,  -606,  -606,  -606,   451,
    -606,   412,  -606,  -606,   432,  -606,  -606,  -606,   413,  -606,
    -606,   -67,  -606,   364,  -606,  -102,  -606,   219,  -606,  -606,
    -606,   388,  -606,  -606,   -90,  -606,   312,  -606,  -159,  -606,
     185,  -606,  -606,  -606,   378,  -606,   313,  -606,   226,  -606,
    -606,  -606,   348,  -606,   284,  -606,   194,  -606,  -606,  -606,
     315,  -606,  -606,  -164,  -606,   227,  -606,  -264,  -606,    82,
    -606,  -606,  -606,   280,  -606,  -606,  -186,  -606,   190,  -606,
    -299,  -606,    57,  -606,  -606,  -606,   258,  -606,  -606,  -231,
    -606,   158,  -606,  -343,  -606,    34,  -606,  -606,  -606,   234,
    -606,   155,  -606,    35,  -606,  -606,  -606,   189,  -606,  -606,
    -317,  -606,   130,  -606,    73,  -606,     7,  -606,  -606,  -606,
     152,  -606,  -606,  -349,  -606,    97,  -606,    43,  -606,   -15,
    -606,  -606,  -606,   126,  -606,  -606,  -379,  -606,    70,  -606,
      15,  -606,   -37,  -606,  -606,   -58,  -606,   -57,  -606,  -605,
    -606,    74,  -606,  -101,  -606,  -606,    45,  -606,  -606,  -606,
    -180,  -606,  -150,  -606,  -606,  -606,    17,  -606,  -606,  -154,
    -606,   -29,  -606,  -124,  -606,   -72,  -606,  -145,  -606,  -606,
      -2,  -606,  -544,  -606,    19,  -606,  -606,   -54,  -606,  -606,
    -606,   -95,  -606,  -179,  -606,  -155,  -606,  -195,  -606,  -143,
    -606,  -606,  -606,  -188,  -606,   -84,  -606,  -606,   -13,  -606,
     -10,  -606,   695,  -606,   984,   483,  -606,  -606,   385,  -606,
     436,  -606,   -12
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -393
static const yytype_int16 yytable[] =
{
      29,   302,    32,   378,   356,   135,   196,   342,    89,   116,
      26,    27,   583,   402,   392,    28,   208,   276,    26,    27,
     427,   403,    66,    28,   110,     6,   657,   140,    55,   158,
     240,    56,     7,   412,    54,   226,   336,    59,    26,    27,
     385,   372,    65,    28,   420,   235,   312,    69,    59,   451,
      76,   682,   683,    83,   189,   271,    26,    27,    84,   128,
      27,    28,    12,    87,    28,    90,    68,    55,     8,    76,
      56,   106,   107,    15,    16,    17,    18,    19,     1,   525,
       2,    90,   526,    55,   587,    20,    56,    87,    14,    90,
      26,    27,    87,   574,   129,    28,    70,    85,   667,    30,
      25,   669,    55,    55,    88,    56,    56,    90,    33,    94,
      55,    34,    87,    56,    87,    55,   108,   154,    56,    35,
      90,    90,    55,   113,   115,    56,  -392,  -392,    38,    55,
      55,  -392,    56,    56,    90,   119,    36,    37,    87,   138,
      76,    55,   187,   142,    56,    55,    90,   145,    56,    55,
      43,    44,    56,    55,    90,    90,    56,   172,    46,    47,
      90,    51,    48,    55,    90,   175,    56,    60,    87,   188,
      90,    55,    52,    76,    56,    55,   199,   205,    56,    61,
      64,   207,    55,    55,    90,    56,    56,    55,   211,   229,
      56,    79,   225,    90,    55,    80,   230,    56,    55,    90,
    -379,    56,    55,    91,    87,    56,    90,   233,   237,    76,
     102,   117,   239,    55,    55,   103,    56,    56,    55,   243,
     263,    56,   124,   269,   273,    55,   125,   130,    56,    55,
      55,    90,    56,    56,   275,   132,    87,   131,    90,   279,
      55,    87,   144,    56,   310,    55,   150,   151,    56,   159,
      55,   314,   335,    56,    90,    90,   353,    55,    55,   161,
      56,    56,    55,   162,   355,    56,   164,    90,   166,   371,
      55,   381,    87,    56,   322,    55,   165,    55,    56,   389,
      56,   174,   332,   391,   183,    55,   197,   184,    56,    55,
      90,   411,    56,   424,   219,    90,    90,    55,   426,    55,
      56,   209,    56,   220,    55,   475,    90,    56,   223,    87,
     487,    55,   241,   251,    56,   322,    55,   506,   516,    56,
     252,   369,   537,    55,    55,   264,    56,    56,    55,   255,
      90,    56,   265,   545,   572,    90,    90,   284,   596,    55,
      55,    90,    56,    56,    55,   256,   601,    56,   605,   285,
     260,    87,    55,   637,    55,    56,   322,    56,   677,    55,
     266,   326,    56,   725,    55,   277,    90,    56,   288,    55,
     289,   415,    56,   294,   291,   303,   296,   325,   305,   330,
     333,   306,   316,   307,   343,   433,   345,    87,   346,   366,
     347,   379,   430,   357,   417,   386,   432,   393,   416,   407,
     436,   421,   438,   442,   448,   428,   455,   447,   462,   463,
     452,   467,   469,   483,   472,   494,   495,   482,   499,   489,
     520,   457,    87,   501,   524,   503,   534,   532,   553,   559,
     576,   547,   581,   627,   561,    41,   699,   649,   594,   658,
     632,   668,   670,   643,   485,   646,   486,   655,   671,   664,
      87,   673,    87,   676,   685,   680,   681,   689,   692,   695,
     711,   701,   713,   716,   718,   723,   728,   733,   741,   758,
     748,   751,   760,   513,   514,    24,    42,   290,   331,    90,
     198,    87,    90,   200,    87,   114,    86,   231,   295,   531,
      67,   437,   334,   206,   238,   304,   173,   468,   160,   344,
     143,   540,   541,   141,   274,   500,   382,   380,   354,   502,
      90,    87,   533,   390,    87,   551,   315,   476,   418,   557,
     449,   560,   507,   425,   484,   538,   582,   609,   564,   565,
     566,   567,   611,   659,   488,   734,   517,   712,   546,    87,
     719,   597,   696,    90,   191,   638,   717,   573,   556,   626,
     726,   742,   586,   590,   591,   592,   593,   678,   761,   598,
     724,    93,   759,   600,   672,   606,    87,     0,    90,     0,
       0,     0,     0,   586,   610,   224,     0,   590,   612,   613,
     614,   615,   228,   620,   118,     0,     0,   622,   623,     0,
     625,     0,     0,    87,     0,   236,     0,   629,   630,   192,
     631,     0,   635,   636,     0,     0,   639,     0,     0,   641,
     642,     0,   259,     0,     0,     0,     0,     0,     0,   654,
       0,     0,     0,   660,   661,     0,     0,   272,   663,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   675,     0,
     190,   679,     0,     0,     0,     0,   684,     0,     0,   688,
       0,     0,     0,     0,   201,     0,   697,     0,   698,     0,
       0,     0,     0,   313,     0,   210,     0,     0,     0,   709,
       0,     0,   710,     0,   329,     0,     0,     0,   227,     0,
       0,     0,     0,   720,     0,     0,     0,   232,   338,   721,
       0,     0,     0,     0,   727,     0,     0,     0,   731,   732,
       0,   242,     0,     0,   735,     0,   736,     0,     0,   358,
     738,   739,     0,     0,     0,   368,     0,     0,     0,     0,
     743,   744,   370,     0,     0,   747,     0,     0,   374,   754,
       0,   755,   756,   278,   757,     0,     0,     0,     0,     0,
       0,     0,     0,   763,   764,     0,   765,     0,   766,     0,
     394,   767,   768,     0,     0,     0,   770,     0,   410,     0,
       0,     0,     0,     0,   414,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   100,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   337,     0,   429,     0,     0,     0,
       0,     0,   100,     0,     0,     0,     0,   123,   441,     0,
       0,     0,   446,     0,     0,     0,     0,     0,   365,     0,
       0,     0,     0,     0,     0,     0,     0,   123,     0,   149,
       0,   466,     0,     0,   373,     0,     0,     0,     0,     0,
     477,     0,     0,   481,     0,   383,     0,     0,     0,     0,
       0,     0,     0,   149,     0,   181,   365,     0,     0,   401,
       0,     0,   498,     0,     0,     0,     0,     0,     0,     0,
     413,     0,     0,     0,     0,   508,     0,     0,   512,     0,
       0,     0,     0,   181,     0,     0,   365,     0,   217,     0,
       0,     0,   401,     0,   530,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   539,     0,     0,   445,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   217,
       0,   401,     0,     0,   249,     0,     0,   558,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   445,     0,     0,
     480,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   249,     0,     0,   580,     0,   283,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   480,     0,     0,   511,   608,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   283,     0,   323,
       0,     0,     0,   621,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   511,     0,     0,     0,     0,   542,     0,
       0,     0,   543,     0,     0,   640,     0,     0,     0,     0,
       0,     0,     0,     0,   323,     0,     0,     0,     0,     0,
     364,     0,     0,     0,   662,     0,     0,   568,     0,     0,
     571,     0,     0,   575,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   571,     0,     0,   364,   599,     0,     0,
       0,   400,   607,   101,   707,   708,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   618,     0,     0,
       0,     0,     0,   101,     0,     0,     0,     0,     0,     0,
       0,     0,   400,     0,     0,     0,     0,   431,     0,     0,
     618,   101,     0,     0,     0,   737,     0,     0,     0,     0,
       0,   653,   740,     0,   157,   157,     0,     0,     0,     0,
     745,   746,     0,     0,     0,     0,     0,   461,   171,     0,
       0,     0,     0,     0,   182,   653,     0,     0,     0,   762,
     157,     0,     0,     0,     0,     0,     0,     0,   195,   195,
       0,   769,     0,     0,   171,   461,     0,   493,   204,   706,
       0,     0,     0,     0,   182,     0,     0,   218,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   195,     0,
       0,     0,     0,     0,     0,     0,   493,   204,   706,   523,
       0,     0,     0,   182,     0,     0,     0,     0,     0,     0,
     218,     0,     0,   250,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   523,     0,     0,   550,
       0,     0,     0,     0,     0,   218,     0,     0,     0,     0,
       0,     0,   250,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   550,     0,     0,     0,   301,   301,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   250,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   604,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   301,     0,     0,     0,     0,   341,
     341,     0,     0,     0,     0,     0,     0,     0,   604,     0,
     352,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   341,     0,     0,     0,     0,   377,
     377,     0,     0,     0,     0,   352,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     377,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   515,     0,     0,   519,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   544,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   579,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   579
};

static const yytype_int16 yycheck[] =
{
      12,   265,    14,   346,   321,     1,   165,   306,    75,    99,
      34,    35,    28,    11,   363,    39,   180,   248,    34,    35,
     399,    19,    28,    39,    91,    42,   631,   117,    34,   131,
     216,    37,     0,   376,    46,   194,   300,    47,    34,    35,
     357,   340,    54,    39,   393,   209,   277,    59,    58,   428,
      60,   656,   657,    65,   156,   241,    34,    35,    68,    34,
      35,    39,     4,    73,    39,    75,    44,    34,    40,    79,
      37,    83,    84,    29,    30,    31,    32,    33,     1,    25,
       3,    91,    28,    34,    28,    41,    37,    97,    46,    99,
      34,    35,   102,    44,   106,    39,    28,    28,   642,     5,
      45,   645,    34,    34,    28,    37,    37,   117,    36,    28,
      34,    36,   122,    37,   124,    34,    28,   129,    37,    36,
     130,   131,    34,    28,    28,    37,    34,    35,     8,    34,
      34,    39,    37,    37,   144,    28,    34,    34,   148,    28,
     150,    34,   154,    28,    37,    34,   156,    28,    37,    34,
      34,     6,    37,    34,   164,   165,    37,    28,    34,    34,
     170,    34,    12,    34,   174,    28,    37,    34,   178,    28,
     180,    34,     7,   183,    37,    34,    28,    28,    37,    13,
      34,    28,    34,    34,   194,    37,    37,    34,    28,   201,
      37,    34,    28,   203,    34,    14,    28,    37,    34,   209,
      44,    37,    34,    44,   214,    37,   216,    28,    28,   219,
      34,    44,    28,    34,    34,    15,    37,    37,    34,    28,
     232,    37,    34,    28,    28,    34,    16,    44,    37,    34,
      34,   241,    37,    37,    28,    43,   246,    44,   248,    28,
      34,   251,    44,    37,    28,    34,    34,    17,    37,    34,
      34,    28,    28,    37,   264,   265,    28,    34,    34,    28,
      37,    37,    34,    28,    28,    37,    44,   277,    43,    28,
      34,    28,   282,    37,   284,    34,    44,    34,    37,    28,
      37,    44,   294,    28,    34,    34,    34,     9,    37,    34,
     300,    28,    37,    28,    34,   305,   306,    34,    28,    34,
      37,    44,    37,    18,    34,    28,   316,    37,    36,   319,
      28,    34,    44,    34,    37,   325,    34,    28,    28,    37,
      21,   333,    28,    34,    34,    44,    37,    37,    34,    36,
     340,    37,    44,    28,    28,   345,   346,    34,    28,    34,
      34,   351,    37,    37,    34,    43,    28,    37,    28,    22,
      43,   361,    34,    28,    34,    37,   366,    37,    28,    34,
      43,    10,    37,    28,    34,    44,   376,    37,    36,    34,
      34,   383,    37,    34,    43,    34,    43,    34,    44,    34,
      34,    44,    44,    43,    34,    20,    44,   397,    44,    34,
      43,    34,   402,    44,    34,    43,    34,    44,    44,    43,
      34,    43,    43,   415,    34,    44,    34,    44,    34,    23,
      43,    34,    43,    34,    43,    34,    24,    44,    34,    44,
      44,   431,   432,    34,    34,    43,    43,    34,    27,    34,
      34,    44,    34,    34,    43,    23,    26,    34,    44,    34,
      43,    34,    34,    43,   456,    43,   458,    43,    28,    43,
     460,    34,   462,    44,    43,    34,    34,    43,    43,    34,
      34,    43,    43,    34,    34,    34,    43,    34,    34,    34,
      43,    43,    34,   485,   486,    10,    25,   258,   293,   489,
     168,   491,   492,   170,   494,    97,    73,   203,   262,   501,
      58,   409,   298,   178,   214,   268,   148,   440,   134,   309,
     122,   513,   514,   118,   246,   471,   351,   349,   319,   474,
     520,   521,   505,   361,   524,   525,   282,   444,   388,   531,
     423,   536,   479,   397,   454,   510,   563,   585,   540,   541,
     542,   543,   589,   634,   460,   715,   491,   687,   521,   549,
     694,   570,   666,   553,   159,   617,   691,   549,   529,   603,
     705,   730,   564,   565,   566,   567,   568,   652,   753,   571,
     703,    78,   750,   575,   648,   578,   576,    -1,   578,    -1,
      -1,    -1,    -1,   585,   586,   190,    -1,   589,   590,   591,
     592,   593,   197,   595,   101,    -1,    -1,   599,   600,    -1,
     602,    -1,    -1,   603,    -1,   210,    -1,   607,   610,   163,
     612,    -1,   614,   615,    -1,    -1,   618,    -1,    -1,   621,
     622,    -1,   227,    -1,    -1,    -1,    -1,    -1,    -1,   629,
      -1,    -1,    -1,   635,   636,    -1,    -1,   242,   640,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   650,    -1,
     157,   653,    -1,    -1,    -1,    -1,   658,    -1,    -1,   661,
      -1,    -1,    -1,    -1,   171,    -1,   668,    -1,   670,    -1,
      -1,    -1,    -1,   278,    -1,   182,    -1,    -1,    -1,   681,
      -1,    -1,   684,    -1,   289,    -1,    -1,    -1,   195,    -1,
      -1,    -1,    -1,   695,    -1,    -1,    -1,   204,   303,   699,
      -1,    -1,    -1,    -1,   706,    -1,    -1,    -1,   710,   711,
      -1,   218,    -1,    -1,   716,    -1,   718,    -1,    -1,   324,
     722,   723,    -1,    -1,    -1,   330,    -1,    -1,    -1,    -1,
     732,   733,   337,    -1,    -1,   737,    -1,    -1,   343,   741,
      -1,   743,   744,   250,   746,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   755,   756,    -1,   758,    -1,   760,    -1,
     365,   763,   764,    -1,    -1,    -1,   768,    -1,   373,    -1,
      -1,    -1,    -1,    -1,   379,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    79,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   301,    -1,   401,    -1,    -1,    -1,
      -1,    -1,    97,    -1,    -1,    -1,    -1,   102,   413,    -1,
      -1,    -1,   417,    -1,    -1,    -1,    -1,    -1,   325,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   122,    -1,   124,
      -1,   436,    -1,    -1,   341,    -1,    -1,    -1,    -1,    -1,
     445,    -1,    -1,   448,    -1,   352,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   148,    -1,   150,   363,    -1,    -1,   366,
      -1,    -1,   467,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     377,    -1,    -1,    -1,    -1,   480,    -1,    -1,   483,    -1,
      -1,    -1,    -1,   178,    -1,    -1,   393,    -1,   183,    -1,
      -1,    -1,   399,    -1,   499,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   511,    -1,    -1,   416,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   214,
      -1,   428,    -1,    -1,   219,    -1,    -1,   532,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   444,    -1,    -1,
     447,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   246,    -1,    -1,   559,    -1,   251,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   479,    -1,    -1,   482,   581,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   282,    -1,   284,
      -1,    -1,    -1,   598,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   510,    -1,    -1,    -1,    -1,   515,    -1,
      -1,    -1,   519,    -1,    -1,   620,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   319,    -1,    -1,    -1,    -1,    -1,
     325,    -1,    -1,    -1,   639,    -1,    -1,   544,    -1,    -1,
     547,    -1,    -1,   550,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   570,    -1,    -1,   361,   574,    -1,    -1,
      -1,   366,   579,    79,   679,   680,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   594,    -1,    -1,
      -1,    -1,    -1,    99,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   397,    -1,    -1,    -1,    -1,   402,    -1,    -1,
     617,   117,    -1,    -1,    -1,   720,    -1,    -1,    -1,    -1,
      -1,   628,   727,    -1,   130,   131,    -1,    -1,    -1,    -1,
     735,   736,    -1,    -1,    -1,    -1,    -1,   432,   144,    -1,
      -1,    -1,    -1,    -1,   150,   652,    -1,    -1,    -1,   754,
     156,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   164,   165,
      -1,   766,    -1,    -1,   170,   460,    -1,   462,   174,   676,
      -1,    -1,    -1,    -1,   180,    -1,    -1,   183,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   194,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   491,   203,   705,   494,
      -1,    -1,    -1,   209,    -1,    -1,    -1,    -1,    -1,    -1,
     216,    -1,    -1,   219,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   521,    -1,    -1,   524,
      -1,    -1,    -1,    -1,    -1,   241,    -1,    -1,    -1,    -1,
      -1,    -1,   248,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   549,    -1,    -1,    -1,   264,   265,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   277,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   576,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   300,    -1,    -1,    -1,    -1,   305,
     306,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   603,    -1,
     316,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   340,    -1,    -1,    -1,    -1,   345,
     346,    -1,    -1,    -1,    -1,   351,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     376,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   489,    -1,    -1,   492,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   520,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   553,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   578
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint16 yystos[] =
{
       0,     1,     3,    48,    70,    71,    42,     0,    40,    49,
      76,    77,     4,    72,    46,    29,    30,    31,    32,    33,
      41,    50,    78,    79,    49,    45,    34,    35,    39,   289,
       5,    73,   289,    36,    36,    36,    34,    34,     8,    51,
      80,    78,    76,    34,     6,    74,    34,    34,    12,    52,
      83,    34,     7,    75,   289,    34,    37,    81,    82,   277,
      34,    13,    53,    96,    34,   289,    28,    81,    44,   289,
      28,    84,    85,    86,    88,    89,   277,   279,   281,    34,
      14,    54,   109,   289,   277,    28,    85,   277,    28,    88,
     277,    44,   277,   282,    28,    97,    98,    99,   101,   102,
     279,   281,    34,    15,    55,   117,   289,   289,    28,    87,
      88,   285,   286,    28,    98,    28,   101,    44,   282,    28,
     110,   111,   112,   279,    34,    16,    56,   125,    34,   289,
      44,    44,    43,    90,    91,     1,   287,   289,    28,   100,
     101,   285,    28,   111,    44,    28,   118,   119,   120,   279,
      34,    17,    57,   138,   289,    92,    93,   281,    92,    34,
      90,    28,    28,   288,    44,    44,    43,   103,   104,   113,
     114,   281,    28,   119,    44,    28,   126,   127,   128,   130,
     131,   279,   281,    34,     9,    58,   151,   289,    28,    92,
     282,   285,   287,   105,   106,   281,   105,    34,   103,    28,
     113,   282,   121,   122,   281,    28,   127,    28,   130,    44,
     282,    28,   139,   140,   141,   143,   144,   279,   281,    34,
      18,    59,   164,    36,   285,    28,   105,   282,   285,   289,
      28,   121,   282,    28,   129,   130,   285,    28,   140,    28,
     143,    44,   282,    28,   152,   153,   154,   156,   157,   279,
     281,    34,    21,    60,   172,    36,    43,    94,    95,   285,
      43,   115,   116,   289,    44,    44,    43,   132,   133,    28,
     142,   143,   285,    28,   153,    28,   156,    44,   282,    28,
     165,   166,   167,   279,    34,    22,    61,   185,    36,    34,
      94,    43,   107,   108,    34,   115,    43,   123,   124,   134,
     135,   281,   134,    34,   132,    44,    44,    43,   145,   146,
      28,   155,   156,   285,    28,   166,    44,   173,   174,   175,
     177,   178,   277,   279,   282,    34,    10,    62,   198,   285,
      34,   107,   289,    34,   123,    28,   134,   282,   285,   147,
     148,   281,   147,    34,   145,    44,    44,    43,   158,   159,
     168,   169,   281,    28,   174,    28,   177,    44,   285,   186,
     187,   188,   190,   191,   279,   282,    34,    63,   285,   289,
     285,    28,   147,   282,   285,   160,   161,   281,   160,    34,
     158,    28,   168,   282,   176,   177,    43,   179,   180,    28,
     187,    28,   190,    44,   285,   199,   200,   201,   203,   204,
     279,   282,    11,    19,    64,   211,   217,    43,   136,   137,
     285,    28,   160,   282,   285,   289,    44,    34,   179,   189,
     190,    43,   192,   193,    28,   200,    28,   203,    44,   285,
     277,   279,    34,    20,    65,   222,    34,   136,    43,   149,
     150,   285,   289,   181,   182,   282,   285,    44,    34,   192,
     202,   203,    43,   205,   206,    34,   284,   277,   283,   218,
     219,   279,    34,    23,    66,   231,   285,    34,   149,    43,
     162,   163,    43,   170,   171,    28,   181,   285,   194,   195,
     282,   285,    44,    34,   205,   289,   289,    28,   218,    44,
     223,   224,   225,   279,    34,    24,    67,   246,   285,    34,
     162,    34,   170,    43,   183,   184,    28,   194,   285,   207,
     208,   282,   285,   289,   289,   281,    28,   223,   226,   281,
      44,   232,   233,   279,    34,    25,    28,    68,   251,   252,
     285,   289,    34,   183,    43,   196,   197,    28,   207,   285,
     289,   289,   282,   282,   281,    28,   233,    44,   247,   248,
     279,   277,   278,    27,    69,   274,   251,   289,   285,    34,
     196,    43,   209,   210,   289,   289,   289,   289,   282,   238,
     239,   282,    28,   247,    44,   282,    34,   275,   276,   281,
     285,    34,   209,    28,   212,   213,   289,    28,   214,   215,
     289,   289,   289,   289,    44,   234,    28,   238,   289,   282,
     289,    28,   254,   255,   279,    28,   275,   282,   285,   212,
     289,   214,   289,   289,   289,   289,   242,   243,   282,   235,
     289,   285,   289,   289,   253,   289,   254,    34,   257,   277,
     289,   289,    43,   220,   221,   289,   289,    28,   242,   289,
     285,   289,   289,    43,   249,   250,    43,   272,   273,    34,
     256,   258,   259,   282,   277,    43,   216,   216,    34,   220,
     289,   289,   285,   289,    43,   240,   241,   249,    34,   249,
      34,    28,   272,    34,   268,   289,    44,    28,   258,   289,
      34,    34,   216,   216,   289,    43,   229,   230,   289,    43,
     244,   245,    43,   236,   237,    34,   240,   289,   289,    26,
     269,    43,   266,   267,   262,   263,   282,   285,   285,   289,
     289,    34,   229,    43,   227,   228,    34,   244,    34,   236,
     289,   277,   280,    34,   266,    28,   262,   289,    43,   260,
     261,   289,   289,    34,   227,   289,   289,   285,   289,   289,
     285,    34,   260,   289,   289,   285,   285,   289,    43,   270,
     271,    43,   264,   265,   289,   289,   289,   289,    34,   270,
      34,   264,   285,   289,   289,   289,   289,   289,   289,   285,
     289
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 3:
#line 116 "srvn_result_gram.y"
    { yyclearin; }
    break;

  case 46:
#line 211 "srvn_result_gram.y"
    { set_general( (yyvsp[(1) - (5)].anInt), (yyvsp[(2) - (5)].aFloat), (yyvsp[(3) - (5)].anInt), (yyvsp[(4) - (5)].anInt), (yyvsp[(5) - (5)].anInt) ); }
    break;

  case 47:
#line 215 "srvn_result_gram.y"
    {
					if ( ( (yyvsp[(2) - (2)].aChar) == 'y' ) || ( (yyvsp[(2) - (2)].aChar) == 'Y' ) ) {
						(yyval.anInt) = 1;
					} else if ( ( (yyvsp[(2) - (2)].aChar) == 'n' ) || ( (yyvsp[(2) - (2)].aChar) == 'N' ) ) {
						(yyval.anInt) = 0;
					} else {
						results_error("Bad validity indicator character: %c\n", (yyvsp[(2) - (2)].aChar));
						YYERROR;
					}
				}
    break;

  case 48:
#line 228 "srvn_result_gram.y"
    { (yyval.aFloat) = (yyvsp[(2) - (2)].aFloat); }
    break;

  case 49:
#line 232 "srvn_result_gram.y"
    { (yyval.anInt) = (yyvsp[(2) - (2)].anInt); }
    break;

  case 50:
#line 236 "srvn_result_gram.y"
    {
					(yyval.anInt) = (yyvsp[(2) - (2)].anInt);
					if ( (yyvsp[(2) - (2)].anInt) <= 0 ) {
						results_error("Number of processors, %d, should be greater than zero", (yyvsp[(2) - (2)].anInt));
						YYERROR;
					}
				}
    break;

  case 51:
#line 246 "srvn_result_gram.y"
    {
					(yyval.anInt) = (yyvsp[(2) - (2)].anInt);
					if ( (yyvsp[(2) - (2)].anInt) <= 0 ) {
						results_error("Number of phases, %d, should be greater than zero", (yyvsp[(2) - (2)].anInt));
						YYERROR;
					}
				}
    break;

  case 57:
#line 276 "srvn_result_gram.y"
    { add_elapsed_time( (yyvsp[(2) - (2)].aFloat) ); }
    break;

  case 58:
#line 278 "srvn_result_gram.y"
    { add_user_time( (yyvsp[(2) - (2)].aFloat) ); }
    break;

  case 59:
#line 280 "srvn_result_gram.y"
    { add_system_time( (yyvsp[(2) - (2)].aFloat) ); }
    break;

  case 60:
#line 282 "srvn_result_gram.y"
    { add_comment( (yyvsp[(1) - (1)].aString) ); }
    break;

  case 62:
#line 285 "srvn_result_gram.y"
    { add_mva_solver_info( (yyvsp[(2) - (8)].anInt), (yyvsp[(3) - (8)].anInt), (yyvsp[(4) - (8)].aFloat), (yyvsp[(5) - (8)].aFloat), (yyvsp[(6) - (8)].aFloat), (yyvsp[(7) - (8)].aFloat), (yyvsp[(8) - (8)].anInt) ); }
    break;

  case 67:
#line 304 "srvn_result_gram.y"
    { add_bound( (yyvsp[(1) - (2)].aString), 0.0, (yyvsp[(2) - (2)].aFloat) ); free( (yyvsp[(1) - (2)].aString) ); }
    break;

  case 68:
#line 306 "srvn_result_gram.y"
    { add_bound( (yyvsp[(3) - (4)].aString), 0.0, (yyvsp[(4) - (4)].aFloat) ); free( (yyvsp[(1) - (4)].aString) ); free( (yyvsp[(3) - (4)].aString) ); }
    break;

  case 75:
#line 333 "srvn_result_gram.y"
    {
				free( task_name );
				task_name = 0;
			    }
    break;

  case 81:
#line 349 "srvn_result_gram.y"
    {
				add_waiting( (yyvsp[(1) - (4)].aString), (yyvsp[(2) - (4)].aString), (yyvsp[(3) - (4)].aFloatList) );
				free_from_and_to_name();
				free( (yyvsp[(3) - (4)].aFloatList) );
			    }
    break;

  case 84:
#line 361 "srvn_result_gram.y"
    {
				add_waiting_confidence( from_name, to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloatList) );
				free( (yyvsp[(3) - (3)].aFloatList) );
			    }
    break;

  case 87:
#line 373 "srvn_result_gram.y"
    {
				add_act_waiting( task_name, (yyvsp[(1) - (4)].aString), (yyvsp[(2) - (4)].aString), (yyvsp[(3) - (4)].aFloatList) );
				free_from_and_to_name();
				free( (yyvsp[(3) - (4)].aFloatList) );
			    }
    break;

  case 90:
#line 385 "srvn_result_gram.y"
    {
				add_act_waiting_confidence( task_name, from_name, to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloatList) );
				free( (yyvsp[(3) - (3)].aFloatList) );
			    }
    break;

  case 97:
#line 411 "srvn_result_gram.y"
    {
				free_task_name();
			    }
    break;

  case 103:
#line 426 "srvn_result_gram.y"
    {
				add_wait_variance( (yyvsp[(1) - (4)].aString), (yyvsp[(2) - (4)].aString), (yyvsp[(3) - (4)].aFloatList) );
				free_from_and_to_name();
				free( (yyvsp[(3) - (4)].aFloatList) );
			    }
    break;

  case 106:
#line 438 "srvn_result_gram.y"
    {
				add_wait_variance_confidence( from_name, to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloatList) );
				free( (yyvsp[(3) - (3)].aFloatList) );
			    }
    break;

  case 109:
#line 449 "srvn_result_gram.y"
    {
				add_act_wait_variance( task_name, (yyvsp[(1) - (4)].aString), (yyvsp[(2) - (4)].aString), (yyvsp[(3) - (4)].aFloatList) );
				free_from_and_to_name();
				free( (yyvsp[(3) - (4)].aFloatList) );
			    }
    break;

  case 112:
#line 461 "srvn_result_gram.y"
    {
				add_act_wait_variance_confidence( task_name, from_name, to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloatList) );
				free( (yyvsp[(3) - (3)].aFloatList) );
			    }
    break;

  case 118:
#line 485 "srvn_result_gram.y"
    {
				free( task_name );
				task_name = 0;
			    }
    break;

  case 121:
#line 496 "srvn_result_gram.y"
    {
				add_fwd_waiting( (yyvsp[(1) - (4)].aString), (yyvsp[(2) - (4)].aString), (yyvsp[(3) - (4)].aFloat) );
				free_from_and_to_name();
			    }
    break;

  case 124:
#line 507 "srvn_result_gram.y"
    {
				add_fwd_waiting_confidence( from_name, to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloat) );
			    }
    break;

  case 130:
#line 530 "srvn_result_gram.y"
    {
				free_task_name();
				task_name = 0;
			    }
    break;

  case 133:
#line 541 "srvn_result_gram.y"
    {
				add_fwd_wait_variance( (yyvsp[(1) - (4)].aString), (yyvsp[(2) - (4)].aString), (yyvsp[(3) - (4)].aFloat) );
				free_from_and_to_name();
			    }
    break;

  case 136:
#line 552 "srvn_result_gram.y"
    {
				add_fwd_wait_variance_confidence( from_name, to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloat) );
			    }
    break;

  case 143:
#line 578 "srvn_result_gram.y"
    {
				free_task_name();
			    }
    break;

  case 149:
#line 593 "srvn_result_gram.y"
    {
				add_snr_waiting( (yyvsp[(1) - (4)].aString), (yyvsp[(2) - (4)].aString), (yyvsp[(3) - (4)].aFloatList) );
				free_from_and_to_name();
				free( (yyvsp[(3) - (4)].aFloatList) );
			    }
    break;

  case 152:
#line 605 "srvn_result_gram.y"
    {
				add_snr_waiting_confidence( from_name, to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloatList) );
				free( (yyvsp[(3) - (3)].aFloatList) );
			    }
    break;

  case 155:
#line 616 "srvn_result_gram.y"
    {
				add_act_snr_waiting( task_name, (yyvsp[(1) - (4)].aString), (yyvsp[(2) - (4)].aString), (yyvsp[(3) - (4)].aFloatList) );
				free_from_and_to_name();
				free( (yyvsp[(3) - (4)].aFloatList) );
			    }
    break;

  case 158:
#line 628 "srvn_result_gram.y"
    {
				add_act_snr_waiting_confidence( task_name, from_name, to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloatList) );
				free( (yyvsp[(3) - (3)].aFloatList) );
			    }
    break;

  case 165:
#line 654 "srvn_result_gram.y"
    {
				free_task_name();
			    }
    break;

  case 171:
#line 669 "srvn_result_gram.y"
    {
				add_snr_wait_variance( (yyvsp[(1) - (4)].aString), (yyvsp[(2) - (4)].aString), (yyvsp[(3) - (4)].aFloatList) );
				free_from_and_to_name();
				free( (yyvsp[(3) - (4)].aFloatList) );
			    }
    break;

  case 174:
#line 681 "srvn_result_gram.y"
    {
				add_snr_wait_variance_confidence( from_name, to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloatList) );
				free( (yyvsp[(3) - (3)].aFloatList) );
			    }
    break;

  case 177:
#line 692 "srvn_result_gram.y"
    {
				add_act_snr_wait_variance( task_name, (yyvsp[(1) - (4)].aString), (yyvsp[(2) - (4)].aString), (yyvsp[(3) - (4)].aFloatList) );
				free_from_and_to_name();
				free( (yyvsp[(3) - (4)].aFloatList) );
			    }
    break;

  case 180:
#line 704 "srvn_result_gram.y"
    {
				add_act_snr_wait_variance_confidence( task_name, from_name, to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloatList) );
				free( (yyvsp[(3) - (3)].aFloatList) );
			    }
    break;

  case 187:
#line 730 "srvn_result_gram.y"
    {
				free_task_name();
			    }
    break;

  case 193:
#line 745 "srvn_result_gram.y"
    {
				add_drop_probability( (yyvsp[(1) - (4)].aString), (yyvsp[(2) - (4)].aString), (yyvsp[(3) - (4)].aFloatList) );
				free_from_and_to_name();
				free( (yyvsp[(3) - (4)].aFloatList) );
			    }
    break;

  case 196:
#line 757 "srvn_result_gram.y"
    {
				add_drop_probability_confidence( from_name, to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloatList) );
				free( (yyvsp[(3) - (3)].aFloatList) );
			    }
    break;

  case 199:
#line 768 "srvn_result_gram.y"
    {
				add_act_drop_probability( task_name, (yyvsp[(1) - (4)].aString), (yyvsp[(2) - (4)].aString), (yyvsp[(3) - (4)].aFloatList) );
				free_from_and_to_name();
				free( (yyvsp[(3) - (4)].aFloatList) );
			    }
    break;

  case 202:
#line 779 "srvn_result_gram.y"
    {
				add_act_drop_probability_confidence( task_name, from_name, to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloatList) );
				free( (yyvsp[(3) - (3)].aFloatList) );
			    }
    break;

  case 208:
#line 805 "srvn_result_gram.y"
    {
				free_task_name();
			    }
    break;

  case 211:
#line 815 "srvn_result_gram.y"
    {
				add_join( task_name, (yyvsp[(1) - (5)].aString), (yyvsp[(2) - (5)].aString), (yyvsp[(3) - (5)].aFloat), (yyvsp[(4) - (5)].aFloat) );
				free_from_and_to_name();
			    }
    break;

  case 214:
#line 826 "srvn_result_gram.y"
    {
				add_join_confidence( task_name, from_name, to_name, (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aFloat), (yyvsp[(4) - (4)].aFloat) );
			    }
    break;

  case 220:
#line 850 "srvn_result_gram.y"
    {
				free_task_name();
			    }
    break;

  case 225:
#line 864 "srvn_result_gram.y"
    {
				add_service( (yyvsp[(1) - (3)].aString), (yyvsp[(2) - (3)].aFloatList) );
				free( to_name );
				to_name = 0;
				free( (yyvsp[(2) - (3)].aFloatList) );
			    }
    break;

  case 228:
#line 877 "srvn_result_gram.y"
    {
				add_service_confidence( to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloatList) );
				free( (yyvsp[(3) - (3)].aFloatList) );
			    }
    break;

  case 231:
#line 888 "srvn_result_gram.y"
    {
				add_act_service( task_name, (yyvsp[(1) - (3)].aString), (yyvsp[(2) - (3)].aFloatList) );
				free( to_name );
				to_name = 0;
				free( (yyvsp[(2) - (3)].aFloatList) );
			    }
    break;

  case 234:
#line 901 "srvn_result_gram.y"
    {
				add_act_service_confidence( task_name, to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloatList) );
				free( (yyvsp[(3) - (3)].aFloatList) );
			    }
    break;

  case 240:
#line 926 "srvn_result_gram.y"
    {
				free_task_name();
			    }
    break;

  case 245:
#line 940 "srvn_result_gram.y"
    {
				add_variance( (yyvsp[(1) - (3)].aString), (yyvsp[(2) - (3)].aFloatList) );
				free( to_name );
				to_name = 0;
				free( (yyvsp[(2) - (3)].aFloatList) );
			    }
    break;

  case 248:
#line 953 "srvn_result_gram.y"
    {
				add_variance_confidence( to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloatList) );
				free( (yyvsp[(3) - (3)].aFloatList) );
			    }
    break;

  case 251:
#line 964 "srvn_result_gram.y"
    {
				add_act_variance( task_name, (yyvsp[(1) - (3)].aString), (yyvsp[(2) - (3)].aFloatList) );
				free( to_name );
				to_name = 0;
				free( (yyvsp[(2) - (3)].aFloatList) );
			    }
    break;

  case 254:
#line 977 "srvn_result_gram.y"
    {
				add_act_variance_confidence( task_name, to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloatList) );
				free( (yyvsp[(3) - (3)].aFloatList) );
			    }
    break;

  case 260:
#line 1002 "srvn_result_gram.y"
    {
				free_task_name();
			    }
    break;

  case 265:
#line 1016 "srvn_result_gram.y"
    {
				add_service_exceeded( (yyvsp[(1) - (3)].aString), (yyvsp[(2) - (3)].aFloatList) );
				free( to_name );
				to_name = 0;
				free( (yyvsp[(2) - (3)].aFloatList) );
			    }
    break;

  case 268:
#line 1029 "srvn_result_gram.y"
    {
				add_service_exceeded_confidence( to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloatList) );
				free( (yyvsp[(3) - (3)].aFloatList) );
			    }
    break;

  case 271:
#line 1040 "srvn_result_gram.y"
    {
				add_act_service_exceeded( task_name, (yyvsp[(1) - (3)].aString), (yyvsp[(2) - (3)].aFloatList) );
				free( to_name );
				to_name = 0;
				free( (yyvsp[(2) - (3)].aFloatList) );
			    }
    break;

  case 274:
#line 1053 "srvn_result_gram.y"
    {
				add_act_service_exceeded_confidence( task_name, to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloatList) );
				free( (yyvsp[(3) - (3)].aFloatList) );
			    }
    break;

  case 275:
#line 1064 "srvn_result_gram.y"
    {
				    entry_name = (yyvsp[(2) - (8)].aString);
				    add_histogram_statistics( entry_name, (yyvsp[(3) - (8)].anInt), (yyvsp[(4) - (8)].aFloat), (yyvsp[(5) - (8)].aFloat), (yyvsp[(6) - (8)].aFloat), (yyvsp[(7) - (8)].aFloat) );		/* Entry/phase */
				    free_entry_name();
				    entry_phase = 0;
				}
    break;

  case 276:
#line 1071 "srvn_result_gram.y"
    {
				    add_act_histogram_statistics( task_name, activity_name, (yyvsp[(4) - (8)].aFloat), (yyvsp[(5) - (8)].aFloat), (yyvsp[(6) - (8)].aFloat), (yyvsp[(7) - (8)].aFloat) );	/* Task/activity */
				    free_task_name();
				    free_activity_name();
				}
    break;

  case 279:
#line 1083 "srvn_result_gram.y"
    {
				    add_histogram_bin( entry_name, entry_phase, (yyvsp[(1) - (5)].aFloat), (yyvsp[(2) - (5)].aFloat), (yyvsp[(3) - (5)].aFloat), (yyvsp[(4) - (5)].aFloat), (yyvsp[(5) - (5)].aFloat) );		/* Entry/phase */
				}
    break;

  case 282:
#line 1093 "srvn_result_gram.y"
    {
				    add_act_histogram_bin( task_name, activity_name, (yyvsp[(1) - (5)].aFloat), (yyvsp[(2) - (5)].aFloat), (yyvsp[(3) - (5)].aFloat), (yyvsp[(4) - (5)].aFloat), (yyvsp[(5) - (5)].aFloat) );		/* Entry/phase */
				}
    break;

  case 283:
#line 1099 "srvn_result_gram.y"
    {
				    (yyval.aFloat)= (yyvsp[(3) - (3)].aFloat);
				}
    break;

  case 284:
#line 1103 "srvn_result_gram.y"
    {
				    (yyval.aFloat) = 0.0;
				}
    break;

  case 288:
#line 1124 "srvn_result_gram.y"
    {
				add_holding_time( (yyvsp[(1) - (8)].aString), (yyvsp[(3) - (8)].aString), (yyvsp[(4) - (8)].aString), (yyvsp[(5) - (8)].aFloat), (yyvsp[(6) - (8)].aFloat), (yyvsp[(7) - (8)].aFloat) );
				free_task_name();
				free_from_and_to_name();
			    }
    break;

  case 291:
#line 1136 "srvn_result_gram.y"
    {
				add_holding_time_confidence( task_name, from_name, to_name, (yyvsp[(2) - (5)].anInt), (yyvsp[(3) - (5)].aFloat), (yyvsp[(4) - (5)].aFloat), (yyvsp[(5) - (5)].aFloat) );
			    }
    break;

  case 296:
#line 1160 "srvn_result_gram.y"
    {
//				add_reader_holding_time( $1, $3, $4, $5, $6, $7, $8, $9);
			    }
    break;

  case 297:
#line 1166 "srvn_result_gram.y"
    {
//				add_writer_holding_time( task_name, $1, $2, $3, $4, $5, $6, $7 );
				free_task_name();
				free_from_and_to_name();
			    }
    break;

  case 300:
#line 1178 "srvn_result_gram.y"
    {
//				add_reader_holding_time_confidence( task_name, from_name, to_name, $2, $3, $4, $5, $6, $7 );
			    }
    break;

  case 303:
#line 1188 "srvn_result_gram.y"
    {
//				add_writer_holding_time_confidence( task_name, from_name, to_name, $2, $3, $4, $5, $6, $7 );
			    }
    break;

  case 307:
#line 1208 "srvn_result_gram.y"
    {
				add_thpt_ut( (yyvsp[(1) - (5)].aString) );
				free_task_name();
			    }
    break;

  case 310:
#line 1219 "srvn_result_gram.y"
    {
				total_thpt_ut( task_name, (yyvsp[(1) - (4)].aFloat), (yyvsp[(2) - (4)].aFloatList), (yyvsp[(3) - (4)].aFloat) );
				free( (yyvsp[(2) - (4)].aFloatList) );
			    }
    break;

  case 314:
#line 1231 "srvn_result_gram.y"
    {
				total_thpt_ut_confidence( task_name, (yyvsp[(2) - (5)].anInt), (yyvsp[(3) - (5)].aFloat), (yyvsp[(4) - (5)].aFloatList), (yyvsp[(5) - (5)].aFloat) );
				free( (yyvsp[(4) - (5)].aFloatList) );
			    }
    break;

  case 317:
#line 1242 "srvn_result_gram.y"
    {
				add_entry_thpt_ut( task_name, (yyvsp[(1) - (5)].aString), (yyvsp[(2) - (5)].aFloat), (yyvsp[(3) - (5)].aFloatList), (yyvsp[(4) - (5)].aFloat) );
				free( to_name );
				to_name = 0;
				free( (yyvsp[(3) - (5)].aFloatList) );
			    }
    break;

  case 320:
#line 1255 "srvn_result_gram.y"
    {
				add_entry_thpt_ut_confidence( to_name, (yyvsp[(2) - (5)].anInt), (yyvsp[(3) - (5)].aFloat), (yyvsp[(4) - (5)].aFloatList), (yyvsp[(5) - (5)].aFloat) );
				free( (yyvsp[(4) - (5)].aFloatList) );
			    }
    break;

  case 323:
#line 1266 "srvn_result_gram.y"
    {
				add_act_thpt_ut( task_name, to_name, (yyvsp[(2) - (4)].aFloat), (yyvsp[(3) - (4)].aFloatList) );
				free( to_name );
				to_name = 0;
				free( (yyvsp[(3) - (4)].aFloatList) );
			    }
    break;

  case 326:
#line 1279 "srvn_result_gram.y"
    {
				add_act_thpt_ut_confidence( task_name, to_name, (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aFloat), (yyvsp[(4) - (4)].aFloatList) );
				free( (yyvsp[(4) - (4)].aFloatList) );
			    }
    break;

  case 330:
#line 1300 "srvn_result_gram.y"
    {
				add_open_arriv( (yyvsp[(1) - (5)].aString), (yyvsp[(2) - (5)].aString), (yyvsp[(3) - (5)].aFloat), (yyvsp[(4) - (5)].aFloat) );
				free_task_name();
				free( to_name );
				to_name = 0;
			    }
    break;

  case 331:
#line 1307 "srvn_result_gram.y"
    {
				add_open_arriv( (yyvsp[(1) - (6)].aString), (yyvsp[(3) - (6)].aString), (yyvsp[(4) - (6)].aFloat), (yyvsp[(5) - (6)].aFloat) );
				free_task_name();
				free( to_name );
				to_name = 0;
			    }
    break;

  case 334:
#line 1320 "srvn_result_gram.y"
    {
				add_open_arriv_confidence( task_name, to_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloat) );
			    }
    break;

  case 337:
#line 1337 "srvn_result_gram.y"
    {
				add_proc( proc_name );
				free( proc_name );
				proc_name = 0;
			    }
    break;

  case 338:
#line 1345 "srvn_result_gram.y"
    {
				add_total_proc( proc_name, (yyvsp[(1) - (3)].aFloat) );
			    }
    break;

  case 342:
#line 1356 "srvn_result_gram.y"
    {
				add_task_proc( proc_name, task_name, (yyvsp[(2) - (5)].anInt), (yyvsp[(4) - (5)].aFloat) );
				free_task_name();
			    }
    break;

  case 345:
#line 1367 "srvn_result_gram.y"
    {
				(yyval.anInt) = (yyvsp[(3) - (3)].anInt);
			    }
    break;

  case 346:
#line 1371 "srvn_result_gram.y"
    {
				(yyval.anInt) = 1;
			    }
    break;

  case 349:
#line 1381 "srvn_result_gram.y"
    {
				add_entry_proc( (yyvsp[(1) - (4)].aString), (yyvsp[(2) - (4)].aFloat), (yyvsp[(3) - (4)].aFloatList) );
				free( to_name );
				to_name = 0;
				free( (yyvsp[(3) - (4)].aFloatList) );
			    }
    break;

  case 352:
#line 1394 "srvn_result_gram.y"
    {
				add_entry_proc_confidence( to_name, (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aFloat), (yyvsp[(4) - (4)].aFloatList) );
				free( (yyvsp[(4) - (4)].aFloatList) );
			    }
    break;

  case 355:
#line 1405 "srvn_result_gram.y"
    {
				add_act_proc( task_name, to_name, (yyvsp[(2) - (4)].aFloat), (yyvsp[(3) - (4)].aFloatList) );
				free( to_name );
				to_name = 0;
				free( (yyvsp[(3) - (4)].aFloatList) );
			    }
    break;

  case 358:
#line 1419 "srvn_result_gram.y"
    {
				add_act_proc_confidence( task_name, to_name, (yyvsp[(2) - (4)].anInt), (yyvsp[(3) - (4)].aFloat), (yyvsp[(4) - (4)].aFloatList) );
				free( (yyvsp[(4) - (4)].aFloatList) );
			    }
    break;

  case 361:
#line 1430 "srvn_result_gram.y"
    {
				add_task_proc_confidence( task_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloat) );
			    }
    break;

  case 362:
#line 1436 "srvn_result_gram.y"
    {
				(yyval.aFloat) = (yyvsp[(1) - (2)].aFloat);
			    }
    break;

  case 363:
#line 1440 "srvn_result_gram.y"
    {
				(yyval.aFloat) = 0;
			    }
    break;

  case 364:
#line 1446 "srvn_result_gram.y"
    {
				add_group_util( group_name, (yyvsp[(3) - (4)].aFloat) );
			    }
    break;

  case 368:
#line 1458 "srvn_result_gram.y"
    {
				add_group_util_conf( group_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloat) );
			    }
    break;

  case 371:
#line 1468 "srvn_result_gram.y"
    {
				add_total_proc_confidence( proc_name, (yyvsp[(2) - (3)].anInt), (yyvsp[(3) - (3)].aFloat) );
			    }
    break;

  case 375:
#line 1485 "srvn_result_gram.y"
    {
				add_overtaking( (yyvsp[(1) - (6)].aString), (yyvsp[(2) - (6)].aString), (yyvsp[(3) - (6)].aString), (yyvsp[(4) - (6)].aString), (yyvsp[(5) - (6)].anInt), (yyvsp[(6) - (6)].aFloatList) );
				free_from_and_to_name();
				free( (yyvsp[(3) - (6)].aString) );
				free( (yyvsp[(4) - (6)].aString) );
				free( (yyvsp[(6) - (6)].aFloatList) );
			    }
    break;

  case 376:
#line 1500 "srvn_result_gram.y"
    { (yyval.aString) = strdup( (yyvsp[(1) - (1)].aString) ); }
    break;

  case 377:
#line 1502 "srvn_result_gram.y"
    { (yyval.aString) = make_name( (yyvsp[(1) - (1)].anInt) ); }
    break;

  case 378:
#line 1506 "srvn_result_gram.y"
    { proc_name = (yyvsp[(1) - (1)].aString); (yyval.aString) = (yyvsp[(1) - (1)].aString); }
    break;

  case 379:
#line 1510 "srvn_result_gram.y"
    { task_name = (yyvsp[(1) - (1)].aString); (yyval.aString) = (yyvsp[(1) - (1)].aString); }
    break;

  case 380:
#line 1514 "srvn_result_gram.y"
    { group_name = (yyvsp[(1) - (1)].aString); (yyval.aString) = (yyvsp[(1) - (1)].aString); }
    break;

  case 381:
#line 1518 "srvn_result_gram.y"
    { from_name = (yyvsp[(1) - (1)].aString); (yyval.aString) = (yyvsp[(1) - (1)].aString); }
    break;

  case 382:
#line 1522 "srvn_result_gram.y"
    { to_name = (yyvsp[(1) - (1)].aString); (yyval.aString) = (yyvsp[(1) - (1)].aString); }
    break;

  case 383:
#line 1526 "srvn_result_gram.y"
    { activity_name = (yyvsp[(1) - (1)].aString); (yyval.aString) = (yyvsp[(1) - (1)].aString); }
    break;

  case 384:
#line 1530 "srvn_result_gram.y"
    { entry_phase = (yyvsp[(1) - (1)].anInt); (yyval.anInt) = (yyvsp[(1) - (1)].anInt); }
    break;

  case 385:
#line 1538 "srvn_result_gram.y"
    { np = 0; }
    break;

  case 386:
#line 1540 "srvn_result_gram.y"
    { (yyval.aFloatList) = fl; }
    break;

  case 387:
#line 1544 "srvn_result_gram.y"
    {	/* We're on the last list element */
					i = np;
					np += 1;
					fl = (double *)calloc( (size_t)np, sizeof( double) );
					fl[i] = (yyvsp[(1) - (2)].aFloat);
				}
    break;

  case 388:
#line 1551 "srvn_result_gram.y"
    { np += 1; }
    break;

  case 389:
#line 1553 "srvn_result_gram.y"
    {	/* We're on all but the last list element. */
					i -= 1;
					fl[i] = (yyvsp[(1) - (3)].aFloat);
				}
    break;

  case 390:
#line 1558 "srvn_result_gram.y"
    {	/* OOPS -- NaN or Inf or whatever... Barf. */
					i = np;
					np += 1;
					fl = (double *)calloc( (size_t)np, sizeof( double ) );
					fl[i] = 0.0;
				}
    break;

  case 392:
#line 1570 "srvn_result_gram.y"
    { (yyval.aFloat) = (double)(yyvsp[(1) - (1)].anInt); }
    break;

  case 393:
#line 1572 "srvn_result_gram.y"
    { (yyval.aFloat) = resultinfinity(); }
    break;


/* Line 1267 of yacc.c.  */
#line 3308 "srvn_result_gram.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}


#line 1576 "srvn_result_gram.y"
	/* Beginning of the code section */

/*
 * Convert an integer into a malloced string.
 */
  
static char *
make_name( int i )
{
	char * buf = (char *)malloc( 10 );
	if ( buf ) {
		(void) sprintf( buf, "%d", i );
	}
	return buf;
}


int result_error_flag;

static void
free_from_and_to_name()
{
    free( from_name );
    from_name = 0;
    free( to_name );
    to_name = 0;
}



static void
free_task_name()
{
    free( task_name );
    task_name = 0;
}



static void
free_entry_name()
{
    free( entry_name );
    entry_name = 0;
}



static void
free_activity_name()
{
    free( activity_name );
    activity_name = 0;
}



static void
resulterror( const char * fmt )
{
    results_error( fmt );
}

static double
resultinfinity()
{
#if defined(INFINITY)
    return INFINITY;
#else
    union {
	unsigned char c[8];
	double f;
    } x;

#if defined(WORDS_BIGENDIAN)
    x.c[0] = 0x7f;
    x.c[1] = 0xf0;
    x.c[2] = 0x00;
    x.c[3] = 0x00;
    x.c[4] = 0x00;
    x.c[5] = 0x00;
    x.c[6] = 0x00;
    x.c[7] = 0x00;
#else
    x.c[7] = 0x7f;
    x.c[6] = 0xf0;
    x.c[5] = 0x00;
    x.c[4] = 0x00;
    x.c[3] = 0x00;
    x.c[2] = 0x00;
    x.c[1] = 0x00;
    x.c[0] = 0x00;
#endif
    return x.f;
#endif
}

