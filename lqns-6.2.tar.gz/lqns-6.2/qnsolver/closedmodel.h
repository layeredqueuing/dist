/* -*- c++ -*-
 * $HeadURL: http://rads-svn.sce.carleton.ca:8080/svn/lqn/trunk/qnsolver/closedmodel.h $
 *
 * SRVN command line interface.
 *
 * Copyright the Real-Time and Distributed Systems Group,
 * Department of Systems and Computer Engineering,
 * Carleton University, Ottawa, Ontario, Canada. K1S 5B6
 *
 * December 2020
 *
 * $Id: closedmodel.h 14864 2021-06-26 01:45:54Z greg $
 *
 * ------------------------------------------------------------------------
 */

#if !defined(CLOSEDMODEL_H)
#define CLOSEDMODEL_H
#include <config.h>
#include <map>
#include <string>
#include <lqio/bcmp_document.h>
#include <mva/mva.h>
#include <mva/pop.h>
#include <mva/vector.h>
#include "model.h"

class ClosedModel : public Model {
public:
    class InstantiateChain {
    public:
	InstantiateChain( ClosedModel& model ) : _model(model) {}
	void operator()( const BCMP::Model::Chain::pair_t& pair );

    private:
	size_t indexAt( const std::string& name ) { return _model._index.k.at(name); }
	unsigned& N(size_t k) { return _model.N[k]; }
	double& Z(size_t k) { return _model.Z[k]; }
	unsigned& priority(size_t k) { return _model.priority[k]; }
	
    private:
	ClosedModel& _model;
    };

public:
    ClosedModel( Model& parent, BCMP::JMVA_Document& input, Model::Using mva );
    virtual ~ClosedModel();

    bool construct();
    bool instantiate();
    bool solve();
    void saveResults();

    std::ostream& debug( std::ostream& output ) const;
    const Population& customers() const { return N; }
    const MVA* solver() const { return _solver; }
	
private:
    virtual BCMP::Model::Chain::Type type() const { return BCMP::Model::Chain::Type::CLOSED; }
    virtual bool isParent() const { return false; }

private:
    Model& _parent;
    Population N;			/* Population (by class) 	*/
    Vector<double> Z;			/* Think Time */
    Vector<unsigned> priority;		/* Priority */
    Model::Using _mva;
    MVA * _solver;
};
#endif
