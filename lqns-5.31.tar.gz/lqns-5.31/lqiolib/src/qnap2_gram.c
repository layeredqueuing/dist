/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0

/* Substitute the variable and function names.  */
#define yyparse qnap2parse
#define yylex   qnap2lex
#define yyerror qnap2error
#define yylval  qnap2lval
#define yychar  qnap2char
#define yydebug qnap2debug
#define yynerrs qnap2nerrs


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     QNAP_CONTROL = 258,
     QNAP_DECLARE = 259,
     QNAP_END_PROGRAM = 260,
     QNAP_EXEC = 261,
     QNAP_RESTART = 262,
     QNAP_REBOOT = 263,
     QNAP_STATION = 264,
     QNAP_TERMINAL = 265,
     QNAP_INIT = 266,
     QNAP_NAME = 267,
     QNAP_PRIO = 268,
     QNAP_QUANTUM = 269,
     QNAP_RATE = 270,
     QNAP_SCHED = 271,
     QNAP_SERVICE = 272,
     QNAP_TRANSIT = 273,
     QNAP_TYPE = 274,
     QNAP_ENTRY = 275,
     QNAP_EXIT = 276,
     QNAP_ASSIGNMENT = 277,
     QNAP_ALL = 278,
     QNAP_ANY = 279,
     QNAP_BEGIN = 280,
     QNAP_DO = 281,
     QNAP_ELSE = 282,
     QNAP_END = 283,
     QNAP_FALSE = 284,
     QNAP_FOR = 285,
     QNAP_FORWARD = 286,
     QNAP_GENERIC = 287,
     QNAP_GOTO = 288,
     QNAP_IF = 289,
     QNAP_IN = 290,
     QNAP_IS = 291,
     QNAP_NIL = 292,
     QNAP_OBJECT = 293,
     QNAP_REF = 294,
     QNAP_REPEAT = 295,
     QNAP_STEP = 296,
     QNAP_THEN = 297,
     QNAP_TRUE = 298,
     QNAP_UNTIL = 299,
     QNAP_VAR = 300,
     QNAP_WATCHED = 301,
     QNAP_OPTION = 302,
     QNAP_WHILE = 303,
     QNAP_WITH = 304,
     RANGE_ERR = 305,
     STRING = 306,
     IDENTIFIER = 307,
     QNAP_AND = 308,
     QNAP_OR = 309,
     QNAP_NOT = 310,
     QNAP_EQUAL = 311,
     QNAP_NOT_EQUAL = 312,
     QNAP_LESS = 313,
     QNAP_LESS_EQUAL = 314,
     QNAP_GREATER = 315,
     QNAP_GREATER_EQUAL = 316,
     QNAP_POWER = 317,
     QNAP_PLUS = 318,
     QNAP_MINUS = 319,
     QNAP_DIVIDE = 320,
     QNAP_MULTIPLY = 321,
     QNAP_MODULUS = 322,
     QNAP_BOOLEAN = 323,
     QNAP_REAL = 324,
     QNAP_INTEGER = 325,
     QNAP_STRING = 326,
     QNAP_QUEUE = 327,
     QNAP_CLASS = 328,
     QNAP_CST = 329,
     QNAP_COX = 330,
     QNAP_EXP = 331,
     QNAP_ERLANG = 332,
     QNAP_HEXP = 333,
     QNAP_SERVER = 334,
     QNAP_MULTIPLE = 335,
     QNAP_SINGLE = 336,
     QNAP_SOURCE = 337,
     QNAP_INFINITE = 338,
     DOUBLE = 339,
     LONG = 340
   };
#endif
/* Tokens.  */
#define QNAP_CONTROL 258
#define QNAP_DECLARE 259
#define QNAP_END_PROGRAM 260
#define QNAP_EXEC 261
#define QNAP_RESTART 262
#define QNAP_REBOOT 263
#define QNAP_STATION 264
#define QNAP_TERMINAL 265
#define QNAP_INIT 266
#define QNAP_NAME 267
#define QNAP_PRIO 268
#define QNAP_QUANTUM 269
#define QNAP_RATE 270
#define QNAP_SCHED 271
#define QNAP_SERVICE 272
#define QNAP_TRANSIT 273
#define QNAP_TYPE 274
#define QNAP_ENTRY 275
#define QNAP_EXIT 276
#define QNAP_ASSIGNMENT 277
#define QNAP_ALL 278
#define QNAP_ANY 279
#define QNAP_BEGIN 280
#define QNAP_DO 281
#define QNAP_ELSE 282
#define QNAP_END 283
#define QNAP_FALSE 284
#define QNAP_FOR 285
#define QNAP_FORWARD 286
#define QNAP_GENERIC 287
#define QNAP_GOTO 288
#define QNAP_IF 289
#define QNAP_IN 290
#define QNAP_IS 291
#define QNAP_NIL 292
#define QNAP_OBJECT 293
#define QNAP_REF 294
#define QNAP_REPEAT 295
#define QNAP_STEP 296
#define QNAP_THEN 297
#define QNAP_TRUE 298
#define QNAP_UNTIL 299
#define QNAP_VAR 300
#define QNAP_WATCHED 301
#define QNAP_OPTION 302
#define QNAP_WHILE 303
#define QNAP_WITH 304
#define RANGE_ERR 305
#define STRING 306
#define IDENTIFIER 307
#define QNAP_AND 308
#define QNAP_OR 309
#define QNAP_NOT 310
#define QNAP_EQUAL 311
#define QNAP_NOT_EQUAL 312
#define QNAP_LESS 313
#define QNAP_LESS_EQUAL 314
#define QNAP_GREATER 315
#define QNAP_GREATER_EQUAL 316
#define QNAP_POWER 317
#define QNAP_PLUS 318
#define QNAP_MINUS 319
#define QNAP_DIVIDE 320
#define QNAP_MULTIPLY 321
#define QNAP_MODULUS 322
#define QNAP_BOOLEAN 323
#define QNAP_REAL 324
#define QNAP_INTEGER 325
#define QNAP_STRING 326
#define QNAP_QUEUE 327
#define QNAP_CLASS 328
#define QNAP_CST 329
#define QNAP_COX 330
#define QNAP_EXP 331
#define QNAP_ERLANG 332
#define QNAP_HEXP 333
#define QNAP_SERVER 334
#define QNAP_MULTIPLE 335
#define QNAP_SINGLE 336
#define QNAP_SOURCE 337
#define QNAP_INFINITE 338
#define DOUBLE 339
#define LONG 340




/* Copy the first part of user declarations.  */
#line 5 "qnap2_gram.y"

#include <stdio.h>
#include <string.h>
#include "qnap2_document.h"

extern void qnap2error( const char * fmt, ... );
extern int qnap2lex();


/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 14 "qnap2_gram.y"
{
    int aCode;
    long aLong;
    double aReal;
    char * aString;
    void * aPointer;
}
/* Line 193 of yacc.c.  */
#line 291 "qnap2_gram.c"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 216 of yacc.c.  */
#line 304 "qnap2_gram.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  81
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   751

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  92
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  48
/* YYNRULES -- Number of rules.  */
#define YYNRULES  163
/* YYNRULES -- Number of states.  */
#define YYNSTATES  325

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   340

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      88,    89,     2,     2,    87,     2,    91,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    90,    86,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     6,     9,    11,    14,    17,    20,    22,
      24,    26,    29,    32,    36,    39,    43,    47,    50,    52,
      54,    56,    58,    60,    64,    67,    73,    81,    83,    87,
      90,    91,    94,    98,   103,   108,   113,   118,   122,   126,
     131,   136,   140,   141,   146,   150,   152,   156,   161,   166,
     171,   178,   185,   187,   189,   191,   195,   199,   209,   211,
     213,   218,   220,   225,   227,   229,   233,   237,   238,   240,
     243,   249,   254,   258,   262,   264,   268,   270,   272,   277,
     284,   289,   296,   303,   305,   312,   317,   324,   331,   336,
     341,   344,   346,   349,   351,   356,   358,   362,   366,   370,
     374,   378,   382,   386,   390,   394,   396,   400,   404,   408,
     412,   414,   418,   420,   423,   426,   429,   431,   436,   438,
     443,   445,   449,   450,   455,   457,   459,   461,   463,   467,
     469,   471,   473,   475,   477,   481,   487,   490,   492,   494,
     496,   498,   500,   502,   504,   506,   508,   510,   512,   514,
     516,   518,   520,   522,   524,   526,   528,   530,   532,   534,
     536,   538,   540,   542
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
      93,     0,    -1,    94,     5,    -1,    94,    95,    -1,    95,
      -1,     3,   115,    -1,     4,    96,    -1,     6,   118,    -1,
       8,    -1,     7,    -1,    10,    -1,     9,   103,    -1,    97,
      86,    -1,    96,    97,    86,    -1,   138,    99,    -1,   138,
      98,    99,    -1,    39,   138,   101,    -1,    98,    99,    -1,
      70,    -1,    69,    -1,    68,    -1,    71,    -1,   100,    -1,
      99,    87,   100,    -1,   139,   102,    -1,   139,    88,   132,
      89,   102,    -1,   139,    88,   132,    90,   132,    89,   102,
      -1,   139,    -1,   101,    87,   139,    -1,    56,   132,    -1,
      -1,   104,    86,    -1,   103,   104,    86,    -1,    11,   105,
      56,   132,    -1,    12,    56,   139,   114,    -1,    13,   105,
      56,   132,    -1,    14,   105,    56,   132,    -1,    15,    56,
     132,    -1,    16,    56,   139,    -1,    17,   105,    56,   107,
      -1,    18,   105,    56,   108,    -1,    19,    56,   111,    -1,
      -1,    88,    23,    73,    89,    -1,    88,   106,    89,    -1,
     139,    -1,   106,    87,   139,    -1,    74,    88,   125,    89,
      -1,    75,    88,   125,    89,    -1,    76,    88,   125,    89,
      -1,    77,    88,   125,    87,   125,    89,    -1,    78,    88,
     125,    87,   125,    89,    -1,   139,    -1,   109,    -1,   110,
      -1,   109,    87,   110,    -1,   139,    87,   125,    -1,   139,
      88,   136,    89,    87,   139,    88,   136,    89,    -1,   112,
      -1,    82,    -1,    80,    88,   125,    89,    -1,   113,    -1,
     113,    88,   125,    89,    -1,    83,    -1,    81,    -1,    79,
      87,   112,    -1,    88,   136,    89,    -1,    -1,   116,    -1,
     115,   116,    -1,    73,    56,    23,    72,    86,    -1,    47,
      56,   117,    86,    -1,    20,    56,   118,    -1,    21,    56,
     118,    -1,   139,    -1,   117,    87,   139,    -1,   119,    -1,
     120,    -1,    34,   124,    42,   118,    -1,    34,   124,    42,
     120,    27,   119,    -1,    48,   124,    42,   119,    -1,    30,
     129,    22,   136,    26,   119,    -1,    30,   129,    22,   133,
      26,   119,    -1,   121,    -1,    34,   124,    42,   120,    27,
     120,    -1,    48,   124,    42,   120,    -1,    30,   129,    22,
     136,    26,   120,    -1,    30,   129,    22,   133,    26,   120,
      -1,    25,   122,    28,    86,    -1,   129,    22,   133,    86,
      -1,   123,    86,    -1,   118,    -1,   122,   118,    -1,   139,
      -1,   139,    88,   135,    89,    -1,   125,    -1,   124,    58,
     125,    -1,   124,    59,   125,    -1,   124,    60,   125,    -1,
     124,    61,   125,    -1,   124,    56,   125,    -1,   124,    57,
     125,    -1,   125,    63,   126,    -1,   125,    64,   126,    -1,
     125,    54,   126,    -1,   126,    -1,   126,    66,   127,    -1,
     126,    65,   127,    -1,   126,    67,   127,    -1,   126,    53,
     127,    -1,   127,    -1,   128,    62,   127,    -1,   128,    -1,
      63,   129,    -1,    64,   129,    -1,    55,   129,    -1,   129,
      -1,   139,    91,   139,   130,    -1,   131,    -1,   131,    91,
     139,   130,    -1,   132,    -1,    88,   135,    89,    -1,    -1,
     139,    88,   135,    89,    -1,   139,    -1,    85,    -1,    84,
      -1,    51,    -1,    88,   124,    89,    -1,   134,    -1,   136,
      -1,   137,    -1,   135,    -1,   125,    -1,   135,    87,   125,
      -1,   125,    41,   125,    44,   125,    -1,    23,   138,    -1,
      72,    -1,    73,    -1,    52,    -1,    73,    -1,    75,    -1,
      74,    -1,    77,    -1,    76,    -1,    78,    -1,    83,    -1,
      11,    -1,    70,    -1,    80,    -1,    12,    -1,    47,    -1,
      13,    -1,    14,    -1,    72,    -1,    15,    -1,    69,    -1,
      16,    -1,    79,    -1,    17,    -1,    81,    -1,    82,    -1,
      18,    -1,    19,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,    49,    49,    52,    53,    56,    57,    58,    59,    60,
      61,    62,    69,    70,    73,    74,    75,    76,    79,    80,
      81,    82,    85,    86,    89,    90,    91,    94,    95,    98,
      99,   106,   107,   110,   111,   112,   113,   114,   115,   116,
     117,   118,   121,   122,   123,   126,   127,   131,   132,   133,
     134,   135,   138,   139,   142,   143,   146,   147,   152,   153,
     154,   155,   156,   159,   160,   163,   166,   167,   174,   175,
     178,   179,   180,   181,   184,   185,   192,   193,   196,   197,
     199,   200,   202,   206,   207,   209,   210,   212,   216,   217,
     218,   221,   222,   225,   226,   229,   230,   231,   232,   233,
     234,   235,   238,   239,   240,   241,   244,   245,   246,   247,
     248,   251,   252,   255,   256,   257,   258,   261,   262,   263,
     264,   267,   268,   271,   274,   275,   276,   277,   278,   285,
     286,   289,   290,   293,   294,   297,   300,   303,   304,   309,
     310,   311,   312,   313,   314,   315,   316,   317,   318,   319,
     320,   321,   322,   323,   324,   325,   326,   327,   328,   329,
     330,   331,   332,   333
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "QNAP_CONTROL", "QNAP_DECLARE",
  "QNAP_END_PROGRAM", "QNAP_EXEC", "QNAP_RESTART", "QNAP_REBOOT",
  "QNAP_STATION", "QNAP_TERMINAL", "QNAP_INIT", "QNAP_NAME", "QNAP_PRIO",
  "QNAP_QUANTUM", "QNAP_RATE", "QNAP_SCHED", "QNAP_SERVICE",
  "QNAP_TRANSIT", "QNAP_TYPE", "QNAP_ENTRY", "QNAP_EXIT",
  "QNAP_ASSIGNMENT", "QNAP_ALL", "QNAP_ANY", "QNAP_BEGIN", "QNAP_DO",
  "QNAP_ELSE", "QNAP_END", "QNAP_FALSE", "QNAP_FOR", "QNAP_FORWARD",
  "QNAP_GENERIC", "QNAP_GOTO", "QNAP_IF", "QNAP_IN", "QNAP_IS", "QNAP_NIL",
  "QNAP_OBJECT", "QNAP_REF", "QNAP_REPEAT", "QNAP_STEP", "QNAP_THEN",
  "QNAP_TRUE", "QNAP_UNTIL", "QNAP_VAR", "QNAP_WATCHED", "QNAP_OPTION",
  "QNAP_WHILE", "QNAP_WITH", "RANGE_ERR", "STRING", "IDENTIFIER",
  "QNAP_AND", "QNAP_OR", "QNAP_NOT", "QNAP_EQUAL", "QNAP_NOT_EQUAL",
  "QNAP_LESS", "QNAP_LESS_EQUAL", "QNAP_GREATER", "QNAP_GREATER_EQUAL",
  "QNAP_POWER", "QNAP_PLUS", "QNAP_MINUS", "QNAP_DIVIDE", "QNAP_MULTIPLY",
  "QNAP_MODULUS", "QNAP_BOOLEAN", "QNAP_REAL", "QNAP_INTEGER",
  "QNAP_STRING", "QNAP_QUEUE", "QNAP_CLASS", "QNAP_CST", "QNAP_COX",
  "QNAP_EXP", "QNAP_ERLANG", "QNAP_HEXP", "QNAP_SERVER", "QNAP_MULTIPLE",
  "QNAP_SINGLE", "QNAP_SOURCE", "QNAP_INFINITE", "DOUBLE", "LONG", "';'",
  "','", "'('", "')'", "':'", "'.'", "$accept", "qnap2", "command_list",
  "command", "declare_list", "declare_statement", "variable_type",
  "variable_list", "variable", "identifier_list", "optional_init",
  "station_list", "station", "class_reference", "class_list", "service",
  "transit", "transit_list", "transit_pair", "station_type",
  "simple_station_type", "compound_station_type", "optional_list",
  "control_list", "control", "option_list", "statement", "open_statement",
  "closed_statement", "simple_statement", "compound_statement",
  "procedure_call", "relation", "expression", "term", "power",
  "prefix_statement", "postfix_statement", "optional_index",
  "function_call", "factor", "list", "array_list", "expression_list",
  "loop_list", "object_list", "object_type", "identifier", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,    59,    44,    40,    41,
      58,    46
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    92,    93,    94,    94,    95,    95,    95,    95,    95,
      95,    95,    96,    96,    97,    97,    97,    97,    98,    98,
      98,    98,    99,    99,   100,   100,   100,   101,   101,   102,
     102,   103,   103,   104,   104,   104,   104,   104,   104,   104,
     104,   104,   105,   105,   105,   106,   106,   107,   107,   107,
     107,   107,   108,   108,   109,   109,   110,   110,   111,   111,
     111,   111,   111,   112,   112,   113,   114,   114,   115,   115,
     116,   116,   116,   116,   117,   117,   118,   118,   119,   119,
     119,   119,   119,   120,   120,   120,   120,   120,   121,   121,
     121,   122,   122,   123,   123,   124,   124,   124,   124,   124,
     124,   124,   125,   125,   125,   125,   126,   126,   126,   126,
     126,   127,   127,   128,   128,   128,   128,   129,   129,   129,
     129,   130,   130,   131,   132,   132,   132,   132,   132,   133,
     133,   134,   134,   135,   135,   136,   137,   138,   138,   139,
     139,   139,   139,   139,   139,   139,   139,   139,   139,   139,
     139,   139,   139,   139,   139,   139,   139,   139,   139,   139,
     139,   139,   139,   139
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     2,     2,     1,     2,     2,     2,     1,     1,
       1,     2,     2,     3,     2,     3,     3,     2,     1,     1,
       1,     1,     1,     3,     2,     5,     7,     1,     3,     2,
       0,     2,     3,     4,     4,     4,     4,     3,     3,     4,
       4,     3,     0,     4,     3,     1,     3,     4,     4,     4,
       6,     6,     1,     1,     1,     3,     3,     9,     1,     1,
       4,     1,     4,     1,     1,     3,     3,     0,     1,     2,
       5,     4,     3,     3,     1,     3,     1,     1,     4,     6,
       4,     6,     6,     1,     6,     4,     6,     6,     4,     4,
       2,     1,     2,     1,     4,     1,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     1,     3,     3,     3,     3,
       1,     3,     1,     2,     2,     2,     1,     4,     1,     4,
       1,     3,     0,     4,     1,     1,     1,     1,     3,     1,
       1,     1,     1,     1,     3,     5,     2,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,     0,     0,     0,     9,     8,     0,    10,     0,     0,
       4,     0,     0,     0,     0,     5,    68,     0,    20,    19,
      18,    21,   137,   138,     6,     0,     0,     0,   147,   150,
     152,   153,   155,   157,   159,   162,   163,     0,     0,     0,
     151,     0,   127,   139,   156,   148,   154,   140,   142,   141,
     144,   143,   145,   158,   149,   160,   161,   146,   126,   125,
       0,     7,    76,    77,    83,     0,     0,   118,   120,    93,
      42,     0,    42,    42,     0,     0,    42,    42,     0,    11,
       0,     1,     2,     3,     0,     0,     0,     0,    69,     0,
       0,    12,    17,    22,    30,    19,    18,     0,    14,    91,
       0,     0,   124,     0,     0,     0,     0,    95,   105,   110,
     112,   116,     0,     0,    90,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      31,    72,    73,     0,    74,     0,    16,    27,    13,     0,
       0,     0,    24,    15,     0,    92,     0,     0,   115,   113,
     114,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   128,     0,   133,
       0,   129,   132,   130,   131,   122,   133,     0,   122,     0,
       0,    45,     0,    67,     0,     0,    37,   124,    38,     0,
       0,     0,     0,    64,    59,    63,    41,    58,    61,    32,
      71,     0,     0,     0,    23,    29,     0,    88,     0,     0,
       0,    78,    77,   100,   101,    96,    97,    98,    99,   104,
     102,   103,   109,   107,   106,   108,   111,    80,    85,   136,
       0,    89,     0,     0,   119,   123,   117,     0,     0,    44,
      33,     0,    34,    35,    36,     0,     0,     0,     0,     0,
      39,    40,    53,    54,    52,     0,     0,     0,    75,    70,
      28,    30,     0,     0,     0,   123,     0,     0,   134,     0,
      43,    46,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    65,     0,     0,    25,     0,    82,    87,    81,
      86,    79,    84,     0,   121,    66,     0,     0,     0,     0,
       0,    55,     0,    56,     0,    60,    62,    30,   135,    47,
      48,    49,     0,     0,     0,    26,     0,     0,     0,    50,
      51,     0,     0,     0,    57
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     8,     9,    10,    24,    25,    26,    92,    93,   136,
     142,    79,    80,   120,   180,   250,   251,   252,   253,   196,
     197,   198,   242,    15,    16,   133,    61,    62,    63,    64,
     100,    65,   106,   107,   108,   109,   110,   111,   234,    67,
      68,   170,   171,   172,   173,   174,    27,   102
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -257
static const yytype_int16 yypact[] =
{
     316,     1,   133,   344,  -257,  -257,   290,  -257,    16,   248,
    -257,   -36,   -29,   -26,   -14,     1,  -257,   139,  -257,  -257,
    -257,  -257,  -257,  -257,   133,   -39,   668,   584,  -257,  -257,
    -257,  -257,  -257,  -257,  -257,  -257,  -257,   344,   542,   464,
    -257,   464,  -257,  -257,  -257,  -257,  -257,  -257,  -257,  -257,
    -257,  -257,  -257,  -257,  -257,  -257,  -257,  -257,  -257,  -257,
     464,  -257,  -257,  -257,  -257,   -21,    28,     2,  -257,   -15,
     -13,    44,   -13,   -13,    55,    58,   -13,   -13,    61,   290,
      34,  -257,  -257,  -257,   344,   344,   668,   105,  -257,   668,
      46,  -257,    63,  -257,   -24,   -42,   127,   668,    63,  -257,
     266,   123,   -78,   542,   542,   542,   181,    95,   -28,  -257,
      94,  -257,   189,    -4,  -257,   386,   668,   464,   668,   626,
     130,   668,   137,   165,   542,   668,   169,   172,   207,    91,
    -257,  -257,  -257,    75,  -257,   162,   112,  -257,  -257,   668,
     542,   542,  -257,    63,   157,  -257,   386,   464,  -257,  -257,
    -257,   344,   464,   464,   464,   464,   464,   464,   464,   464,
     464,   464,   464,   464,   464,   464,   344,  -257,   139,   155,
     158,  -257,   175,  -257,  -257,   176,    95,     9,   176,   192,
      64,  -257,   542,   180,   542,   542,  -257,  -257,  -257,   253,
     668,   185,   204,  -257,  -257,  -257,  -257,  -257,   205,  -257,
    -257,   668,   187,   668,  -257,  -257,   143,  -257,   269,   271,
      78,  -257,   272,    95,    95,    95,    95,    95,    95,   -28,
     -28,   -28,  -257,  -257,  -257,  -257,  -257,  -257,  -257,  -257,
     464,  -257,   464,   464,  -257,   212,  -257,   221,   668,  -257,
    -257,   464,  -257,  -257,  -257,   223,   224,   228,   233,   244,
    -257,  -257,   246,  -257,   129,   141,   464,   464,  -257,  -257,
    -257,   278,   542,   344,   344,  -257,   344,   166,    95,    89,
    -257,  -257,   155,   263,   464,   464,   464,   464,   464,   668,
     464,   464,  -257,   -46,    -5,  -257,   264,  -257,  -257,  -257,
    -257,  -257,  -257,   464,  -257,  -257,    38,    41,    71,   110,
     121,  -257,   129,    95,   281,  -257,  -257,   278,    95,  -257,
    -257,  -257,   464,   464,   250,  -257,    77,    79,   668,  -257,
    -257,   283,   464,   284,  -257
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -257,  -257,  -257,   363,  -257,   351,   349,   -25,   238,  -257,
    -256,  -257,   300,   198,  -257,  -257,  -257,  -257,   101,  -257,
     126,  -257,  -257,  -257,   367,  -257,   -22,  -154,  -140,  -257,
    -257,  -257,   -32,   -86,   -69,   203,  -257,     3,   206,  -257,
    -105,   237,  -257,  -114,  -142,  -257,   -16,    -3
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -157
static const yytype_int16 yytable[] =
{
      69,    89,    98,   177,   209,   285,    66,  -124,   158,   112,
     147,   212,   227,   118,  -156,    99,    81,   159,   160,   186,
      84,    11,    12,    94,    94,   161,   228,    85,   113,   169,
      86,   176,   140,   210,    69,   205,   206,   162,   163,   164,
      66,   101,    87,   305,  -156,  -156,  -156,    91,    13,   158,
     115,   315,   152,   153,   154,   155,   156,   157,   159,   160,
     169,   176,   131,   132,   141,   114,   213,   214,   215,   216,
     217,   218,   143,   117,    14,   119,   118,   240,   145,   243,
     244,    69,    69,   134,   306,   167,   137,    66,    66,   219,
     220,   221,   158,   116,    94,   158,   232,    69,   235,   273,
     121,   159,   160,    66,   159,   160,   148,   149,   150,   287,
     289,   124,   291,   175,   125,   178,   181,   128,   183,   269,
     130,   187,   188,   288,   290,   158,   292,   309,   135,   211,
     310,   158,   138,   158,   159,   160,    94,   187,   187,   304,
     159,   160,   159,   160,   267,   146,   268,   176,    69,   158,
     139,   238,   229,   239,    66,   272,   165,   286,   159,   160,
     311,   200,   201,    69,   158,   232,   319,   265,   320,    66,
     283,   284,    17,   159,   160,   158,   232,   199,   294,   187,
     323,   187,   187,  -148,   159,   160,   182,   254,   296,   297,
     298,   299,   300,   184,   303,   272,   230,   312,   258,   203,
     260,    18,    19,    20,    21,    22,    23,   308,   313,   158,
     293,    22,    23,  -148,  -148,  -148,   280,   281,   159,   160,
     158,   185,   193,   151,   195,   189,   316,   317,   190,   159,
     160,   166,   261,   262,   202,   271,   272,   152,   153,   154,
     155,   156,   157,   207,   231,   152,   153,   154,   155,   156,
     157,     1,     2,    82,     3,     4,     5,     6,     7,   187,
      69,    69,   232,    69,   233,   237,    66,    66,   241,    66,
     122,   123,   255,   259,   126,   127,   302,    28,    29,    30,
      31,    32,    33,    34,    35,    36,   191,   192,   193,   194,
     195,    37,   256,   257,   144,   263,    38,   264,   -94,   266,
      39,    70,    71,    72,    73,    74,    75,    76,    77,    78,
     270,   274,   275,    40,    41,   321,   276,    42,    43,     1,
       2,   277,     3,     4,     5,     6,     7,   245,   246,   247,
     248,   249,   278,   279,   140,    44,    45,   318,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,   295,   307,    60,    28,    29,    30,    31,    32,
      33,    34,    35,    36,   222,   223,   224,   225,   226,    37,
     314,   322,    83,   324,    38,    90,    97,   204,    39,   129,
     301,   282,    88,   208,   236,     0,     0,     0,     0,     0,
       0,    40,    41,     0,     0,    42,    43,    28,    29,    30,
      31,    32,    33,    34,    35,    36,     0,     0,     0,   168,
       0,     0,     0,    44,    45,     0,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
       0,     0,    60,    40,     0,     0,     0,    42,    43,     0,
       0,   103,     0,     0,     0,     0,     0,     0,     0,   104,
     105,     0,     0,     0,     0,    44,    45,     0,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,     0,     0,    60,    28,    29,    30,    31,    32,
      33,    34,    35,    36,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    40,     0,     0,     0,    42,    43,     0,     0,   103,
       0,     0,     0,     0,     0,     0,     0,   104,   105,     0,
       0,     0,     0,    44,    45,     0,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
       0,     0,    60,    28,    29,    30,    31,    32,    33,    34,
      35,    36,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    40,
       0,     0,     0,    42,    43,    28,    29,    30,    31,    32,
      33,    34,    35,    36,     0,     0,     0,     0,     0,     0,
       0,    44,    45,     0,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,     0,     0,
      60,    40,     0,     0,     0,     0,    43,    28,    29,    30,
      31,    32,    33,    34,    35,    36,     0,     0,     0,   179,
       0,     0,    18,    95,    96,    21,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,     0,     0,
       0,     0,     0,    40,     0,     0,     0,     0,    43,    28,
      29,    30,    31,    32,    33,    34,    35,    36,     0,     0,
       0,     0,     0,     0,     0,    44,    45,     0,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
       0,     0,     0,     0,     0,    40,     0,     0,     0,     0,
      43,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    44,    45,     0,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57
};

static const yytype_int16 yycheck[] =
{
       3,    17,    27,   117,   146,   261,     3,    22,    54,    41,
      88,   151,   166,    91,    56,    37,     0,    63,    64,   124,
      56,    20,    21,    26,    27,    53,   166,    56,    60,   115,
      56,   117,    56,   147,    37,   140,   141,    65,    66,    67,
      37,    38,    56,    89,    86,    87,    88,    86,    47,    54,
      22,   307,    56,    57,    58,    59,    60,    61,    63,    64,
     146,   147,    84,    85,    88,    86,   152,   153,   154,   155,
     156,   157,    97,    88,    73,    88,    91,   182,   100,   184,
     185,    84,    85,    86,    89,    89,    89,    84,    85,   158,
     159,   160,    54,    91,    97,    54,    87,   100,    89,   241,
      56,    63,    64,   100,    63,    64,   103,   104,   105,   263,
     264,    56,   266,   116,    56,   118,   119,    56,   121,   233,
      86,   124,   125,   263,   264,    54,   266,    89,    23,   151,
      89,    54,    86,    54,    63,    64,   139,   140,   141,   281,
      63,    64,    63,    64,   230,    22,   232,   233,   151,    54,
      87,    87,   168,    89,   151,   241,    62,   262,    63,    64,
      89,    86,    87,   166,    54,    87,    89,    89,    89,   166,
     256,   257,    39,    63,    64,    54,    87,    86,    89,   182,
     322,   184,   185,    56,    63,    64,    56,   190,   274,   275,
     276,   277,   278,    56,   280,   281,    41,    87,   201,    87,
     203,    68,    69,    70,    71,    72,    73,   293,    87,    54,
      44,    72,    73,    86,    87,    88,    87,    88,    63,    64,
      54,    56,    81,    42,    83,    56,   312,   313,    56,    63,
      64,    42,    89,    90,    72,   238,   322,    56,    57,    58,
      59,    60,    61,    86,    86,    56,    57,    58,    59,    60,
      61,     3,     4,     5,     6,     7,     8,     9,    10,   262,
     263,   264,    87,   266,    88,    73,   263,   264,    88,   266,
      72,    73,    87,    86,    76,    77,   279,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    79,    80,    81,    82,
      83,    25,    88,    88,    28,    26,    30,    26,    86,    27,
      34,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      89,    88,    88,    47,    48,   318,    88,    51,    52,     3,
       4,    88,     6,     7,     8,     9,    10,    74,    75,    76,
      77,    78,    88,    87,    56,    69,    70,    87,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
      84,    85,    89,    89,    88,    11,    12,    13,    14,    15,
      16,    17,    18,    19,   161,   162,   163,   164,   165,    25,
      89,    88,     9,    89,    30,    24,    27,   139,    34,    79,
     279,   255,    15,   146,   178,    -1,    -1,    -1,    -1,    -1,
      -1,    47,    48,    -1,    -1,    51,    52,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    -1,    -1,    -1,    23,
      -1,    -1,    -1,    69,    70,    -1,    72,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
      -1,    -1,    88,    47,    -1,    -1,    -1,    51,    52,    -1,
      -1,    55,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    63,
      64,    -1,    -1,    -1,    -1,    69,    70,    -1,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
      84,    85,    -1,    -1,    88,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    47,    -1,    -1,    -1,    51,    52,    -1,    -1,    55,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    63,    64,    -1,
      -1,    -1,    -1,    69,    70,    -1,    72,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
      -1,    -1,    88,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    47,
      -1,    -1,    -1,    51,    52,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    69,    70,    -1,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    83,    84,    85,    -1,    -1,
      88,    47,    -1,    -1,    -1,    -1,    52,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    -1,    -1,    -1,    23,
      -1,    -1,    68,    69,    70,    71,    72,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    -1,    -1,
      -1,    -1,    -1,    47,    -1,    -1,    -1,    -1,    52,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    69,    70,    -1,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
      -1,    -1,    -1,    -1,    -1,    47,    -1,    -1,    -1,    -1,
      52,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    69,    70,    -1,
      72,    73,    74,    75,    76,    77,    78,    79,    80,    81,
      82,    83
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     3,     4,     6,     7,     8,     9,    10,    93,    94,
      95,    20,    21,    47,    73,   115,   116,    39,    68,    69,
      70,    71,    72,    73,    96,    97,    98,   138,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    25,    30,    34,
      47,    48,    51,    52,    69,    70,    72,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
      88,   118,   119,   120,   121,   123,   129,   131,   132,   139,
      11,    12,    13,    14,    15,    16,    17,    18,    19,   103,
     104,     0,     5,    95,    56,    56,    56,    56,   116,   138,
      97,    86,    99,   100,   139,    69,    70,    98,    99,   118,
     122,   129,   139,    55,    63,    64,   124,   125,   126,   127,
     128,   129,   124,   124,    86,    22,    91,    88,    91,    88,
     105,    56,   105,   105,    56,    56,   105,   105,    56,   104,
      86,   118,   118,   117,   139,    23,   101,   139,    86,    87,
      56,    88,   102,    99,    28,   118,    22,    88,   129,   129,
     129,    42,    56,    57,    58,    59,    60,    61,    54,    63,
      64,    53,    65,    66,    67,    62,    42,    89,    23,   125,
     133,   134,   135,   136,   137,   139,   125,   135,   139,    23,
     106,   139,    56,   139,    56,    56,   132,   139,   139,    56,
      56,    79,    80,    81,    82,    83,   111,   112,   113,    86,
      86,    87,    72,    87,   100,   132,   132,    86,   133,   136,
     135,   118,   120,   125,   125,   125,   125,   125,   125,   126,
     126,   126,   127,   127,   127,   127,   127,   119,   120,   138,
      41,    86,    87,    88,   130,    89,   130,    73,    87,    89,
     132,    88,   114,   132,   132,    74,    75,    76,    77,    78,
     107,   108,   109,   110,   139,    87,    88,    88,   139,    86,
     139,    89,    90,    26,    26,    89,    27,   125,   125,   135,
      89,   139,   125,   136,    88,    88,    88,    88,    88,    87,
      87,    88,   112,   125,   125,   102,   132,   119,   120,   119,
     120,   119,   120,    44,    89,    89,   125,   125,   125,   125,
     125,   110,   139,   125,   136,    89,    89,    89,   125,    89,
      89,    89,    87,    87,    89,   102,   125,   125,    87,    89,
      89,   139,    88,   136,    89
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 6:
#line 57 "qnap2_gram.y"
    { qnap2_construct_chains(); }
    break;

  case 7:
#line 58 "qnap2_gram.y"
    { qnap2_set_main( (yyvsp[(2) - (2)].aPointer) ); }
    break;

  case 11:
#line 62 "qnap2_gram.y"
    { qnap2_construct_station(); }
    break;

  case 14:
#line 73 "qnap2_gram.y"
    { qnap2_declare_object( (yyvsp[(1) - (2)].aCode), (yyvsp[(2) - (2)].aPointer) ); }
    break;

  case 15:
#line 74 "qnap2_gram.y"
    { qnap2_declare_attribute( (yyvsp[(1) - (3)].aCode), (yyvsp[(2) - (3)].aCode), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 16:
#line 75 "qnap2_gram.y"
    { qnap2_declare_reference( (yyvsp[(2) - (3)].aCode), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 17:
#line 76 "qnap2_gram.y"
    { qnap2_declare_variable( (yyvsp[(1) - (2)].aCode), (yyvsp[(2) - (2)].aPointer) ); }
    break;

  case 18:
#line 79 "qnap2_gram.y"
    { (yyval.aCode) = (yyvsp[(1) - (1)].aCode); }
    break;

  case 19:
#line 80 "qnap2_gram.y"
    { (yyval.aCode) = (yyvsp[(1) - (1)].aCode); }
    break;

  case 20:
#line 81 "qnap2_gram.y"
    { (yyval.aCode) = (yyvsp[(1) - (1)].aCode); }
    break;

  case 21:
#line 82 "qnap2_gram.y"
    { (yyval.aCode) = (yyvsp[(1) - (1)].aCode); }
    break;

  case 22:
#line 85 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_append_pointer( NULL, (yyvsp[(1) - (1)].aPointer) ); }
    break;

  case 23:
#line 86 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_append_pointer( (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 24:
#line 89 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_define_variable( (yyvsp[(1) - (2)].aString), NULL, NULL, (yyvsp[(2) - (2)].aPointer) ); free( (yyvsp[(1) - (2)].aString) ); }
    break;

  case 25:
#line 90 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_define_variable( (yyvsp[(1) - (5)].aString), qnap2_get_integer(1), (yyvsp[(3) - (5)].aPointer), (yyvsp[(5) - (5)].aPointer) ); free( (yyvsp[(1) - (5)].aString) ); }
    break;

  case 26:
#line 91 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_define_variable( (yyvsp[(1) - (7)].aString), (yyvsp[(3) - (7)].aPointer), (yyvsp[(5) - (7)].aPointer), (yyvsp[(7) - (7)].aPointer) ); free( (yyvsp[(1) - (7)].aString) ); }
    break;

  case 27:
#line 94 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_append_string( NULL, (yyvsp[(1) - (1)].aString) ); free( (yyvsp[(1) - (1)].aString) ); }
    break;

  case 28:
#line 95 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_append_string( (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aString) ); free( (yyvsp[(1) - (3)].aPointer) ); }
    break;

  case 29:
#line 98 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(2) - (2)].aPointer); }
    break;

  case 30:
#line 99 "qnap2_gram.y"
    { (yyval.aPointer) = NULL; }
    break;

  case 33:
#line 110 "qnap2_gram.y"
    { qnap2_set_station_init( (yyvsp[(2) - (4)].aPointer), (yyvsp[(4) - (4)].aPointer) ); }
    break;

  case 34:
#line 111 "qnap2_gram.y"
    { qnap2_set_station_name( (yyvsp[(3) - (4)].aString) ); free( (yyvsp[(3) - (4)].aString) ); }
    break;

  case 35:
#line 112 "qnap2_gram.y"
    { qnap2_set_station_prio( (yyvsp[(2) - (4)].aPointer), (yyvsp[(4) - (4)].aPointer) ); }
    break;

  case 36:
#line 113 "qnap2_gram.y"
    { qnap2_set_station_quantum( (yyvsp[(2) - (4)].aPointer), (yyvsp[(4) - (4)].aPointer) ); }
    break;

  case 37:
#line 114 "qnap2_gram.y"
    { qnap2_set_station_rate( (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 38:
#line 115 "qnap2_gram.y"
    { qnap2_set_station_sched( (yyvsp[(3) - (3)].aString) ); free( (yyvsp[(3) - (3)].aString) ); }
    break;

  case 39:
#line 116 "qnap2_gram.y"
    { qnap2_set_station_service( (yyvsp[(2) - (4)].aPointer), (yyvsp[(4) - (4)].aPointer) ); }
    break;

  case 40:
#line 117 "qnap2_gram.y"
    { qnap2_set_station_transit( (yyvsp[(2) - (4)].aPointer), (yyvsp[(4) - (4)].aPointer) ); }
    break;

  case 41:
#line 118 "qnap2_gram.y"
    { qnap2_set_station_type( (yyvsp[(3) - (3)].aPointer) ); qnap2_delete_station_pair( (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 42:
#line 121 "qnap2_gram.y"
    { (yyval.aPointer) = NULL; }
    break;

  case 43:
#line 122 "qnap2_gram.y"
    { (yyval.aPointer) = NULL; }
    break;

  case 44:
#line 123 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(2) - (3)].aPointer); }
    break;

  case 45:
#line 126 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_append_string( NULL, qnap2_get_class_name( (yyvsp[(1) - (1)].aString) ) ); free( (yyvsp[(1) - (1)].aString) ); }
    break;

  case 46:
#line 127 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_append_string( (yyvsp[(1) - (3)].aPointer), qnap2_get_class_name( (yyvsp[(3) - (3)].aString) ) ); free( (yyvsp[(3) - (3)].aString) ); }
    break;

  case 47:
#line 131 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_service_distribution( (yyvsp[(1) - (4)].aCode), (yyvsp[(3) - (4)].aPointer), NULL ); }
    break;

  case 48:
#line 132 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_service_distribution( (yyvsp[(1) - (4)].aCode), (yyvsp[(3) - (4)].aPointer), NULL ); }
    break;

  case 49:
#line 133 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_service_distribution( (yyvsp[(1) - (4)].aCode), (yyvsp[(3) - (4)].aPointer), NULL ); }
    break;

  case 50:
#line 134 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_service_distribution( (yyvsp[(1) - (6)].aCode), (yyvsp[(3) - (6)].aPointer), (yyvsp[(5) - (6)].aPointer) ); }
    break;

  case 51:
#line 135 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_service_distribution( (yyvsp[(1) - (6)].aCode), (yyvsp[(3) - (6)].aPointer), (yyvsp[(5) - (6)].aPointer) ); }
    break;

  case 52:
#line 138 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_append_pointer( NULL, qnap2_get_transit_pair( (yyvsp[(1) - (1)].aString), NULL, NULL, NULL ) ); free( (yyvsp[(1) - (1)].aString) ); }
    break;

  case 53:
#line 139 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(1) - (1)].aPointer); }
    break;

  case 54:
#line 142 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_append_pointer( NULL, (yyvsp[(1) - (1)].aPointer) ); }
    break;

  case 55:
#line 143 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_append_pointer( (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 56:
#line 146 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_transit_pair( qnap2_get_station_name( (yyvsp[(1) - (3)].aString) ), NULL, (yyvsp[(3) - (3)].aPointer), NULL ); free( (yyvsp[(1) - (3)].aString) ); }
    break;

  case 57:
#line 148 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_transit_pair( qnap2_get_station_name( (yyvsp[(1) - (9)].aString) ), (yyvsp[(3) - (9)].aPointer), qnap2_get_variable( (yyvsp[(6) - (9)].aString) ), (yyvsp[(8) - (9)].aPointer) ); free( (yyvsp[(1) - (9)].aString) ); free( (yyvsp[(6) - (9)].aString) ); }
    break;

  case 58:
#line 152 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_station_type_pair( (yyvsp[(1) - (1)].aCode), NULL ); }
    break;

  case 59:
#line 153 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_station_type_pair( (yyvsp[(1) - (1)].aCode), NULL ); }
    break;

  case 60:
#line 154 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_station_type_pair( (yyvsp[(1) - (4)].aCode), (yyvsp[(3) - (4)].aPointer) ); }
    break;

  case 61:
#line 155 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_station_type_pair( (yyvsp[(1) - (1)].aCode), NULL ); }
    break;

  case 62:
#line 156 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_station_type_pair( (yyvsp[(1) - (4)].aCode), (yyvsp[(3) - (4)].aPointer) ); }
    break;

  case 63:
#line 159 "qnap2_gram.y"
    { (yyval.aCode) = (yyvsp[(1) - (1)].aCode); }
    break;

  case 64:
#line 160 "qnap2_gram.y"
    { (yyval.aCode) = (yyvsp[(1) - (1)].aCode); }
    break;

  case 65:
#line 163 "qnap2_gram.y"
    { (yyval.aCode) = (yyvsp[(1) - (3)].aCode); }
    break;

  case 66:
#line 166 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(2) - (3)].aPointer); }
    break;

  case 67:
#line 167 "qnap2_gram.y"
    { (yyval.aPointer) = NULL; }
    break;

  case 71:
#line 179 "qnap2_gram.y"
    { qnap2_set_option( (yyvsp[(3) - (4)].aPointer) ); }
    break;

  case 72:
#line 180 "qnap2_gram.y"
    { qnap2_set_entry( (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 73:
#line 181 "qnap2_gram.y"
    { qnap2_set_exit( (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 74:
#line 184 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_append_string( NULL, (yyvsp[(1) - (1)].aString) ); free( (yyvsp[(1) - (1)].aString) ); }
    break;

  case 75:
#line 185 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_append_string( (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aString) ); free( (yyvsp[(3) - (3)].aString) ); }
    break;

  case 76:
#line 192 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(1) - (1)].aPointer); }
    break;

  case 77:
#line 193 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(1) - (1)].aPointer); }
    break;

  case 78:
#line 196 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_if_statement( (yyvsp[(2) - (4)].aPointer), (yyvsp[(4) - (4)].aPointer), NULL ); }
    break;

  case 79:
#line 198 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_if_statement( (yyvsp[(2) - (6)].aPointer), (yyvsp[(4) - (6)].aPointer), (yyvsp[(6) - (6)].aPointer) ); }
    break;

  case 80:
#line 199 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_while_statement( (yyvsp[(2) - (4)].aPointer), (yyvsp[(4) - (4)].aPointer) ); }
    break;

  case 81:
#line 201 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_for_statement( (yyvsp[(2) - (6)].aPointer), (yyvsp[(4) - (6)].aPointer), (yyvsp[(6) - (6)].aPointer) ); }
    break;

  case 82:
#line 203 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_foreach_statement( (yyvsp[(2) - (6)].aPointer), (yyvsp[(4) - (6)].aPointer), (yyvsp[(6) - (6)].aPointer) ); }
    break;

  case 83:
#line 206 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(1) - (1)].aPointer); }
    break;

  case 84:
#line 208 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_if_statement( (yyvsp[(2) - (6)].aPointer), (yyvsp[(4) - (6)].aPointer), (yyvsp[(6) - (6)].aPointer) ); }
    break;

  case 85:
#line 209 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_while_statement( (yyvsp[(2) - (4)].aPointer), (yyvsp[(4) - (4)].aPointer) ); }
    break;

  case 86:
#line 211 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_for_statement( (yyvsp[(2) - (6)].aPointer), (yyvsp[(4) - (6)].aPointer), (yyvsp[(6) - (6)].aPointer) ); }
    break;

  case 87:
#line 213 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_foreach_statement( (yyvsp[(2) - (6)].aPointer), (yyvsp[(4) - (6)].aPointer), (yyvsp[(6) - (6)].aPointer) ); }
    break;

  case 88:
#line 216 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_compound_statement( (yyvsp[(2) - (4)].aPointer) ); }
    break;

  case 89:
#line 217 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_assignment( (yyvsp[(1) - (4)].aPointer), (yyvsp[(3) - (4)].aPointer) ); }
    break;

  case 90:
#line 218 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(1) - (2)].aPointer); }
    break;

  case 91:
#line 221 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_append_pointer( NULL, (yyvsp[(1) - (1)].aPointer) ); }
    break;

  case 92:
#line 222 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_append_pointer( (yyvsp[(1) - (2)].aPointer), (yyvsp[(2) - (2)].aPointer) ); }
    break;

  case 93:
#line 225 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_procedure( (yyvsp[(1) - (1)].aString), NULL ); free( (yyvsp[(1) - (1)].aString) ); }
    break;

  case 94:
#line 226 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_procedure( (yyvsp[(1) - (4)].aString), (yyvsp[(3) - (4)].aPointer) ); free( (yyvsp[(1) - (4)].aString) ); }
    break;

  case 95:
#line 229 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(1) - (1)].aPointer); }
    break;

  case 96:
#line 230 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_relation( (yyvsp[(2) - (3)].aCode), (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 97:
#line 231 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_relation( (yyvsp[(2) - (3)].aCode), (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 98:
#line 232 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_relation( (yyvsp[(2) - (3)].aCode), (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 99:
#line 233 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_relation( (yyvsp[(2) - (3)].aCode), (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 100:
#line 234 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_relation( (yyvsp[(2) - (3)].aCode), (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 101:
#line 235 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_relation( (yyvsp[(2) - (3)].aCode), (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 102:
#line 238 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_math( (yyvsp[(2) - (3)].aCode), (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 103:
#line 239 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_math( (yyvsp[(2) - (3)].aCode), (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 104:
#line 240 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_logic( (yyvsp[(2) - (3)].aCode), (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 105:
#line 241 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(1) - (1)].aPointer); }
    break;

  case 106:
#line 244 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_math( (yyvsp[(2) - (3)].aCode), (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 107:
#line 245 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_math( (yyvsp[(2) - (3)].aCode), (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 108:
#line 246 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_math( (yyvsp[(2) - (3)].aCode), (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 109:
#line 247 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_logic( (yyvsp[(2) - (3)].aCode), (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 110:
#line 248 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(1) - (1)].aPointer); }
    break;

  case 111:
#line 251 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_math( (yyvsp[(2) - (3)].aCode), (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 112:
#line 252 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(1) - (1)].aPointer); }
    break;

  case 113:
#line 255 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(2) - (2)].aPointer); }
    break;

  case 114:
#line 256 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_math( (yyvsp[(1) - (2)].aCode), NULL, (yyvsp[(2) - (2)].aPointer) ); }
    break;

  case 115:
#line 257 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_logic( (yyvsp[(1) - (2)].aCode), (yyvsp[(2) - (2)].aPointer), NULL ); }
    break;

  case 116:
#line 258 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(1) - (1)].aPointer); }
    break;

  case 117:
#line 261 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_attribute( qnap2_get_variable( (yyvsp[(1) - (4)].aString) ), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aPointer) ); free( (yyvsp[(3) - (4)].aString) ); }
    break;

  case 118:
#line 262 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(1) - (1)].aPointer); }
    break;

  case 119:
#line 263 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_attribute( (yyvsp[(1) - (4)].aPointer), (yyvsp[(3) - (4)].aString), (yyvsp[(4) - (4)].aPointer) ); free( (yyvsp[(3) - (4)].aString) ); }
    break;

  case 120:
#line 264 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(1) - (1)].aPointer); }
    break;

  case 121:
#line 267 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(2) - (3)].aPointer); }
    break;

  case 122:
#line 268 "qnap2_gram.y"
    { (yyval.aPointer) = NULL; }
    break;

  case 123:
#line 271 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_function( (yyvsp[(1) - (4)].aString), (yyvsp[(3) - (4)].aPointer) ); free( (yyvsp[(1) - (4)].aString) ); }
    break;

  case 124:
#line 274 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_variable( (yyvsp[(1) - (1)].aString) ); free( (yyvsp[(1) - (1)].aString) ); }
    break;

  case 125:
#line 275 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_integer( (yyvsp[(1) - (1)].aLong) ); }
    break;

  case 126:
#line 276 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_real( (yyvsp[(1) - (1)].aReal) ); }
    break;

  case 127:
#line 277 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_string( (yyvsp[(1) - (1)].aString) ); free( (yyvsp[(1) - (1)].aString) ); }
    break;

  case 128:
#line 278 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(2) - (3)].aPointer); }
    break;

  case 129:
#line 285 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(1) - (1)].aPointer); }
    break;

  case 130:
#line 286 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_comprehension( (yyvsp[(1) - (1)].aPointer) ); }
    break;

  case 131:
#line 289 "qnap2_gram.y"
    { (yyval.aPointer) = (yyvsp[(1) - (1)].aPointer); }
    break;

  case 132:
#line 290 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_array( (yyvsp[(1) - (1)].aPointer) ); }
    break;

  case 133:
#line 293 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_append_pointer( NULL, (yyvsp[(1) - (1)].aPointer) ); }
    break;

  case 134:
#line 294 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_append_pointer( (yyvsp[(1) - (3)].aPointer), (yyvsp[(3) - (3)].aPointer) ); }
    break;

  case 135:
#line 297 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_list( (yyvsp[(1) - (5)].aPointer), (yyvsp[(3) - (5)].aPointer), (yyvsp[(5) - (5)].aPointer) ); }
    break;

  case 136:
#line 300 "qnap2_gram.y"
    { (yyval.aPointer) = qnap2_get_all_objects( (yyvsp[(2) - (2)].aCode) ); }
    break;

  case 137:
#line 303 "qnap2_gram.y"
    { (yyval.aCode) = (yyvsp[(1) - (1)].aCode); }
    break;

  case 138:
#line 304 "qnap2_gram.y"
    { (yyval.aCode) = (yyvsp[(1) - (1)].aCode); }
    break;

  case 139:
#line 309 "qnap2_gram.y"
    { (yyval.aString) = (yyvsp[(1) - (1)].aString); }
    break;

  case 140:
#line 310 "qnap2_gram.y"
    { (yyval.aString) = strdup( "class" ); }
    break;

  case 141:
#line 311 "qnap2_gram.y"
    { (yyval.aString) = strdup( "cox" ); }
    break;

  case 142:
#line 312 "qnap2_gram.y"
    { (yyval.aString) = strdup( "cst" ); }
    break;

  case 143:
#line 313 "qnap2_gram.y"
    { (yyval.aString) = strdup( "erlang" ); }
    break;

  case 144:
#line 314 "qnap2_gram.y"
    { (yyval.aString) = strdup( "exp" ); }
    break;

  case 145:
#line 315 "qnap2_gram.y"
    { (yyval.aString) = strdup( "hexp" ); }
    break;

  case 146:
#line 316 "qnap2_gram.y"
    { (yyval.aString) = strdup( "infinite" ); }
    break;

  case 147:
#line 317 "qnap2_gram.y"
    { (yyval.aString) = strdup( "init" ); }
    break;

  case 148:
#line 318 "qnap2_gram.y"
    { (yyval.aString) = strdup( "integer" ); }
    break;

  case 149:
#line 319 "qnap2_gram.y"
    { (yyval.aString) = strdup( "multiple" ); }
    break;

  case 150:
#line 320 "qnap2_gram.y"
    { (yyval.aString) = strdup( "name" ); }
    break;

  case 151:
#line 321 "qnap2_gram.y"
    { (yyval.aString) = strdup( "option" ); }
    break;

  case 152:
#line 322 "qnap2_gram.y"
    { (yyval.aString) = strdup( "prio" ); }
    break;

  case 153:
#line 323 "qnap2_gram.y"
    { (yyval.aString) = strdup( "quantum" ); }
    break;

  case 154:
#line 324 "qnap2_gram.y"
    { (yyval.aString) = strdup( "queue" ); }
    break;

  case 155:
#line 325 "qnap2_gram.y"
    { (yyval.aString) = strdup( "rate" ); }
    break;

  case 156:
#line 326 "qnap2_gram.y"
    { (yyval.aString) = strdup( "real" ); }
    break;

  case 157:
#line 327 "qnap2_gram.y"
    { (yyval.aString) = strdup( "sched" ); }
    break;

  case 158:
#line 328 "qnap2_gram.y"
    { (yyval.aString) = strdup( "server" ); }
    break;

  case 159:
#line 329 "qnap2_gram.y"
    { (yyval.aString) = strdup( "service" ); }
    break;

  case 160:
#line 330 "qnap2_gram.y"
    { (yyval.aString) = strdup( "single" ); }
    break;

  case 161:
#line 331 "qnap2_gram.y"
    { (yyval.aString) = strdup( "source" ); }
    break;

  case 162:
#line 332 "qnap2_gram.y"
    { (yyval.aString) = strdup( "transit" ); }
    break;

  case 163:
#line 333 "qnap2_gram.y"
    { (yyval.aString) = strdup( "type" ); }
    break;


/* Line 1267 of yacc.c.  */
#line 2641 "qnap2_gram.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}


#line 335 "qnap2_gram.y"


