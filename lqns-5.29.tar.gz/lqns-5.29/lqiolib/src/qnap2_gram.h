/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     QNAP_CONTROL = 258,
     QNAP_DECLARE = 259,
     QNAP_END_PROGRAM = 260,
     QNAP_EXEC = 261,
     QNAP_RESTART = 262,
     QNAP_REBOOT = 263,
     QNAP_STATION = 264,
     QNAP_TERMINAL = 265,
     QNAP_INIT = 266,
     QNAP_NAME = 267,
     QNAP_PRIO = 268,
     QNAP_QUANTUM = 269,
     QNAP_RATE = 270,
     QNAP_SCHED = 271,
     QNAP_SERVICE = 272,
     QNAP_TRANSIT = 273,
     QNAP_TYPE = 274,
     QNAP_ENTRY = 275,
     QNAP_EXIT = 276,
     QNAP_ASSIGNMENT = 277,
     QNAP_ALL = 278,
     QNAP_ANY = 279,
     QNAP_BEGIN = 280,
     QNAP_DO = 281,
     QNAP_ELSE = 282,
     QNAP_END = 283,
     QNAP_FALSE = 284,
     QNAP_FOR = 285,
     QNAP_FORWARD = 286,
     QNAP_GENERIC = 287,
     QNAP_GOTO = 288,
     QNAP_IF = 289,
     QNAP_IN = 290,
     QNAP_IS = 291,
     QNAP_NIL = 292,
     QNAP_OBJECT = 293,
     QNAP_REF = 294,
     QNAP_REPEAT = 295,
     QNAP_STEP = 296,
     QNAP_THEN = 297,
     QNAP_TRUE = 298,
     QNAP_UNTIL = 299,
     QNAP_VAR = 300,
     QNAP_WATCHED = 301,
     QNAP_OPTION = 302,
     QNAP_WHILE = 303,
     QNAP_WITH = 304,
     RANGE_ERR = 305,
     STRING = 306,
     IDENTIFIER = 307,
     QNAP_AND = 308,
     QNAP_OR = 309,
     QNAP_NOT = 310,
     QNAP_EQUAL = 311,
     QNAP_NOT_EQUAL = 312,
     QNAP_LESS = 313,
     QNAP_LESS_EQUAL = 314,
     QNAP_GREATER = 315,
     QNAP_GREATER_EQUAL = 316,
     QNAP_POWER = 317,
     QNAP_PLUS = 318,
     QNAP_MINUS = 319,
     QNAP_DIVIDE = 320,
     QNAP_MULTIPLY = 321,
     QNAP_MODULUS = 322,
     QNAP_BOOLEAN = 323,
     QNAP_REAL = 324,
     QNAP_INTEGER = 325,
     QNAP_STRING = 326,
     QNAP_QUEUE = 327,
     QNAP_CLASS = 328,
     QNAP_CST = 329,
     QNAP_COX = 330,
     QNAP_EXP = 331,
     QNAP_ERLANG = 332,
     QNAP_HEXP = 333,
     QNAP_SERVER = 334,
     QNAP_MULTIPLE = 335,
     QNAP_SINGLE = 336,
     QNAP_SOURCE = 337,
     QNAP_INFINITE = 338,
     DOUBLE = 339,
     LONG = 340
   };
#endif
/* Tokens.  */
#define QNAP_CONTROL 258
#define QNAP_DECLARE 259
#define QNAP_END_PROGRAM 260
#define QNAP_EXEC 261
#define QNAP_RESTART 262
#define QNAP_REBOOT 263
#define QNAP_STATION 264
#define QNAP_TERMINAL 265
#define QNAP_INIT 266
#define QNAP_NAME 267
#define QNAP_PRIO 268
#define QNAP_QUANTUM 269
#define QNAP_RATE 270
#define QNAP_SCHED 271
#define QNAP_SERVICE 272
#define QNAP_TRANSIT 273
#define QNAP_TYPE 274
#define QNAP_ENTRY 275
#define QNAP_EXIT 276
#define QNAP_ASSIGNMENT 277
#define QNAP_ALL 278
#define QNAP_ANY 279
#define QNAP_BEGIN 280
#define QNAP_DO 281
#define QNAP_ELSE 282
#define QNAP_END 283
#define QNAP_FALSE 284
#define QNAP_FOR 285
#define QNAP_FORWARD 286
#define QNAP_GENERIC 287
#define QNAP_GOTO 288
#define QNAP_IF 289
#define QNAP_IN 290
#define QNAP_IS 291
#define QNAP_NIL 292
#define QNAP_OBJECT 293
#define QNAP_REF 294
#define QNAP_REPEAT 295
#define QNAP_STEP 296
#define QNAP_THEN 297
#define QNAP_TRUE 298
#define QNAP_UNTIL 299
#define QNAP_VAR 300
#define QNAP_WATCHED 301
#define QNAP_OPTION 302
#define QNAP_WHILE 303
#define QNAP_WITH 304
#define RANGE_ERR 305
#define STRING 306
#define IDENTIFIER 307
#define QNAP_AND 308
#define QNAP_OR 309
#define QNAP_NOT 310
#define QNAP_EQUAL 311
#define QNAP_NOT_EQUAL 312
#define QNAP_LESS 313
#define QNAP_LESS_EQUAL 314
#define QNAP_GREATER 315
#define QNAP_GREATER_EQUAL 316
#define QNAP_POWER 317
#define QNAP_PLUS 318
#define QNAP_MINUS 319
#define QNAP_DIVIDE 320
#define QNAP_MULTIPLY 321
#define QNAP_MODULUS 322
#define QNAP_BOOLEAN 323
#define QNAP_REAL 324
#define QNAP_INTEGER 325
#define QNAP_STRING 326
#define QNAP_QUEUE 327
#define QNAP_CLASS 328
#define QNAP_CST 329
#define QNAP_COX 330
#define QNAP_EXP 331
#define QNAP_ERLANG 332
#define QNAP_HEXP 333
#define QNAP_SERVER 334
#define QNAP_MULTIPLE 335
#define QNAP_SINGLE 336
#define QNAP_SOURCE 337
#define QNAP_INFINITE 338
#define DOUBLE 339
#define LONG 340




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 14 "qnap2_gram.y"
{
    int aCode;
    long aLong;
    double aReal;
    char * aString;
    void * aPointer;
}
/* Line 1529 of yacc.c.  */
#line 227 "qnap2_gram.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE qnap2lval;

