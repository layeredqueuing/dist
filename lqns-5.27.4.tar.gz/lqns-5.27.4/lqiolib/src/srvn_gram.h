/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_SRVN_SRVN_GRAM_H_INCLUDED
# define YY_SRVN_SRVN_GRAM_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int srvndebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    TEXT = 258,                    /* TEXT  */
    END_LIST = 259,                /* END_LIST  */
    SYMBOL = 260,                  /* SYMBOL  */
    VARIABLE = 261,                /* VARIABLE  */
    RANGE_ERR = 262,               /* RANGE_ERR  */
    SOLVER = 263,                  /* SOLVER  */
    INTEGER = 264,                 /* INTEGER  */
    FLOAT = 265,                   /* FLOAT  */
    CONST_INFINITY = 266,          /* CONST_INFINITY  */
    TRANSITION = 267,              /* TRANSITION  */
    KEY_UTILIZATION = 268,         /* KEY_UTILIZATION  */
    KEY_THROUGHPUT = 269,          /* KEY_THROUGHPUT  */
    KEY_PROCESSOR_UTILIZATION = 270, /* KEY_PROCESSOR_UTILIZATION  */
    KEY_SERVICE_TIME = 271,        /* KEY_SERVICE_TIME  */
    KEY_VARIANCE = 272,            /* KEY_VARIANCE  */
    KEY_THROUGHPUT_BOUND = 273,    /* KEY_THROUGHPUT_BOUND  */
    KEY_PROCESSOR_WAITING = 274,   /* KEY_PROCESSOR_WAITING  */
    KEY_WAITING = 275,             /* KEY_WAITING  */
    KEY_WAITING_VARIANCE = 276,    /* KEY_WAITING_VARIANCE  */
    KEY_ITERATIONS = 277,          /* KEY_ITERATIONS  */
    KEY_ELAPSED_TIME = 278,        /* KEY_ELAPSED_TIME  */
    KEY_USER_TIME = 279,           /* KEY_USER_TIME  */
    KEY_SYSTEM_TIME = 280,         /* KEY_SYSTEM_TIME  */
    KEY_EXCEEDED_TIME = 281,       /* KEY_EXCEEDED_TIME  */
    TOK_LESS_EQUAL = 282,          /* TOK_LESS_EQUAL  */
    TOK_LOGIC_NOT = 283,           /* TOK_LOGIC_NOT  */
    TOK_LESS_THAN = 284,           /* TOK_LESS_THAN  */
    TOK_NOT_EQUALS = 285,          /* TOK_NOT_EQUALS  */
    TOK_GREATER_EQUAL = 286,       /* TOK_GREATER_EQUAL  */
    TOK_EQUALS = 287,              /* TOK_EQUALS  */
    TOK_LOGIC_AND = 288,           /* TOK_LOGIC_AND  */
    TOK_GREATER_THAN = 289,        /* TOK_GREATER_THAN  */
    TOK_LOGIC_OR = 290,            /* TOK_LOGIC_OR  */
    TOK_POWER = 291,               /* TOK_POWER  */
    SRVN_INPUT = 292,              /* SRVN_INPUT  */
    SPEX_PARAMETER = 293,          /* SPEX_PARAMETER  */
    SPEX_RESULT = 294,             /* SPEX_RESULT  */
    SPEX_CONVERGENCE = 295,        /* SPEX_CONVERGENCE  */
    SPEX_EXPRESSION = 296          /* SPEX_EXPRESSION  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif
/* Token kinds.  */
#define YYEMPTY -2
#define YYEOF 0
#define YYerror 256
#define YYUNDEF 257
#define TEXT 258
#define END_LIST 259
#define SYMBOL 260
#define VARIABLE 261
#define RANGE_ERR 262
#define SOLVER 263
#define INTEGER 264
#define FLOAT 265
#define CONST_INFINITY 266
#define TRANSITION 267
#define KEY_UTILIZATION 268
#define KEY_THROUGHPUT 269
#define KEY_PROCESSOR_UTILIZATION 270
#define KEY_SERVICE_TIME 271
#define KEY_VARIANCE 272
#define KEY_THROUGHPUT_BOUND 273
#define KEY_PROCESSOR_WAITING 274
#define KEY_WAITING 275
#define KEY_WAITING_VARIANCE 276
#define KEY_ITERATIONS 277
#define KEY_ELAPSED_TIME 278
#define KEY_USER_TIME 279
#define KEY_SYSTEM_TIME 280
#define KEY_EXCEEDED_TIME 281
#define TOK_LESS_EQUAL 282
#define TOK_LOGIC_NOT 283
#define TOK_LESS_THAN 284
#define TOK_NOT_EQUALS 285
#define TOK_GREATER_EQUAL 286
#define TOK_EQUALS 287
#define TOK_LOGIC_AND 288
#define TOK_GREATER_THAN 289
#define TOK_LOGIC_OR 290
#define TOK_POWER 291
#define SRVN_INPUT 292
#define SPEX_PARAMETER 293
#define SPEX_RESULT 294
#define SPEX_CONVERGENCE 295
#define SPEX_EXPRESSION 296

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 39 "srvn_gram.y"

    long anInt;
    double aFloat;
    void * aVariable;
    void * domObject;
    char * aString;
    void * entryList;
    void * activityList;
    scheduling_type schedulingFlag;
    void * aParseTreeNode;
    void * aParseTreeList;

#line 162 "srvn_gram.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE srvnlval;


int srvnparse (void);


#endif /* !YY_SRVN_SRVN_GRAM_H_INCLUDED  */
