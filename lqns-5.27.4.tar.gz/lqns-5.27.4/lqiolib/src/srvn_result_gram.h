/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_RESULT_SRVN_RESULT_GRAM_H_INCLUDED
# define YY_RESULT_SRVN_RESULT_GRAM_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int resultdebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    VALIDITY_FLAG = 258,           /* VALIDITY_FLAG  */
    CONV_FLAG = 259,               /* CONV_FLAG  */
    ITERATION_FLAG = 260,          /* ITERATION_FLAG  */
    PROC_COUNT_FLAG = 261,         /* PROC_COUNT_FLAG  */
    PHASE_COUNT_FLAG = 262,        /* PHASE_COUNT_FLAG  */
    BOUND_FLAG = 263,              /* BOUND_FLAG  */
    DROP_PROBABILITY_FLAG = 264,   /* DROP_PROBABILITY_FLAG  */
    SERVICE_EXCEEDED_FLAG = 265,   /* SERVICE_EXCEEDED_FLAG  */
    DISTRIBUTION_FLAG = 266,       /* DISTRIBUTION_FLAG  */
    WAITING_FLAG = 267,            /* WAITING_FLAG  */
    WAITING_VARIANCE_FLAG = 268,   /* WAITING_VARIANCE_FLAG  */
    FWD_WAITING_FLAG = 269,        /* FWD_WAITING_FLAG  */
    FWD_WAITING_VARIANCE_FLAG = 270, /* FWD_WAITING_VARIANCE_FLAG  */
    SNR_WAITING_FLAG = 271,        /* SNR_WAITING_FLAG  */
    SNR_WAITING_VARIANCE_FLAG = 272, /* SNR_WAITING_VARIANCE_FLAG  */
    JOIN_FLAG = 273,               /* JOIN_FLAG  */
    HOLD_TIME_FLAG = 274,          /* HOLD_TIME_FLAG  */
    RWLOCK_HOLD_TIME_FLAG = 275,   /* RWLOCK_HOLD_TIME_FLAG  */
    SERVICE_FLAG = 276,            /* SERVICE_FLAG  */
    VARIANCE_FLAG = 277,           /* VARIANCE_FLAG  */
    THPT_UT_FLAG = 278,            /* THPT_UT_FLAG  */
    OPEN_ARRIV_FLAG = 279,         /* OPEN_ARRIV_FLAG  */
    PROC_FLAG = 280,               /* PROC_FLAG  */
    GROUP_FLAG = 281,              /* GROUP_FLAG  */
    OVERTAKING_FLAG = 282,         /* OVERTAKING_FLAG  */
    ENDLIST = 283,                 /* ENDLIST  */
    REAL_TIME = 284,               /* REAL_TIME  */
    USER_TIME = 285,               /* USER_TIME  */
    SYST_TIME = 286,               /* SYST_TIME  */
    MAX_RSS = 287,                 /* MAX_RSS  */
    SOLVER = 288,                  /* SOLVER  */
    INTEGER = 289,                 /* INTEGER  */
    FLOAT = 290,                   /* FLOAT  */
    TIME = 291,                    /* TIME  */
    SYMBOL = 292,                  /* SYMBOL  */
    TEXT = 293,                    /* TEXT  */
    INFTY = 294,                   /* INFTY  */
    VARIABLE = 295,                /* VARIABLE  */
    COMMENT = 296,                 /* COMMENT  */
    CHAR = 297                     /* CHAR  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif
/* Token kinds.  */
#define YYEMPTY -2
#define YYEOF 0
#define YYerror 256
#define YYUNDEF 257
#define VALIDITY_FLAG 258
#define CONV_FLAG 259
#define ITERATION_FLAG 260
#define PROC_COUNT_FLAG 261
#define PHASE_COUNT_FLAG 262
#define BOUND_FLAG 263
#define DROP_PROBABILITY_FLAG 264
#define SERVICE_EXCEEDED_FLAG 265
#define DISTRIBUTION_FLAG 266
#define WAITING_FLAG 267
#define WAITING_VARIANCE_FLAG 268
#define FWD_WAITING_FLAG 269
#define FWD_WAITING_VARIANCE_FLAG 270
#define SNR_WAITING_FLAG 271
#define SNR_WAITING_VARIANCE_FLAG 272
#define JOIN_FLAG 273
#define HOLD_TIME_FLAG 274
#define RWLOCK_HOLD_TIME_FLAG 275
#define SERVICE_FLAG 276
#define VARIANCE_FLAG 277
#define THPT_UT_FLAG 278
#define OPEN_ARRIV_FLAG 279
#define PROC_FLAG 280
#define GROUP_FLAG 281
#define OVERTAKING_FLAG 282
#define ENDLIST 283
#define REAL_TIME 284
#define USER_TIME 285
#define SYST_TIME 286
#define MAX_RSS 287
#define SOLVER 288
#define INTEGER 289
#define FLOAT 290
#define TIME 291
#define SYMBOL 292
#define TEXT 293
#define INFTY 294
#define VARIABLE 295
#define COMMENT 296
#define CHAR 297

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 75 "srvn_result_gram.y"

	int anInt;
	double aFloat;
	char *aString;
	char aChar;
	double *aFloatList;

#line 159 "srvn_result_gram.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE resultlval;


int resultparse (void);


#endif /* !YY_RESULT_SRVN_RESULT_GRAM_H_INCLUDED  */
