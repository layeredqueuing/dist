/* -*- c++ -*-
 * $HeadURL: http://rads-svn.sce.carleton.ca:8080/svn/lqn/tags/V5/24.0/qnsolver/boundsmodel.cc $
 *
 * SRVN command line interface.
 *
 * Copyright the Real-Time and Distributed Systems Group,
 * Department of Systems and Computer Engineering,
 * Carleton University, Ottawa, Ontario, Canada. K1S 5B6
 *
 * December 2020
 *
 * $Id: boundsmodel.cc 15425 2022-02-04 13:32:11Z greg $
 *
 * ------------------------------------------------------------------------
 */

#include <string>
#include <sstream>
#include <algorithm>
#include <numeric>
#include <lqio/jmva_document.h>
#include <lqio/dom_extvar.h>
#include "boundsmodel.h"

BoundsModel::BoundsModel( Model& parent, BCMP::JMVA_Document& input ) : Model(input,Model::Solver::BOUNDS), _parent(parent), _bounds()
{
    const size_t K = _model.n_chains(type());
    const size_t M = _model.n_stations(type());
    _result = K > 0 && M > 0;
    if ( !_result ) return;
}



BoundsModel::~BoundsModel()
{
}


/*
 * For each chain, find the station with the highest demand, and find
 * the total demand.  Highest demand gives throughput bound, total
 * demand gives response bound.  I suppose I can calculate the number
 * of customers per class too so that I can find the x-range.
 */

bool
BoundsModel::construct()
{
    assert( !isParent() );
    
    for ( BCMP::Model::Chain::map_t::const_iterator chain = chains().begin(); chain != chains().end(); ++chain ) {
	_bounds.emplace( chain->first, BCMP::Model::Bound(*chain,stations()) );
    }
    return true;
}


/*
 * Find bounds.  For all chains, find D_max.  Find N.
 */

bool
BoundsModel::solve()
{
    for ( std::map<std::string,BCMP::Model::Bound>::iterator b = _bounds.begin(); b != _bounds.end(); ++b ) {
    }
    return true;
}


void
BoundsModel::saveResults()
{
}
