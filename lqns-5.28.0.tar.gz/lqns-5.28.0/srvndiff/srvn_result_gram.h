/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     VALIDITY_FLAG = 258,
     CONV_FLAG = 259,
     ITERATION_FLAG = 260,
     PROC_COUNT_FLAG = 261,
     PHASE_COUNT_FLAG = 262,
     BOUND_FLAG = 263,
     DROP_PROBABILITY_FLAG = 264,
     SERVICE_EXCEEDED_FLAG = 265,
     DISTRIBUTION_FLAG = 266,
     WAITING_FLAG = 267,
     WAITING_VARIANCE_FLAG = 268,
     FWD_WAITING_FLAG = 269,
     FWD_WAITING_VARIANCE_FLAG = 270,
     SNR_WAITING_FLAG = 271,
     SNR_WAITING_VARIANCE_FLAG = 272,
     JOIN_FLAG = 273,
     HOLD_TIME_FLAG = 274,
     RWLOCK_HOLD_TIME_FLAG = 275,
     SERVICE_FLAG = 276,
     VARIANCE_FLAG = 277,
     THPT_UT_FLAG = 278,
     OPEN_ARRIV_FLAG = 279,
     PROC_FLAG = 280,
     GROUP_FLAG = 281,
     OVERTAKING_FLAG = 282,
     ENDLIST = 283,
     REAL_TIME = 284,
     USER_TIME = 285,
     SYST_TIME = 286,
     MAX_RSS = 287,
     SOLVER = 288,
     INTEGER = 289,
     FLOAT = 290,
     TIME = 291,
     SYMBOL = 292,
     TEXT = 293,
     INFTY = 294,
     VARIABLE = 295,
     COMMENT = 296,
     CHAR = 297
   };
#endif
/* Tokens.  */
#define VALIDITY_FLAG 258
#define CONV_FLAG 259
#define ITERATION_FLAG 260
#define PROC_COUNT_FLAG 261
#define PHASE_COUNT_FLAG 262
#define BOUND_FLAG 263
#define DROP_PROBABILITY_FLAG 264
#define SERVICE_EXCEEDED_FLAG 265
#define DISTRIBUTION_FLAG 266
#define WAITING_FLAG 267
#define WAITING_VARIANCE_FLAG 268
#define FWD_WAITING_FLAG 269
#define FWD_WAITING_VARIANCE_FLAG 270
#define SNR_WAITING_FLAG 271
#define SNR_WAITING_VARIANCE_FLAG 272
#define JOIN_FLAG 273
#define HOLD_TIME_FLAG 274
#define RWLOCK_HOLD_TIME_FLAG 275
#define SERVICE_FLAG 276
#define VARIANCE_FLAG 277
#define THPT_UT_FLAG 278
#define OPEN_ARRIV_FLAG 279
#define PROC_FLAG 280
#define GROUP_FLAG 281
#define OVERTAKING_FLAG 282
#define ENDLIST 283
#define REAL_TIME 284
#define USER_TIME 285
#define SYST_TIME 286
#define MAX_RSS 287
#define SOLVER 288
#define INTEGER 289
#define FLOAT 290
#define TIME 291
#define SYMBOL 292
#define TEXT 293
#define INFTY 294
#define VARIABLE 295
#define COMMENT 296
#define CHAR 297




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 75 "srvn_result_gram.y"
{
	int anInt;
	double aFloat;
	char *aString;
	char aChar;
	double *aFloatList;
}
/* Line 1529 of yacc.c.  */
#line 141 "srvn_result_gram.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE resultlval;

